window.onload=function(){
	//	放大镜tab切换
	var lunBox = getId('lun');//轮播图盒子
    var lunLis = lunBox.getElementsByTagName("li");//指定的小图
    var glassBox = getId('glass');//被放大图片盒子
    var glassLis = glassBox.getElementsByTagName("li");//被放大图
    var mask = getClass("mask");//放大镜
    var big = getId("big");//放大效果图盒子
    var bigImg = big.children;//放大效果图
    console.log(mask);
    //2循环遍历,遍历所有的li,绑定点击事件
	for(var i=0; i<lunLis.length; i++){
		lunLis[i].onmouseover = function(){
		    //i = 0, lis[0] spans[0]
			//3.第二层循环,用来给li与span绑定类的
			//点击到哪一个,哪一个就具有类
			for(var j=0; j<lunLis.length; j++){
				//4.this指向discountLis[i]
 				if(this == lunLis[j]){
 					glassLis[j].className = "selected";
 					lunLis[j].className = "show";
 				}else{
 					glassLis[j].className = "";
 					lunLis[j].className = "";
 				}
			}	
		}	
	}
	
	//放大镜
	for(var i=0; i<glassLis.length; i++){
		glassLis[i].onmouseover = function(){
		    //i = 0, lis[0] spans[0]
			//3.第二层循环,用来给li与span绑定类的
			//点击到哪一个,哪一个就具有类
			for(var j=0; j<glassLis.length; j++){
				//4.this指向discountLis[i]
 				if(this == glassLis[j]){
 					mask[j].style.display = "block";
 					big.style.display = "block";
 				}
			}	
		}
		glassLis[i].onmouseout = function(){
		    //i = 0, lis[0] spans[0]
			//3.第二层循环,用来给li与span绑定类的
			//点击到哪一个,哪一个就具有类
			for(var j=0; j<glassLis.length; j++){
				//4.this指向discountLis[i]
 				if(this == glassLis[j]){
 					mask[j].style.display = "none";
 					big.style.display = "none";
   				}
			}	
		}	
	}
//	for(var i=0; i<glassLis.length; i++){
//		glassLis[0].onmouseover = function(event){
//      //想移动黄盒子，必须知道鼠标在small中的位置。x作为mask的left值，y作mask的top值。
//      //新五步
//      event = event || window.event;
//      var pagex = event.pageX || scroll().left + event.clientX;
//      var pagey = event.pageY || scroll().top + event.clientY;
//      //让鼠标在黄盒子最中间，减去黄盒子宽高的一半
//      var x = pagex - glassBox.offsetLeft - mask[0].offsetWidth/2;
//      var y = pagey - glassBox.offsetTop - mask[0].offsetHeight/2;
//      //限制换盒子的范围
//      //left取值为大于0，小盒子的宽-mask的宽。
//      if(x<0){
//          x = 0;
//      }
//      if(x>glassLis[0].offsetWidth-mask[0].offsetWidth){
//          x = glassLis[0].offsetWidth-mask[0].offsetWidth;
//      }
//      //top同理。
//      if(y<0){
//          y = 0;
//      }
//      if(y>glassLis[0].offsetHeight-mask[0].offsetHeight){
//          y = glassLis[0].offsetHeight-mask[0].offsetHeight;
//      }
//      //移动黄盒子
//      console.log(glassLis[i].offsetHeight);
//      mask[0].style.left = x + "px";
//      mask[0].style.top = y + "px";
//
//      //3.右侧的大图片，等比例移动。
//      //如何移动大图片？等比例移动。
//      //    大图片/大盒子 = 小图片/mask盒子
//      //    大图片走的距离/mask走的距离 = （大图片-大盒子）/（小图片-黄盒子）
////                var bili = (bigImg.offsetWidth-big.offsetWidth)/(small.offsetWidth-mask.offsetWidth);
//
//      //大图片走的距离/mask盒子都的距离 = 大图片/小图片
//      var bili = bigImg[0].offsetWidth/glassLis[0].offsetWidth;
//
//      var xx = bili*x;
//      var yy = bili*y;
//
//
//      bigImg[0].style.marginTop = -yy+"px";
//      bigImg[0].style.marginLeft = -xx+"px";
//  }
	
//======================================================
	//增值业务下拉块
	var addBox = getClass("add")[0];
	var ddArr = addBox.getElementsByTagName("dd");
	var addXia = getClass("addXia");
	console.log(addXia);
	for(var i=0; i<ddArr.length; i++){
		ddArr[i].onmouseover = function(){
		    //i = 0, lis[0] spans[0]
			//3.第二层循环,用来给li与span绑定类的
			//点击到哪一个,哪一个就具有类
			for(var j=0; j<ddArr.length; j++){
				//4.this指向discountLis[i]
 				if(this == ddArr[j]){
 					addXia[j].style.display = "block";
 				}
			}	
		}
		ddArr[i].onmouseout = function(){
		    //i = 0, lis[0] spans[0]
			//3.第二层循环,用来给li与span绑定类的
			//点击到哪一个,哪一个就具有类
			for(var j=0; j<ddArr.length; j++){
				//4.this指向discountLis[i]
 				if(this == ddArr[j]){
 					addXia[j].style.display = "none";
   				}
			}	
		}	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
