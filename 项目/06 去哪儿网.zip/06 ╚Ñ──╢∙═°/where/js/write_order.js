window.onload = function () {
    
    //1.获取id
    function getId(id){
        return  document.getElementById(id);
    }
    //2.获取类名
    function getClass(cls){
        //找到所有的标签
        var elem = document.all?document.all:document.getElementsByTagName("*");
        //新建数组
        var arr = [];
        //遍历找到所有标签数组
        for(var i=0; i<elem.length;i++){
            //判断标签数组所有的元素的类名与传进来的参数cls是否相等
            if(elem[i].className==cls){
                //把具有这个类的元素放进arr数组
                arr.push(elem[i]);
            }
        }
        //把找到的数组传出去
        return arr;
    }
    //3.获取标签名
    function getEle(ele){
        return  document.getElementsByTagName(ele);
    }

// --------------------------------------------     //服务块
    var service = document.getElementById('service');//服务费
    var serviceXia = document.getElementById('service_xia');//服务费下拉效果
    service.onmousemove = function(){
    	serviceXia.style.display = 'block';
    }
    service.onmouseout = function(){
    	serviceXia.style.display = 'none';
    }

// -----------------------------------------------
    //保险红块
    var safeZi = document.getElementById('safe_zi');//服务费
    var redSafe = document.getElementById('red_safe');//服务费下拉效果
    safeZi.onmousemove = function(){
    	redSafe.style.display = 'block';
    }
    safeZi.onmouseout = function(){
    	redSafe.style.display = 'none';
    }

// -----------------------------------------------
    //报销凭证下拉块
    var faPiao = document.getElementById('faPiao');//服务费
    var evidenceXia = document.getElementById('evidence_xia');//服务费下拉效果
    faPiao.onclick = function(){
    	evidenceXia.style.display = 'block';
    	faPiao.onclick = function(){
	    	evidenceXia.style.display = 'none';
	    }
    }
    
// -----------------------------------------------
    //正则表达式
    var rideInput = document.getElementsByClassName('ride_input')[0];//输入框的盒子
    var inputP = rideInput.getElementsByTagName('p');//输入框的下粉色框
     var rideInput1 = document.getElementsByClassName('ride_input')[1];//输入框的盒子
    var inputP1 = rideInput1.getElementsByTagName('p');//输入框的下粉色框
    // 乘车人姓名
    addEvent("input_name_c", function () {
        //开头13, 结尾为0-9的八个数字; 或开头为15, 结尾为 [非4到非数字] 的八个数字; 或开头18, 结尾为0-9的八个数字;
        if(/^[\u4e00-\u9fa5]{2,4}$/.test(this.value)){
            inputP[0].style.display = 'none';
        }else{
            inputP[0].style.display = 'block';
        }
    });
    // 乘车人身份证号
    addEvent("input_ID_c", function () {
        //开头13, 结尾为0-9的八个数字; 或开头为15, 结尾为 [非4到非数字] 的八个数字; 或开头18, 结尾为0-9的八个数字;
        if(/(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/.test(this.value)){
            inputP[1].style.display = 'none';
        }else{
            inputP[1].style.display = 'block';
        }
    });
    // 取票人姓名
    addEvent("input_name_q", function () {
        //开头13, 结尾为0-9的八个数字; 或开头为15, 结尾为 [非4到非数字] 的八个数字; 或开头18, 结尾为0-9的八个数字;
        if(/^[\u4e00-\u9fa5]{2,4}$/.test(this.value)){
            inputP1[0].style.display = 'none';
        }else{
            inputP1[0].style.display = 'block';
        }
    });
    // 取票人身份证号
    addEvent("input_ID_q", function () {
        //开头13, 结尾为0-9的八个数字; 或开头为15, 结尾为 [非4到非数字] 的八个数字; 或开头18, 结尾为0-9的八个数字;
        if(/(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/.test(this.value)){
            inputP1[1].style.display = 'none';
        }else{
            inputP1[1].style.display = 'block';
        }
    });
    // 取票人手机号
    addEvent("input_phone_q", function () {
        //开头13, 结尾为0-9的八个数字; 或开头为15, 结尾为 [非4到非数字] 的八个数字; 或开头18, 结尾为0-9的八个数字;
        if(/^((13[0-9])|(15[^4,\D])|(18[0-9]))\d{8}$/.test(this.value)){
            inputP1[2].style.display = 'none';
        }else{
            inputP1[2].style.display = 'block';
        }
    });

    
    function addEvent(str,fn){
            document.getElementById(str).onblur = fn;
        }

// -----------------------------------------------
    //更多保障多选框
    var baoCheckbox = document.getElementsByClassName('baoCheckbox')[0];//更多保障多选框
    var baoZi = document.getElementById('bao_zi');//更多保障一行字
    var baoNumber = document.getElementById('bao_number');//价钱数字
    var instructions = document.getElementById('instructions');//《旅游险说明》
    baoCheckbox.onclick = function(){
        baoZi.innerText = '您已选购¥2目的地保障礼包,下车了也能保';
        baoNumber.innerText = '¥138.00';
        instructions.style.display = 'inline-block';
        baoCheckbox.onclick = function(){
            baoZi.innerText = '2元保1天,下车了也能保,点击购买目的地保障礼包';
            baoNumber.innerText = '¥136.00';
            instructions.style.display = 'none';
        }
    }





















}