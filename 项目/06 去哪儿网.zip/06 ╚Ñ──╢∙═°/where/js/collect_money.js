window.onload = function () {
    //1.获取id
    function getId(id){
        return  document.getElementById(id);
    }
    //2.获取类名
    function getClass(cls){
        //找到所有的标签
        var elem = document.all?document.all:document.getElementsByTagName("*");
        //新建数组
        var arr = [];
        //遍历找到所有标签数组
        for(var i=0; i<elem.length;i++){
            //判断标签数组所有的元素的类名与传进来的参数cls是否相等
            if(elem[i].className==cls){
                //把具有这个类的元素放进arr数组
                arr.push(elem[i]);
            }
        }
        //把找到的数组传出去
        return arr;
    }
    //3.获取标签名
    function getEle(ele){
        return  document.getElementsByTagName(ele);
    }

// --------------------------------------------     
    //支付银行卡的tab切换
    var payTitle = getId('pay_title');//标题的外壳
    // var payTitle = document.getElementById('pay_title');//标题的外壳
    var payLis = payTitle.getElementsByTagName("li");//指定的标题
    var payBox = document.getElementsByClassName('pay_box')[0];//特惠产品块
    var payDivs = payBox.getElementsByTagName("i");//指定的产品块
    //2循环遍历,遍历所有的li,绑定点击事件 
    console.log(payDivs);
	for(var i=0; i< payLis.length; i++){
		payLis[i].onclick = function(){
		    //i = 0, lis[0] spans[0]
			//3.第二层循环,用来给li与span绑定类的
			//点击到哪一个,哪一个就具有类
			for(var j=0; j< payLis.length; j++){
				//4.this指向tourLis[i]
 				if(this == payLis[j]){
 					payLis[j].className = "pay_selected";
 					payDivs[j].className = "pay_show";
 				}else{
 					payLis[j].className = "";
 					payDivs[j].className = "";
 				}
			}	
		}	
	}

//------------------------------------------------------
    // 银行卡正背面
    var zhengInp = document.getElementById('zhengInp');//正面输入框
    var zhengImg = document.getElementById('zhengImg');//正面图片
    var beiInp = document.getElementById('beiInp');//背面输入框
    var beiImg = document.getElementById('beiImg');//背面图片
    zhengInp.onclick = function(){
    	zhengImg.style.display = 'block';
    	beiImg.style.display = 'none';
    }
    beiInp.onclick = function(){
    	zhengImg.style.display = 'none';
    	beiImg.style.display = 'block';
    }
































}