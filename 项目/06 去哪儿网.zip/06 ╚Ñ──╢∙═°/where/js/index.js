window.onload = function () {
	//1.获取id
	function getId(id){
	    return  document.getElementById(id);
	}
	//2.获取类名
	function getClass(cls){
	    //找到所有的标签
	    var elem = document.all?document.all:document.getElementsByTagName("*");
	    //新建数组
	    var arr = [];
	    //遍历找到所有标签数组
	    for(var i=0; i<elem.length;i++){
	        //判断标签数组所有的元素的类名与传进来的参数cls是否相等
	        if(elem[i].className==cls){
	            //把具有这个类的元素放进arr数组
	            arr.push(elem[i]);
	        }
	    }
	    //把找到的数组传出去
	    return arr;
	}
    //3.获取标签名
    function getEle(ele){
	    return  document.getElementsByTagName(ele);
	}

// --------------------------------------------   	
	// 查看订单
	var orderXia = getId('orderXia');//订单下效果块
	var orderA = getId('orderA');//a链接改变字体颜色
	var orderli = getClass('order')[0];//查看订单的li标签
	// var orderXia = document.getElementById('orderXia');//订单下效果块
	// var orderA = document.getElementById('orderA');//a链接改变字体颜色
	// var orderli = document.getElementsByClassName('order')[0];//查看订单的li标签
	var orderTu = orderli.getElementsByTagName('i');//阿里图标
	orderTu[0].onmouseover = orderXia.onmouseover = function(){
		orderXia.style.display="block";
		orderA.style.color = "#00a3d2";
		orderTu[1].style.color = "#00a3d2";
		orderTu[0].className = "";
    	orderTu[1].className = "iconfont icon-arrow-left-copy";
	}
	orderXia.onmouseout = function(){
		orderXia.style.display="none";
        orderA.style.color = "#666";
        orderTu[1].style.color = "#666";
        orderTu[0].className = "iconfont icon-down";
    	orderTu[1].className = "";
	}
 
 // --------------------------------------------   
    // 团购
    var nav = document.getElementById('nav');
    shopping = nav.children[3];
    var shoppingXia = document.getElementById('shoppingXia');
    var A = shopping.children[0];
    shopping.onmouseover = shoppingXia.onmouseover = function(){
		shoppingXia.style.display="block";
		shopping.style.borderLeft = "1px solid #ccc";
		shopping.style.borderRight = "1px solid #ccc";
		shopping.style.boxShadow = "#e6e6e6 0 15px 30px 0px";
		A.style.color = "#00a3d2";
	}
	shoppingXia.onmouseout = shopping.onmouseout = function(){
		shoppingXia.style.display="none";
		shopping.style.borderLeft = "none";
		shopping.style.borderRight = "none";
		shopping.style.boxShadow = "none";
		A.style.color = "#666";
	}
	// 金融
    var moneyXia = document.getElementById('moneyXia');//金融的下拉效果dl
    money = nav.children[14];//第15个li金融
    var B = money.children[0];//li的第一个孩子a标签"金融"两个字
	money.onmouseover = moneyXia.onmouseover = function(){
		moneyXia.style.display="block";
		money.style.borderLeft = "1px solid #ccc";
		money.style.borderRight = "1px solid #ccc";
		money.style.boxShadow = "#e6e6e6 0 15px 30px 0px";
		B.style.color = "#00a3d2";
	}
	moneyXia.onmouseout = money.onmouseout =function(){
		moneyXia.style.display="none";
		money.style.borderLeft = "none";
		money.style.borderRight = "none";
		money.style.boxShadow = "none";
		B.style.color = "#666";
	}
	// 门票
    var piaoXia = document.getElementById('piaoXia');//金融的下拉效果dl
    piao = nav.children[6];//第15个li金融
    var C = piao.children[0];//li的第一个孩子a标签"金融"两个字
	piao.onmouseover = piao.onmouseover = function(){
		piaoXia.style.display="block";
		piao.style.borderLeft = "1px solid #ccc";
		piao.style.borderRight = "1px solid #ccc";
		piao.style.boxShadow = "#e6e6e6 0 15px 30px 0px";
		C.style.color = "#00a3d2";
	}
	piaoXia.onmouseout = piao.onmouseout =function(){
		piaoXia.style.display="none";
		piao.style.borderLeft = "none";
		piao.style.borderRight = "none";
		piao.style.boxShadow = "none";
		C.style.color = "#666";
	}
	// 车车
    var carXia = document.getElementById('carXia');//金融的下拉效果dl
    car = nav.children[10];//第15个li金融
    var D = car.children[0];//li的第一个孩子a标签"金融"两个字
	car.onmouseover = car.onmouseover = function(){
		carXia.style.display="block";
		car.style.borderLeft = "1px solid #ccc";
		car.style.borderRight = "1px solid #ccc";
		car.style.boxShadow = "#e6e6e6 0 15px 30px 0px";
		D.style.color = "#00a3d2";
	}
	carXia.onmouseout = car.onmouseout =function(){
		carXia.style.display="none";
		car.style.borderLeft = "none";
		car.style.borderRight = "none";
		car.style.boxShadow = "none";
		D.style.color = "#666";
	}

// --------------------------------------------
     // 特惠tab切换discount_title
    var discountTitle = document.getElementsByClassName('discount_title')[0];//标题的外壳
    var discountLis = discountTitle.getElementsByTagName("li");//指定的标题
    var discountBox = document.getElementsByClassName('discount_box')[0];//特惠产品块
    var discountDivs = discountBox.getElementsByTagName("div");//指定的产品块
    //2循环遍历,遍历所有的li,绑定点击事件 
	for(var i=0; i<discountLis.length; i++){
		discountLis[i].onmouseover = function(){
		    //i = 0, lis[0] spans[0]
			//3.第二层循环,用来给li与span绑定类的
			//点击到哪一个,哪一个就具有类
			for(var j=0; j<discountLis.length; j++){
				//4.this指向discountLis[i]
 				if(this == discountLis[j]){
 					discountLis[j].className = "discount_seleted";
 					discountDivs[j].className = "discount_show";
 				}else{
 					discountLis[j].className = "";
 					discountDivs[j].className = "";
 				}
			}	
		}	
	}

// --------------------------------------------
    // 广告滚播图
    var gunBox = document.getElementsByClassName('gun_box')[0];//轮播图的盒子
	var gunUl = gunBox.children[0];//ul
	var gunLis = gunUl.children;//5个图片
	var ol = gunBox.children[1];//指示器ol
	var firstLi = gunUl.children[0];//第一张图片
	var scrollWidth = gunBox.offsetWidth;//可视区域的宽度
	//2.1克隆元素 
	var newLi = firstLi.cloneNode(true);//深复制:标签和内容
	//2.2添加图片ul中 
	//此时ul中有了6张图片, 123451
	gunUl.appendChild(newLi);
	//2.3动态创建ol中的li,指示器
	//i 01234 5个
	//innerHTML 12345
	for(var i =0; i<gunLis.length-1;i++){
		var lili = document.createElement("li");
		// 指示器的数:1-5
		// lili.innerHTML = i+1;
		ol.appendChild(lili);
	}
	//3.焦点指示器 (指着它会有效果)
	var olLis = ol.children;//5个指示器
	//3.1第一个指示器使用current的样式
	olLis[0].className="current";
	//3.2循环给5个指示器添加事件
	for(var i=0;i<olLis.length; i++){
		//3.3给每个li添加属性,就是索引号 
		olLis[i].index = i;
		//3.4给每个li添加事件
		olLis[i].onmouseover=function(){
			//3.5让所有的li都没有样式 
			for(var j=0; j<olLis.length;j++){
				olLis[j].className="";
			}
			//3.6鼠标放在谁上面,那个span就有current这个样式
			this.className = "current";
			// //index 0-4 *490  
			// //0 490 980 1470 1960
			//3.7运动方法 (点击哪块哪块动 指示器 1-5)
			//当索引号为.index为0时,左边距离为0
			animate(gunUl,-this.index*scrollWidth);
		}
	}
	//4.自动轮播
	//自动轮播时,图片1-5, 指示器1-5
	//4.1定义自动轮播 
	var timer = null; //定时器 
	var key = 0 ;//控制图片
	var square = 0;//控制指示器
	//4.2设置定时器 setInterval(函数方法,时间间隔)
	timer = setInterval(autoPlay,2000);
	//4.3自动播放方法 
	function autoPlay(){
		//4.4自动轮播时,方向往右,	图片1-5;图片索引增大,指示器索引增大
		key++;
		square++;
		//4.5 图片索引 0 1 2 3 4
		//真正的图片ul 0 1 2 3 4 5(0)
		//               第五张图片--->第一张图片0
		//                        5(0)   6(1)
		//设置一个假效果,让5-1的切换自然一些.
		if(key>5){
			key=1;
			// 1 2 3 4 5(0) 0 , 由于设置了一个假效果,则1的左边为0px
			gunUl.style.left = 0+"px";
		}
		//4.6让图片动起来 (图片自动滚动)
		animate(gunUl,-key*scrollWidth);

		//4.7指示器的范围 (图片ul为6个,指示器ol为5个)
		//01234  5个
		//		0 
		//square>4
		square = square>olLis.length-1? 0 : square;
		//4.8指示器运动
		for(var j=0; j<olLis.length;j++){
				olLis[j].className="";
			}
			//4.9指示器下标 0--4
			olLis[square].className = "current";
	}
	//5鼠标移动到这个区域中
	gunBox.onmouseover = function(){
		//5.1当鼠标移动到轮播图区域时,自动轮播停,timer为定时器
		//清除定时器
		clearInterval(timer);
	}
	gunBox.onmouseout = function(){
		//5.2鼠标移出去,自动轮播就得开始 
		timer = setInterval(autoPlay,2000);
	}

// --------------------------------------------
// //封装好,运动函数 animate
	//obj  对象 
	//target  目标位置,让scrollLeft移动多少
	function animate (obj,target){
		clearInterval(obj.timer);
			// ul.style.left = -this.index*scrollWidth+"px";
			//从1-->5 left小
			//从5-->1 left变大
			//每次移动这个距离,张数*图片的宽度
			//3.1目标位置
			//3.2 速度正反
			var speed = obj.offsetLeft < target ? 15 : -15;
			obj.timer = setInterval(function(){
				//3.3应该运动的距离
				//   -1470 - 0 
				//   1470  1456 1472
				var result = target - obj.offsetLeft;
				// 0  -15px+
				obj.style.left = obj.offsetLeft + speed + "px";
				if(Math.abs(result)<=15){
					obj.style.left = target + "px";
					clearInterval(obj.timer);
				}
		},10);
	}

// --------------------------------------------
    // 酒店推荐tab切换
    var hotelTitle = document.getElementsByClassName('hotel_ul')[0];//标题的外壳
    var hotelLis = hotelTitle.getElementsByTagName("li");//指定的标题
    var hotelBox = document.getElementById('hotelBox');//特惠产品块
    var hotelDivs = hotelBox.getElementsByTagName('b');//指定的产品块
    //2循环遍历,遍历所有的li,绑定点击事件 
	for(var i=0; i<hotelLis.length; i++){
		hotelLis[i].onmouseover = function(){
		    //i = 0, lis[0] spans[0]
			//3.第二层循环,用来给li与span绑定类的
			//点击到哪一个,哪一个就具有类
			for(var j=0; j<hotelLis.length; j++){
				//4.this指向discountLis[i]
 				if(this == hotelLis[j]){
 					hotelLis[j].className = "hotel_seleted";
 					hotelDivs[j].className = "hotel_show";
 				}else{
 					hotelLis[j].className = "";
 					hotelDivs[j].className = "";
 				}
			}	
		}	
	}
    
// -------------------------------------------- 
    // 旅游攻略往上滑动的字
    var imgBig = document.getElementsByClassName('tu1');//大图
    var huaHeiBig = document.getElementsByClassName('hua_hei');//大黑色块
    var imgSmall = document.getElementsByClassName('li');//小图
    var huaHeiSmall = document.getElementsByClassName('hua_xiao');//小黑色块
    // 左边大图-------------
    for(let h = 0;h<imgBig.length;h++){
		imgBig[h].index = h;
		imgBig[h].onmousemove = function(){
			for(let j = 0;j<huaHeiBig.length;j++){
				huaHeiBig[j].style.top = '295px';
			}
			huaHeiBig[h].style.top = '273px';
			
		}
		imgBig[h].onmouseout = function(){
			huaHeiBig[h].style.top = '295px';
			
		}
	}
    //右边小图---------------
	for(let e = 0;e<imgSmall.length;e++){
		imgSmall[e].index = e;
		imgSmall[e].onmousemove = function(){
			for(let r = 0;r<huaHeiSmall.length;r++){
				huaHeiSmall[r].style.top = '135px';
			}
			huaHeiSmall[e].style.top = '86px';
			
		}
		imgSmall[e].onmouseout = function(){
			huaHeiSmall[e].style.top = '135px';
			
		}
	}
    
    // 旅游攻略tab切换============
    var strategyTitle = document.getElementsByClassName('strategy_ul')[0];//标题的外壳
    var strategyLis = strategyTitle.getElementsByTagName("li");//指定的标题
    var strategyBox = document.getElementsByClassName('strategy_box')[0];//特惠产品块
    var strategyDivs = strategyBox.getElementsByTagName('b');//指定的产品块
    //2循环遍历,遍历所有的li,绑定点击事件 
    console.log(strategyDivs);
	for(var i=0; i<strategyLis.length; i++){
		strategyLis[i].onmouseover = function(){
		    //i = 0, lis[0] spans[0]
			//3.第二层循环,用来给li与span绑定类的
			//点击到哪一个,哪一个就具有类
			for(var j=0; j<strategyLis.length; j++){
				//4.this指向discountLis[i]
 				if(this == strategyLis[j]){
 					strategyLis[j].className = "strategy_seleted";
 					strategyDivs[j].className = "strategy_show";
 				}else{
 					strategyLis[j].className = "";
 					strategyDivs[j].className = "";
 				}
			}	
		}	
	} 
// --------------------------------------------   
    // 骆驼书浮动黑块
    var fuTu = document.getElementsByClassName('fuTu');//小图
    var fuHei = document.getElementsByClassName('fuHei');//小黑色块
	for(let e = 0;e<fuTu.length;e++){
		fuTu[e].index = e;
		fuTu[e].onmousemove = function(){
			for(let r = 0;r<fuHei.length;r++){
				fuHei[r].style.display = 'none';
			}
			fuHei[e].style.display = 'block';
			
		}
		fuTu[e].onmouseout = function(){
			fuHei[e].style.display = 'none';
			
		}
	}
    
    // 骆驼书tab切换============
    var bookTitle = document.getElementsByClassName('book_ul')[0];//标题的外壳
    var bookLis = bookTitle.getElementsByTagName("li");//指定的标题
    var bookBox = document.getElementsByClassName('book_box')[0];//特惠产品块
    var bookDivs = bookBox.getElementsByTagName('li');//指定的产品块
    //2循环遍历,遍历所有的li,绑定点击事件 
    console.log(bookDivs);
	for(var i=0; i<bookLis.length; i++){
		bookLis[i].onmouseover = function(){
		    //i = 0, lis[0] spans[0]
			//3.第二层循环,用来给li与span绑定类的
			//点击到哪一个,哪一个就具有类
			for(var j=0; j<bookLis.length; j++){
				//4.this指向discountLis[i]
 				if(this == bookLis[j]){
 					bookLis[j].className = "book_seleted";
 					bookDivs[j].className = "book_show";
 				}else{
 					bookLis[j].className = "";
 					bookDivs[j].className = "";
 				}
			}	
		}	
	} 
// --------------------------------------------   
    //尾部关于我们定位
    var aboutWe = document.getElementById('aboutWe');//关于我们
    var tuWe = aboutWe.getElementsByTagName('i')//阿里图标
    var dinWe = document.getElementsByClassName('din_we')[0];//定位的效果盒子
    aboutWe.onmousemove = function(){
    	dinWe.style.display = 'block';
    	aboutWe.style.color = '#ff9ea2';
    	tuWe[0].className = "";
    	tuWe[1].className = "iconfont icon-arrow-left-copy";
    }
    aboutWe.onmouseout = function(){
    	dinWe.style.display = 'none';
    	aboutWe.style.color = '#999';
    	tuWe[0].className = "iconfont icon-down";
    	tuWe[1].className = "";
    }

  














}
  