window.onload = function () {
    
    //1.获取id
    function getId(id){
        return  document.getElementById(id);
    }
    //2.获取类名
    function getClass(cls){
        //找到所有的标签
        var elem = document.all?document.all:document.getElementsByTagName("*");
        //新建数组
        var arr = [];
        //遍历找到所有标签数组
        for(var i=0; i<elem.length;i++){
            //判断标签数组所有的元素的类名与传进来的参数cls是否相等
            if(elem[i].className==cls){
                //把具有这个类的元素放进arr数组
                arr.push(elem[i]);
            }
        }
        //把找到的数组传出去
        return arr;
    }
    //3.获取标签名
    function getEle(ele){
        return  document.getElementsByTagName(ele);
    }

// --------------------------------------------     // input输入框的效果:下拉城市
    var referInput = document.getElementsByClassName('refer_input_1')[0];//一个输入框盒子
    var ziInput = referInput.getElementsByTagName('p')[0];//输入城市名/车站名
    var input = referInput.getElementsByTagName('input')[0];//输入框
    var xiaInput= referInput.getElementsByClassName('input_1_xia')[0];//下拉框
    var riliInput = referInput.getElementsByTagName('i')[0];//日历
    input.onfocus = riliInput.onclick = function(){
    	ziInput.style.display = 'none';
    	input.style.border = '1px solid #3cb0d0';
    	input.style.borderBottom = 'none';
    	xiaInput.style.display = 'block';
    }
    input.onblur = riliInput.onclick = function(){
    	ziInput.style.display = 'block';
    	ziInput.style.color = '#ff0000';
    	xiaInput.style.display = 'none';
    }
    var referInput1 = document.getElementById('refer_input_2');//一个输入框盒子
    var ziInput1 = referInput1.getElementsByTagName('p')[0];//输入城市名/车站名
    var input1 = referInput1.getElementsByTagName('input')[0];//输入框
    var xiaInput1= referInput1.getElementsByClassName('input_1_xia')[0];//下拉框
    var riliInput1 = referInput1.getElementsByTagName('i')[0];//日历
    input1.onfocus = riliInput1.onclick = function(){
    	ziInput1.style.display = 'none';
    	ziInput1.style.color = '#ff0000';
    	input1.style.border = '1px solid #3cb0d0';
    	input1.style.borderBottom = 'none';
    	xiaInput1.style.display = 'block';
    }
    input1.onblur = riliInput1.onclick = function(){
    	ziInput1.style.display = 'block';
    	ziInput1.style.color = '#ff0000';
    	xiaInput1.style.display = 'none';
    }
    
 //---------------------------------------------------
	//换
	var huan = document.getElementById('huan');
	var referInputP = document.getElementsByClassName('refer_input_1')[0];//一个输入框盒子
	var inputP = referInput.getElementsByTagName('input')[0];//输入框
    var referInputP_1 = document.getElementById('refer_input_2');//一个输入框盒子
    var inputP_1 = referInput1.getElementsByTagName('input')[0];//输入框   
    var a = inputP.value;
    var b = inputP_1.value;
	huan.onclick = function(){
		inputP.value=[a,a=b][1];
	    inputP_1.value='上海';
	}

 //---------------------------------------------------
	//日期滚动条
	var zuoJian = document.getElementById('zuoJian');//左箭头
	var youJian = document.getElementById('youJian');//右箭头
	var weekUl = document.getElementById('youJian');//日期条
    var weekLis = weekUl.getElementsByTagName('li');//日期条
    var target = 0;//开始位置
    //3.点击左箭头
	zuoJian.onclick = function(){
		//3.1点一次就加490
		target+=115;
		if (target>=0) {
			target = 0;
		}
		animate(weekUl,target);
	}
	//4点击右边箭头
	//target 0, -490 , -980, -1470, -1960
	youJian.onclick = function(){
		//4.1点一次就减490,就往左移动一张图片的位置
		target -=115;
		//4.2进行判断范围 
		//targte<=-1960
		if(target<=-(weekLis.length-1)*115){
			target = -(weekLis.length-1)*115;
		}
		animate(weekUl,target);
	}

// --------------------------------------------
    // 周边游tab切换
    var weekTitle = document.getElementById('weekUl');//标题的外壳
    var weekLis = weekTitle.getElementsByTagName("li");//指定的标题
    //2循环遍历,遍历所有的li,绑定点击事件 
    console.log(weekLis);
	for(var i=0; i<weekLis.length; i++){
		weekLis[i].onclick = function(){
			//4.this指向tourLis[i]
			if(this == weekLis[i]){
				weekLis[i].className = "week_selected";
			}else{
				weekLis[i].className = "";
			}	
		}	
	}
// --------------------------------------------
	// 多选框
	var checkedBox = document.getElementsByClassName('go_time')[0];//一条多选的box
	var limited = checkedBox.getElementsByClassName('limited')[0];//不限
    var checked = checkedBox.getElementsByTagName('input');
    console.log(checked);
    checked[0].onclick = function(){
    	limited.style.color = "#0883bc";
    	limited.style.background = "#fff";
    	checked[0].onclick = function(){
	    	limited.style.color = "#fff";
	    	limited.style.background = "#3cb0d0";
	    }
    }
	     
// --------------------------------------------
    // 排序
    var startTime = document.getElementsByClassName('start_time')[0];//发车时间dl
    var timeArr = startTime.getElementsByTagName('dd');//时间数组
    // var a = timeArr[0].innerText;
    // var b = timeArr[1].innerText;
    // var c = timeArr[2].innerText;
    // var array = [a,b,c];
    var topArrow = document.getElementById('topArrow');//上箭头
    var botArrow = document.getElementById('botArrow');//下箭头
    // console.log(array);
// var array=[1,80,4,33,21,55];
        // array.sort(function (x,y) {
        //     return x-y;
        // });
        // console.log(array);
// var array=[1,80,4,33,21,55];
//         array.sort(function (x,y) {
//             return y-x;
//         });
//         document.writeln(array);
// --------------------------------------------
    // 更多热门
    var routeMore = document.getElementsByClassName('route_more')[0];
    var routeHidden = document.getElementsByClassName('route_hidden')[0];
    var routeI = routeMore.getElementsByTagName('i');
    routeMore.onclick = function(){
    	routeHidden.style.display= 'block';
    	routeI[0].className = '';
    	routeI[1].className = 'iconfont icon-jiantou-copy';
    	routeMore.onclick = function(){
	    	routeHidden.style.display= 'none';
	    	routeI[0].className = 'iconfont icon-doubleJT-down';
	    	routeI[1].className = '';
	    }
    }

    var routeMore1 = document.getElementsByClassName('route_more')[1];
    var routeHidden1 = document.getElementsByClassName('route_hidden')[1];
    var routeI1 = routeMore1.getElementsByTagName('i');
    routeMore1.onclick = function(){
    	routeHidden1.style.display= 'block';
    	routeI[0].className = '';
    	routeI[1].className = 'iconfont icon-jiantou-copy';
    	routeMore1.onclick = function(){
	    	routeHidden1.style.display= 'none';
	    	routeI[0].className = 'iconfont icon-doubleJT-down';
	    	routeI[1].className = '';
	    }
    }
    
// --------------------------------------------   
    //尾部关于我们定位
    var aboutWe = document.getElementById('aboutWe');//关于我们
    var tuWe = aboutWe.getElementsByTagName('i')//阿里图标
    var dinWe = document.getElementsByClassName('din_we')[0];//定位的效果盒子
    aboutWe.onmousemove = function(){
    	dinWe.style.display = 'block';
    	aboutWe.style.color = '#ff9ea2';
    	tuWe[0].className = "";
    	tuWe[1].className = "iconfont icon-arrow-left-copy";
    }
    aboutWe.onmouseout = function(){
    	dinWe.style.display = 'none';
    	aboutWe.style.color = '#999';
    	tuWe[0].className = "iconfont icon-down";
    	tuWe[1].className = "";
    }
























}






