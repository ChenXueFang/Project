window.onload = function () {
	//1.获取id
    function getId(id){
        return  document.getElementById(id);
    }
    //2.获取类名
    function getClass(cls){
        //找到所有的标签
        var elem = document.all?document.all:document.getElementsByTagName("*");
        //新建数组
        var arr = [];
        //遍历找到所有标签数组
        for(var i=0; i<elem.length;i++){
            //判断标签数组所有的元素的类名与传进来的参数cls是否相等
            if(elem[i].className==cls){
                //把具有这个类的元素放进arr数组
                arr.push(elem[i]);
            }
        }
        //把找到的数组传出去
        return arr;
    }
    //3.获取标签名
    function getEle(ele){
        return  document.getElementsByTagName(ele);
    }

// --------------------------------------------     
    // 查看订单
	var orderXia = document.getElementById('orderXia');//订单下效果块
	var orderA = document.getElementById('orderA');//a链接改变字体颜色
	var orderli = document.getElementsByClassName('order')[0];//查看订单的li标签
	var orderTu = orderli.getElementsByTagName('i');
	orderTu[0].onmouseover = orderXia.onmouseover = function(){
		orderXia.style.display="block";
		orderA.style.color = "#00a3d2";
		orderTu[1].style.color = "#00a3d2";
		orderTu[0].className = "";
    	orderTu[1].className = "iconfont icon-arrow-left-copy";
	}
	orderXia.onmouseout = function(){
		orderXia.style.display="none";
        orderA.style.color = "#666";
        orderTu[1].style.color = "#666";
        orderTu[0].className = "iconfont icon-down";
    	orderTu[1].className = "";
	}
 
 // --------------------------------------------   
    // 团购
    var nav = document.getElementById('nav');
    shopping = nav.children[3];
    var shoppingXia = document.getElementById('shoppingXia');
    var A = shopping.children[0];
    shopping.onmouseover = shoppingXia.onmouseover = function(){
		shoppingXia.style.display="block";
		shopping.style.borderLeft = "1px solid #ccc";
		shopping.style.borderRight = "1px solid #ccc";
		shopping.style.boxShadow = "#e6e6e6 0 15px 30px 0px";
		A.style.color = "#00a3d2";
	}
	shoppingXia.onmouseout = shopping.onmouseout = function(){
		shoppingXia.style.display="none";
		shopping.style.borderLeft = "none";
		shopping.style.borderRight = "none";
		shopping.style.boxShadow = "none";
		A.style.color = "#666";
	}
	// 金融
    var moneyXia = document.getElementById('moneyXia');//金融的下拉效果dl
    money = nav.children[14];//第15个li金融
    var B = money.children[0];//li的第一个孩子a标签"金融"两个字
	money.onmouseover = moneyXia.onmouseover = function(){
		moneyXia.style.display="block";
		money.style.borderLeft = "1px solid #ccc";
		money.style.borderRight = "1px solid #ccc";
		money.style.boxShadow = "#e6e6e6 0 15px 30px 0px";
		B.style.color = "#00a3d2";
	}
	moneyXia.onmouseout = money.onmouseout =function(){
		moneyXia.style.display="none";
		money.style.borderLeft = "none";
		money.style.borderRight = "none";
		money.style.boxShadow = "none";
		B.style.color = "#666";
	}
	// 门票
    var piaoXia = document.getElementById('piaoXia');//金融的下拉效果dl
    piao = nav.children[6];//第15个li金融
    var C = piao.children[0];//li的第一个孩子a标签"金融"两个字
	piao.onmouseover = piao.onmouseover = function(){
		piaoXia.style.display="block";
		piao.style.borderLeft = "1px solid #ccc";
		piao.style.borderRight = "1px solid #ccc";
		piao.style.boxShadow = "#e6e6e6 0 15px 30px 0px";
		C.style.color = "#00a3d2";
	}
	piaoXia.onmouseout = piao.onmouseout =function(){
		piaoXia.style.display="none";
		piao.style.borderLeft = "none";
		piao.style.borderRight = "none";
		piao.style.boxShadow = "none";
		C.style.color = "#666";
	}
	// 车车
    var carXia = document.getElementById('carXia');//金融的下拉效果dl
    car = nav.children[10];//第15个li金融
    var D = car.children[0];//li的第一个孩子a标签"金融"两个字
	car.onmouseover = car.onmouseover = function(){
		carXia.style.display="block";
		car.style.borderLeft = "1px solid #ccc";
		car.style.borderRight = "1px solid #ccc";
		car.style.boxShadow = "#e6e6e6 0 15px 30px 0px";
		D.style.color = "#00a3d2";
	}
	carXia.onmouseout = car.onmouseout =function(){
		carXia.style.display="none";
		car.style.borderLeft = "none";
		car.style.borderRight = "none";
		car.style.boxShadow = "none";
		D.style.color = "#666";
	}
//==================================
    // input输入框的效果:下拉城市
    var referInput = document.getElementsByClassName('refer_input_1')[0];//一个输入框盒子
    var ziInput = referInput.getElementsByTagName('p')[0];//输入城市名/车站名
    var input = referInput.getElementsByTagName('input')[0];//输入框
    var xiaInput= referInput.getElementsByClassName('input_1_xia')[0];//下拉框
    var riliInput = referInput.getElementsByTagName('i')[0];//日历
    input.onfocus = riliInput.onclick = function(){
    	ziInput.style.display = 'none';
    	input.style.border = '1px solid #3cb0d0';
    	input.style.borderBottom = 'none';
    	xiaInput.style.display = 'block';
    }
    input.onblur = riliInput.onclick = function(){
    	ziInput.style.display = 'block';
    	ziInput.style.color = '#ff0000';
    	input.style.border = '1px solid #ff0000';
    	xiaInput.style.display = 'none';
    }
    var referInput1 = document.getElementById('refer_input_2');//一个输入框盒子
    var ziInput1 = referInput1.getElementsByTagName('p')[0];//输入城市名/车站名
    var input1 = referInput1.getElementsByTagName('input')[0];//输入框
    var xiaInput1= referInput1.getElementsByClassName('input_1_xia')[0];//下拉框
    var riliInput1 = referInput1.getElementsByTagName('i')[0];//日历
    input1.onfocus = riliInput1.onclick = function(){
    	ziInput1.style.display = 'none';
    	ziInput1.style.color = '#ff0000';
    	input1.style.border = '1px solid #3cb0d0';
    	input1.style.borderBottom = 'none';
    	xiaInput1.style.display = 'block';
    }
    input1.onblur = riliInput1.onclick = function(){
    	ziInput1.style.display = 'block';
    	ziInput1.style.color = '#ff0000';
    	input1.style.border = '1px solid #ff0000';
    	xiaInput1.style.display = 'none';
    }
    
 //---------------------------------------------------
    // 周边游tab切换
    var tourTitle = document.getElementsByClassName('tour_title')[0];//标题的外壳
    var tourLis = tourTitle.getElementsByTagName("li");//指定的标题
    var tourBox = document.getElementsByClassName('tour_box')[0];//特惠产品块
    var tourDivs = tourBox.getElementsByTagName("ul");//指定的产品块
    //2循环遍历,遍历所有的li,绑定点击事件 
	for(var i=0; i<tourLis.length; i++){
		tourLis[i].onclick = function(){
		    //i = 0, lis[0] spans[0]
			//3.第二层循环,用来给li与span绑定类的
			//点击到哪一个,哪一个就具有类
			for(var j=0; j<tourLis.length; j++){
				//4.this指向tourLis[i]
 				if(this == tourLis[j]){
 					tourLis[j].className = "tour_selected";
 					tourDivs[j].className = "tour_show";
 				}else{
 					tourLis[j].className = "";
 					tourDivs[j].className = "";
 				}
			}	
		}	
	}

//---------------------------------------------------
    // 更多热门
    var routeMore = document.getElementsByClassName('route_more')[0];
    var routeHidden = document.getElementsByClassName('route_hidden')[0];
    var routeI = routeMore.getElementsByTagName('i');
    routeMore.onclick = function(){
    	routeHidden.style.display= 'block';
    	routeI[0].className = '';
    	routeI[1].className = 'iconfont icon-jiantou-copy';
    	routeMore.onclick = function(){
	    	routeHidden.style.display= 'none';
	    	routeI[0].className = 'iconfont icon-doubleJT-down';
	    	routeI[1].className = '';
	    }
    }

    var routeMore1 = document.getElementsByClassName('route_more')[1];
    var routeHidden1 = document.getElementsByClassName('route_hidden')[1];
    var routeI1 = routeMore1.getElementsByTagName('i');
    routeMore1.onclick = function(){
    	routeHidden1.style.display= 'block';
    	routeI[0].className = '';
    	routeI[1].className = 'iconfont icon-jiantou-copy';
    	routeMore1.onclick = function(){
	    	routeHidden1.style.display= 'none';
	    	routeI[0].className = 'iconfont icon-doubleJT-down';
	    	routeI[1].className = '';
	    }
    }
    
    var routeMore2 = document.getElementsByClassName('route_more')[2];
    var routeHidden2 = document.getElementsByClassName('route_hidden')[2];
    var routeI2 = routeMore2.getElementsByTagName('i');
    routeMore2.onclick = function(){
    	routeHidden2.style.display= 'block';
    	routeI[0].className = '';
    	routeI[1].className = 'iconfont icon-jiantou-copy';
    	routeMore2.onclick = function(){
	    	routeHidden2.style.display= 'none';
	    	routeI[0].className = 'iconfont icon-doubleJT-down';
	    	routeI[1].className = '';
	    }
    }

    var routeMore3 = document.getElementsByClassName('route_more')[3];
    var routeHidden3 = document.getElementsByClassName('route_hidden')[3];
    var routeI3 = routeMore.getElementsByTagName('i');
    routeMore3.onclick = function(){
    	routeHidden3.style.display= 'block';
    	routeI[0].className = '';
    	routeI[1].className = 'iconfont icon-jiantou-copy';
    	routeMore3.onclick = function(){
	    	routeHidden3.style.display= 'none';
	    	routeI[0].className = 'iconfont icon-doubleJT-down';
	    	routeI[1].className = '';
	    }
    }

// --------------------------------------------   
    //尾部关于我们定位
    var aboutWe = document.getElementById('aboutWe');//关于我们
    var tuWe = aboutWe.getElementsByTagName('i')//阿里图标
    var dinWe = document.getElementsByClassName('din_we')[0];//定位的效果盒子
    aboutWe.onmousemove = function(){
    	dinWe.style.display = 'block';
    	aboutWe.style.color = '#ff9ea2';
    	tuWe[0].className = "";
    	tuWe[1].className = "iconfont icon-arrow-left-copy";
    }
    aboutWe.onmouseout = function(){
    	dinWe.style.display = 'none';
    	aboutWe.style.color = '#999';
    	tuWe[0].className = "iconfont icon-down";
    	tuWe[1].className = "";
    }

    











































































}