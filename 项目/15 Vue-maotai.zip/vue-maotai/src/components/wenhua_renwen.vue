<template>
    <h1>人文茅台</h1>
</template>

<script>
    export default {
        name: "wenhua_renwen.vue"
    }
</script>

<style scoped>

</style>
