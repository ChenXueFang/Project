<template>
  <h1>领导介绍</h1>
</template>

<script>
    export default {
        name: "lingdao.vue"
    }
</script>

<style scoped>

</style>
