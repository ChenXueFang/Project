<template>
    <h1>酒之博览</h1>
</template>

<script>
    export default {
        name: "jiu.vue"
    }
</script>

<style scoped>

</style>
