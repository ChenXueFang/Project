<template>
    <h1>媒体聚焦</h1>
</template>

<script>
    export default {
        name: "news_meiti.vue"
    }
</script>

<style scoped>

</style>
