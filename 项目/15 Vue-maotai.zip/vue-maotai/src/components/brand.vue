<template>
    <h1>brand</h1>
</template>

<script>
    export default {
        name: "brand.vue"
    }
</script>

<style scoped>

</style>
