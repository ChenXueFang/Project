<template>
    <h1>茅台商城</h1>
</template>

<script>
    export default {
        name: "city.vue"
    }
</script>

<style scoped>

</style>
