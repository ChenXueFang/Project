<template>
  <div class="main_right">
    <!--右头-->
    <div class="right_title">
      <div class="title_a">
        <router-link class="link" to="/">首页</router-link> <span class="el-icon-arrow-right"></span>
        <router-link class="link" to="/go">走进茅台</router-link> <span class="el-icon-arrow-right"></span>
        <router-link class="link" to="/go/jituan">集团介绍</router-link> <span class="el-icon-arrow-right"></span>
      </div>
      <h2>中国贵州茅台酒厂（集团）有限责任公司简介</h2>
    </div>
    <!--内容-->
    <div class="right_con">
      <p class="con_p">
        <b>中国贵州茅台酒厂（集团）有限责任公司：</b>
        <br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;中国贵州茅台酒厂(集团)有限责任公司(以下简称茅台集团)是国家特大型国有企业，总部位于贵州遵义市茅台镇，平均海拔 423 米，占地约1.5万亩，其中茅台酒地理标志产品保护地域面积为15.03平方公里，员工3.6万余人。
      　　<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;茅台集团以贵州茅台酒股份有限公司为核心企业，涉足产业包括白酒、保健酒、葡萄酒、金融、文化旅游、教育、酒店、房地产及白酒上下游等。主导产品贵州茅台酒历史悠久、源远流长，具有深厚的文化内涵，1915 年荣获巴拿马万国博览会金奖，与法国科涅克白兰地、英国苏格兰威士忌一起并称“世界三大（蒸馏）名酒”，被誉为“国酒”，是我国大曲酱香型白酒的鼻祖和典型代表，是绿色食品、有机食品、地理标志产品，其酿制技艺入选国家首批非物质文化遗产代表作名录，是一张香飘世界的“国家名片”。
      　　<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;目前，茅台集团拥有中国白酒大师3人、中国酿酒大师5人、中国首席白酒品酒师7人、中国白酒工艺大师3人、国家级白酒评委26人，处于行业领先水平。
      　　<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;党的十八大以来，在党中央、国务院和贵州省委、省政府一系列重大决策部署的有力地推动下，茅台集团坚持稳中求进和高质量发展要求，紧紧围绕“做足酒文章、扩大酒天地”，深耕精耕市场、持续优化服务，扎实推进改革创新、转型发展，切实推动企业抗风险能力、竞争能力、发展后劲、综合实力大大增强，走上了更加良性的发展轨道，步入了新的上升发展周期。2018年，茅台集团完成营业收入859亿元，同比增长29.5%;增加值856亿元，同比增长28.9%；净利润396亿元，同比增长28.2%；实现税收380亿元，同比增长32.1%。
      　　<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;从行业看，2018年，茅台酒单品销售额稳居全球蒸馏酒业第一，茅台营收、净利润、股票市值稳居国内酒业第一，净利润、市值位居全球蒸馏酒业第一。
      　　<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;从品牌看，自2013年来，茅台5次入选“BrandZ全球最具价值品牌100强”，2018年位居榜单第34位，位列全球酒类品牌价值第一；自2015年来，连续三年位居“全球烈酒品牌价值50强”榜首；连续8年稳居“华樽杯”酒类企业200强榜首，习酒首进前十、位列第九。
      　　<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;从贡献看，茅台是一家有担当、负责任的企业。自2012年起，每年捐资1亿元，连续7年捐资7亿元，帮助14万名贫困学子圆梦大学。自2014年起，每年安排专项资金5000万元，连续10年安排资金5亿元，参与赤水河流域生态保护和环境治理。自2001年上市以来，贵州茅台酒股份公司坚持分红、回馈股东，累计现金分红超过500亿元。
      　　<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;当前和今后一个时期，茅台集团将以习近平新时代中国特色社会主义思想为指导，深入学习贯彻党的十九大精神，认真贯彻贵州省委、省政府决策部署，坚持稳中求进工作总基调和高质量发展新理念，以供给侧结构性改革为主线，切实做好“做足酒文章、扩大酒天地”这篇大文章，全力推动茅台发展再上新台阶，努力把茅台打造成为受人尊敬的世界企业。
      </p>
      <div class="con_pic">
        <p class="con_p_pic">
          <b>厂旗的寓意：</b>
          <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;形意上：三条曲线—寓意有机茅台、科技茅台、人文茅台；中部弧线—表现川流不息、源远流长的赤水河是企业的源泉，也寓意企业如同赤水河一浪推动一浪，一浪更比一浪高。
          　　色意上：黄色—是身份与地位的象征，是茅台特有的文化、特有的历史、特有的品质、特有的地位和“人文茅台”所特有的整合价值。绿色—是企业“绿色时代”造就的结晶体“绿色茅台”和“有机茅台”。银灰色—象征企业融合传统工艺与现代科技，不断探索、研究、开发、实施“科技茅台”战略。
        </p>
        <img src="./img/jituan1.jpg" width="200px" height="131px">
      </div>
      <div class="con_pic con_pic2">
        <p class="con_p_pic">
          <b>企徽标识释义：</b>
          <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;在形态上为椭圆图形，由GJMT 四个字母组合而成，寓意“贵州茅台集团”，其中，G 代表“贵州”，J 代表“集团”，MT 代表“茅台”。整个图案外圈为红色，象征团结、开拓、奋进。图案内部是“MT”两个字母构成的蓝色酒樽造型，蓝色代表茅台博大精深的国酒文化，酒樽造型揭示茅台集团的主业是白酒，同时也寓意着茅台始终处于集团的核心位置，所有集团成员紧密团结在茅台周围。整个图案简洁流畅，整体象征着茅台的国酒地位永不动摇。
        </p>
        <img src="./img/jituan2.gif" height="110px" width="180px">
      </div>

    </div>
  </div>
</template>

<script>
    export default {
        name: "jituan.vue"
    }
</script>

<style scoped>
  /*主体右*/
  .main_right{
    border: 1px solid #c4bbb6;
    border-radius: 5px;
  }
  /*右头*/
  .right_title{
    color: #666;
    height: 100px;
    margin: 0;
    background: linear-gradient(#d8d8d8,#fff);
  }
  .right_title>h2{
    margin-top: 5px;
  }
  .title_a{
    text-align: left;
  }
  .title_a .link{
    color: #444444;
    text-decoration: none;
  }
  .title_a .link:hover{
    color: red;
  }
  /*右内容*/
  .right_con{
    padding: 20px 80px;
    text-align: left;
    background: #f3f3f3;
  }
  .con_p{
    margin-top: -15px;
    margin-bottom: 50px;
    padding-top: 50px;
    border-top: 1px dotted #c5bdba;
    font-size: 15px;
    line-height: 25px;
  }
  /*文字及图*/
  .con_pic{
    font-size: 15px;
    line-height: 25px;
    display: flex;
    justify-content: space-between;
    margin-bottom: 50px;
  }
  .con_pic img{
    margin-top: 40px;
    margin-left: 10px;
  }
  /*第二个图文*/
  .con_pic2{
    border-bottom: 1px dotted #c5bdba;
    padding-bottom: 50px;
    margin-bottom: 30px;
  }
</style>
