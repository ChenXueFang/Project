<template>
    <h1>社会责任</h1>
</template>

<script>
    export default {
        name: "shehui.vue"
    }
</script>

<style scoped>

</style>
