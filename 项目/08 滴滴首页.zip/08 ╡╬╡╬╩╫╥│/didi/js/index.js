window.onload=function(){
	//新闻轮播图
	var flashBox = getClass("flashBox")[0];
	var aArr = flashBox.getElementsByTagName("a");
//	console.log(aArr);
	var timer = null;//定时器 
	var num = 0;//控制下标
	timer = setInterval(rightFn,1000);
	function rightFn(){
		//3.3往右 num增加 
		num++;
		//3.4底线 
		//0 1 2 3
		//num>3
		if (num>aArr.length-1) {
			num=0;
		}
		// 3.1取消所有a的类与li的类
		for(var i=0; i<aArr.length; i++){
			aArr[i].className = "";
		}
		//3.2当前的num下标的a与li具有样式
		aArr[num].className = "show";
	}
	
//--------------------------------------------
    //资料库轮播图
    var ziBox = getClass("ciecle_gun");//轮播图盒子
    var ziUl = getId("gunC_box");//装图片的ul
    var ziLis = ziUl.children;//4个图片
	var arrLeft = getId("left");//左箭头
	var arrRight = getId("right");//左箭头
	var ol = getId("zi_ol");//数字指示器ol
	var target=0 , n=1;//target目标位置
	arrRight.onclick=function(){
//		console.log(ziUl.offsetLeft);
		n++;
		if(n>4){
			n=4;
		}
		if(ziUl.offsetLeft<-990){
			target=-990;
		}
		target -= 495;
		animate(ziUl,target);
		ol.innerHTML="0"+n;
	}
	arrLeft.onclick = function () {
		n--;
		if(n<1){
			n=1;
		}
		target += 495;
		if(target>=0){
			target =0;
		}
		animate(ziUl,target);
		ol.innerHTML="0"+n;
	}
//	// 封装滚动方法
	function animate(obj,target) {
		clearInterval(obj.timer)
		var speed = obj.offsetLeft < target ? 10 : -10;
		obj.timer = setInterval(function () {
			var result = target - obj.offsetLeft;
			obj.style.left = obj.offsetLeft + speed + "px";
			if(Math.abs(result) <= 10 ){
				clearInterval(obj.timer);
				obj.style.left = target + "px";
			}
		},1);
	}

//--------------------------------------------
	//更多业务轮播图
	var optionBox = getId("optionG_box");//装图片的ul
    var optionUl = getId("optionUl");//装图片的ul
    var optionLis = optionUl.children;//4个图片
    var firstLi = optionUl.children[0];
    var newLi = firstLi.cloneNode(true);
    optionUl.appendChild(newLi);
    var scrollWidth = optionBox.offsetWidth;//可视区域的宽度
	var leftOption = getId("left_option");//左箭头
	var rightOption = getId("right_option");//左箭头
	var colorCircle = getId("colorCircle");//颜色圆
	var key = 0;//控制图片
	var n = 1;
//	console.log(rightOption);
	function autoPlay(){
		n++
		if(n>7){
			n=1;
		}
        key++;
        if(key>7){
         	key=1;
            optionUl.style.left = 0+ 'px';
        }
        animate(optionUl,-key*scrollWidth);
        colorCircle.className="color"+n;
    }        
	leftOption.onclick = function () {
        autoPlay();
    }
	rightOption.onclick = function () {
            n--;
			if(n<1){
				n=7;
			}
           key--;
            if(key<0){
                key=6;
                optionUl.style.left = -7*scrollWidth+ 'px';
            }
            animate(optionUl,-key*scrollWidth);
            colorCircle.className="color"+n;
    }
	
//----------------------------------------------------------
	//滴滴科技蒙版,阴影效果
	var scienceBox = getId("science_box");//装图的盒子ul
	var scienceLis = scienceBox.children;//三张图片
	var scienceHei = getClass("scienceHei");//三个蒙版
	//阴影
	for(var i=0; i<scienceLis.length; i++){
		scienceLis[i].onmouseover = function(){
			this.style.boxShadow = "#d1d1d1 0px 30px 30px 5px";
		}
		scienceLis[i].onmouseout = function(){
			this.style.boxShadow = "none";
		}
	}
	//蒙版
	for(var j=0; j<scienceHei.length; j++){
		scienceHei[j].onmouseover = function(){
			this.style.opacity = "0";
		}
		scienceHei[j].onmouseout = function(){
			this.style.opacity = "0.5";
		}
	}

//------------------------------------------------
	//社会价值轮播图
    var valueUl = getId("value_box");//装图片的ul
    var valueLis = valueUl.children;//4个图片
	var leftValue = getClass("value_left")[0];//左箭头
	var rightValue = getClass("value_right")[0];//左箭头
	var olValue = getClass("value_ol")[0];//数字指示器ol
	
	var mask = getClass("mask");//放大镜
	var oBigDiv = getClass("bigBox")[0];//放大图的盒子
	var oBigImg = getClass("bigImg")[0];//大图
	var value_Zi = getClass("value_Zi");//字
	
	var target= -54, n=1;//target目标位置
	rightValue.onclick=function(){
		console.log(valueUl.offsetLeft);
		n++;
		if(n>4){
			n=4;
		}
		if(valueUl.offsetLeft<-1367){
			target=-1367;
		}
		target -= 656;//图片的大小加图片之间的距离
		animate(valueUl,target);
		olValue.innerHTML="0"+n;
	}
	leftValue.onclick = function () {
		n--;
		if(n<1){
			n=1;
		}
		target += 656;
		if(target>=0){
			target =-54;
		}
		animate(valueUl,target);
		olValue.innerHTML="0"+n;
	}
	console.log(valueLis);
	//社会价值放大镜
	for(var i=0;i<valueLis.length;i++){
		valueLis[i].index=i;
		valueLis[i].onmouseenter=function(){
		mask[this.index].style.display="block";
		value_Zi[this.index].style.display="none";
		}
		valueLis[i].onmouseleave=function(){
		mask[this.index].style.display="none";
		value_Zi[this.index].style.display="block";
		}
	}

	valueLis[0].onmousemove=function(event){
		event = event || window.event;
	    var pagex = event.pageX || scroll().left + event.clientX;
//	    console.log(pagex);
	    var pagey = event.pageY || scroll().top + event.clientY;
	    console.log(pagey);
		var x = pagex -404 -50 - valueUl.offsetLeft - mask[0].offsetWidth/2;
//		console.log(x);
	    var y = pagey - 4153+50 - mask[0].offsetWidth/2;
	    console.log(y);
		// console.log(pagex); //560开始
		// console.log(pagey); //6008开始
		console.log(valueUl.offsetLeft);
		// console.log(y);
		mask[0].style.left = x + "px";
		mask[0].style.top = y + "px";
		mask[0].style.backgroundPosition = -x+"px "+-y+"px";
		if(pagex<461 + valueUl.offsetLeft){
	        mask[0].style.display="none";
	    }
		if(pagex>461 + valueUl.offsetLeft+valueLis[0].offsetWidth){
		    mask[0].style.display="none";
		}
		if(pagey<4102){
		    mask[0].style.display="none";
		}
		if(pagey>4102+valueLis[0].offsetHeight){
		    mask[0].style.display="none";
		}
	}
	valueLis[1].onmousemove=function(event){
		event = event || window.event;
	    var pagex = event.pageX || scroll().left + event.clientX;
//	    console.log(pagex);
	    var pagey = event.pageY || scroll().top + event.clientY;
	    console.log(pagey);
		var x = pagex -1064 -50 - valueUl.offsetLeft - mask[1].offsetWidth/2;
//		console.log(x);
	    var y = pagey - 4153+50 - mask[1].offsetWidth/2;
	    console.log(y);
		// console.log(pagex); //560开始
		// console.log(pagey); //6008开始
		console.log(valueUl.offsetLeft);
		// console.log(y);
		mask[1].style.left = x + "px";
		mask[1].style.top = y + "px";
		mask[1].style.backgroundPosition = -x+"px "+-y+"px";
		if(pagex<1117 + valueUl.offsetLeft){
	        mask[1].style.display="none";
	    }
		if(pagex>1117 + valueUl.offsetLeft+valueLis[1].offsetWidth){
		    mask[1].style.display="none";
		}
		if(pagey<4102){
		    mask[1].style.display="none";
		}
		if(pagey>4102+valueLis[1].offsetHeight){
		    mask[1].style.display="none";
		}
	}
	valueLis[2].onmousemove=function(event){
		event = event || window.event;
	    var pagex = event.pageX || scroll().left + event.clientX;
//	    console.log(pagex);
	    var pagey = event.pageY || scroll().top + event.clientY;
	    console.log(pagey);
		var x = pagex -1716 -50 - valueUl.offsetLeft - mask[2].offsetWidth/2;
//		console.log(x);
	    var y = pagey - 4153+50 - mask[2].offsetWidth/2;
	    console.log(y);
		// console.log(pagex); //560开始
		// console.log(pagey); //6008开始
		console.log(valueUl.offsetLeft);
		// console.log(y);
		mask[2].style.left = x + "px";
		mask[2].style.top = y + "px";
		mask[2].style.backgroundPosition = -x+"px "+-y+"px";
		if(pagex<1773 + valueUl.offsetLeft){
	        mask[2].style.display="none";
	    }
		if(pagex>1773 + valueUl.offsetLeft+valueLis[2].offsetWidth){
		    mask[2].style.display="none";
		}
		if(pagey<4102){
		    mask[2].style.display="none";
		}
		if(pagey>4102+valueLis[2].offsetHeight){
		    mask[2].style.display="none";
		}
	}
	console.log(mask[2].offsetWidth);
	valueLis[3].onmousemove=function(event){
		event = event || window.event;
	    var pagex = event.pageX || scroll().left + event.clientX;
//	    console.log(pagex);
	    var pagey = event.pageY || scroll().top + event.clientY;
	    console.log(pagey);
		var x = pagex -2372 -50 - valueUl.offsetLeft - mask[2].offsetWidth/2;
//		console.log(x);
	    var y = pagey - 4153+50 - mask[3].offsetWidth/2;
	    console.log(y);
		// console.log(pagex); //560开始
		// console.log(pagey); //6008开始
		console.log(valueUl.offsetLeft);
		// console.log(y);
		mask[3].style.left = x + "px";
		mask[3].style.top = y + "px";
		mask[3].style.backgroundPosition = -x+"px "+-y+"px";
		if(pagex<2429 + valueUl.offsetLeft){
	        mask[3].style.display="none";
	    }
		if(pagex>2429 + valueUl.offsetLeft+valueLis[3].offsetWidth){
		    mask[3].style.display="none";
		}
		if(pagey<4102){
		    mask[3].style.display="none";
		}
		if(pagey>4102+valueLis[3].offsetHeight){
		    mask[3].style.display="none";
		}
	}
	
//------------------------------------
	//尾部蒙版
	var footerHei = getClass("footerHei");//三个二维码
	console.log(footerHei);
	for(var j=0; j<footerHei.length; j++){
		footerHei[j].onmouseover = function(){
			this.style.opacity = "0";
		}
		footerHei[j].onmouseout = function(){
			this.style.opacity = "0.7";
		}
	}

//------------------------------------
	//尾部出行服务下拉块
	var scope = getId("scope");//出行服务
	var scopeXia = getId("scopeXia");//出行服务下拉块
	scope.onmousemove = scopeXia.onmousemove = function(){
		scopeXia.style.height = "269px";
//		scopeXia.style.display = "block";
	}
	scope.onmouseout = scopeXia.onmouseout = function(){
		scopeXia.style.height = "0px";
//		scopeXia.style.display = "none";
	}
	
//--------------------------------------------------------
	//箭头楼层跳跃
	var arrowTiao = getId("arrow_tiao");//跳跃的箭头
	var floorArr = getClass("floor");//楼层
	var target = 0;
    var leader = 0;
    var timer = null;
    arrowTiao.onclick = console.log("4444");
	arrowTiao.onclick = function () {
		if(document.documentElement.scrollTop<650){
			z=0;
		}else if(document.documentElement.scrollTop<650*2){
			z=1;
		}else if(document.documentElement.scrollTop<650*3){
			z=2;
		}else if(document.documentElement.scrollTop<650*4){
			z=3;
		}else if(document.documentElement.scrollTop<650*5){
			z=4;
		}else if(document.documentElement.scrollTop<650*6){
			z=5;
		}else if(document.documentElement.scrollTop<650*7){
			z=6;
		}else if(document.documentElement.scrollTop<650*8){
			z=7;
		}else if(document.documentElement.scrollTop<650*9){
			z=8;
		}
	    z++;
		console.log(z);
		console.log(document.documentElement.scrollTop);
		if(z>6){
			z=7;
		}
		for(var i=0;i<floorArr.length;i++){
			floorArr[i].style.color="#8f8f8f";
		}
		down_target=floorArr[z].offsetTop; //console.log(down_target);
	                //要用定时器，先清除定时器
	    clearInterval(timer);
	                //3.利用缓动动画原理实现屏幕滑动
	    timerDown = setInterval(function () {
	                    //(1).获取步长
			var step = (down_target-leader)/10;
	                    //(2).二次处理步长
			step = step>0?Math.ceil(step):Math.floor(step);
	                    //(3).屏幕滑动
			leader = leader + step;
	                    //盒子本身的位置+步长
			window.scrollTo(0,leader);
	                    //scrollTo(xpos,ypos) 方法可把内容滚动到指定的坐标。
	                    //(4).清除定时器
			if(Math.abs(down_target-leader)<=Math.abs(step)){
				window.scrollTo(0,down_target);
				clearInterval(timerDown);
			}
	    },25);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
