window.onload = function () {
    // 广告滚播图
    var back = getId("back");//大字
    var bianse = getClass("bianse");//变色的类数组
    console.log(bianse);
    var gunBox = getClass('gun_box')[0];//轮播图的盒子
	var gunUl = gunBox.children[0];//ul
	var gunLis = gunUl.children;//6个图片
	var firstLi = gunUl.children[0];//第一张图片
	var scrollWidth = gunBox.offsetWidth;//可视区域的宽度
	//2.1克隆元素 
	var newLi = firstLi.cloneNode(true);//深复制:标签和内容
	//2.2添加图片ul中 
	//此时ul中有了6张图片, 123451
	gunUl.appendChild(newLi);
	//4.自动轮播
	//自动轮播时,图片1-5, 指示器1-5
	//4.1定义自动轮播 
	var timer = null; //定时器 
	var key = 0 ;//控制图片
	//4.2设置定时器 setInterval(函数方法,时间间隔)
	timer = setInterval(autoPlay,3000);
	//4.3自动播放方法 
	function autoPlay(){
		//4.4自动轮播时,方向往右,	图片1-5;图片索引增大,指示器索引增大
		key++;
		//4.5 图片索引 0 1 2 3 4
		//真正的图片ul 0 1 2 3 4 5(0)
		//               第五张图片--->第一张图片0
		//                        5(0)   6(1)
		//设置一个假效果,让5-1的切换自然一些.
		if(key>5){
			key=1;
			// 1 2 3 4 5(0) 0 , 由于设置了一个假效果,则1的左边为0px
			gunUl.style.left = 0+"px";
		}
		//4.6让图片动起来 (图片自动滚动)
		animate(gunUl,-key*scrollWidth);
		
		if(key==2|key==5){
	        back.style.color = '#000';
	    }else{
	    	back.style.color = '#fff';
	    }
	    if(key==5){
	        for(var i=0;i<bianse.length;i++){
				bianse[i].style.color = '#000';
			}
	    }else{
	    	for(var i=0;i<bianse.length;i++){
				bianse[i].style.color = '#fff';
			}
	    }
	}	

// --------------------------------------------
    //封装好,运动函数 animate
	//obj  对象 
	//target  目标位置,让scrollLeft移动多少
	function animate (obj,target){
		clearInterval(obj.timer);
			// ul.style.left = -this.index*scrollWidth+"px";
			//从1-->5 left小
			//从5-->1 left变大
			//每次移动这个距离,张数*图片的宽度
			//3.1目标位置
			//3.2 速度正反
			var speed = obj.offsetLeft < target ? 15 : -15;
			obj.timer = setInterval(function(){
				//3.3应该运动的距离
				//   -1470 - 0 
				//   1470  1456 1472
				var result = target - obj.offsetLeft;
				// 0  -15px+
				obj.style.left = obj.offsetLeft + speed + "px";
				if(Math.abs(result)<=15){
					obj.style.left = target + "px";
					clearInterval(obj.timer);
				}
		},10);
	}

// --------------------------------------------
    // 产品下拉块
    var productXia = getId('product_xia');//产品下效果块
	var product = getId('product');//产品
    product.onmouseover = productXia.onmouseover = function(){
		productXia.style.display="block";
	}
	product.onmouseout = productXia.onmouseout = function(){
		productXia.style.display="none";	
	}
 
 // -------------------------------------------
    // 诚信经营下拉块
    var honestXia = getId('honest_xia');//产品下效果块
	var honest = getId('honest');//产品
    honest.onmouseover = honestXia.onmouseover = function(){
		honestXia.style.display="block";
	}
	honest.onmouseout = honestXia.onmouseout = function(){
		honestXia.style.display="none";	
	}


























}