$(function(){
//	小红书发展史开始
	var i=0;
	var timer = setInterval(function(){
		if(i==0){
			$(".jnd_allLi").eq(0).css({"font-weight":"800","color":"black"});
			$(".jnd_allLi").eq(0).siblings("li").css({"font-weight":"100","color":"#666666"});
			$(".jnd_allLi").eq(0).find(".jnd_dian").css("background","red");
			$(".jnd_allLi").eq(0).siblings("li").find(".jnd_dian").css("background","#666666");
			$(".jnd_allLi").eq(0).find("b").animate({height:"40px",},3000);
			$(".jnd_allLi").eq(0).siblings("li").find("b").animate({height:"0px",},0);
		}
		if(i==1){
			$(".jnd_allLi").eq(1).css({"font-weight":"800","color":"black"});
			$(".jnd_allLi").eq(1).siblings("li").css({"font-weight":"100","color":"#666666"});
			$(".jnd_allLi").eq(1).find(".jnd_dian").css("background","red");
			$(".jnd_allLi").eq(1).siblings("li").find(".jnd_dian").css("background","#666666");
			$(".jnd_allLi").eq(1).find("b").animate({height:"40px",},3000);
			$(".jnd_allLi").eq(1).siblings("li").find("b").animate({height:"0px",},0);
		}
		if(i==2){
			$(".jnd_allLi").eq(2).css({"font-weight":"800","color":"black"});
			$(".jnd_allLi").eq(2).siblings("li").css({"font-weight":"100","color":"#666666"});
			$(".jnd_allLi").eq(2).find(".jnd_dian").css("background","red");
			$(".jnd_allLi").eq(2).siblings("li").find(".jnd_dian").css("background","#666666");
			$(".jnd_allLi").eq(2).find("b").animate({height:"40px",},3000);
			$(".jnd_allLi").eq(2).siblings("li").find("b").animate({height:"0px",},0);
		}
		if(i==3){
			$(".jnd_allLi").eq(3).css({"font-weight":"800","color":"black"});
			$(".jnd_allLi").eq(3).siblings("li").css({"font-weight":"100","color":"#666666"});
			$(".jnd_allLi").eq(3).find(".jnd_dian").css("background","red");
			$(".jnd_allLi").eq(3).siblings("li").find(".jnd_dian").css("background","#666666");
			$(".jnd_allLi").eq(3).find("b").animate({height:"40px",},3000);
			$(".jnd_allLi").eq(3).siblings("li").find("b").animate({height:"0px",},0);
		}
		if(i==4){
			$(".jnd_allLi").eq(4).css({"font-weight":"800","color":"black"});
			$(".jnd_allLi").eq(4).siblings("li").css({"font-weight":"100","color":"#666666"});
			$(".jnd_allLi").eq(4).find(".jnd_dian").css("background","red");
			$(".jnd_allLi").eq(4).siblings("li").find(".jnd_dian").css("background","#666666");
			$(".jnd_allLi").eq(4).find("b").animate({height:"40px",},3000);
			$(".jnd_allLi").eq(4).siblings("li").find("b").animate({height:"0px",},0);
		}
		if(i==5){
			$(".jnd_allLi").eq(5).css({"font-weight":"800","color":"black"});
			$(".jnd_allLi").eq(5).siblings("li").css({"font-weight":"100","color":"#666666"});
			$(".jnd_allLi").eq(5).find(".jnd_dian").css("background","red");
			$(".jnd_allLi").eq(5).siblings("li").find(".jnd_dian").css("background","#666666");
			$(".jnd_allLi").eq(5).find("b").animate({height:"40px",},3000);
			$(".jnd_allLi").eq(5).siblings("li").find("b").animate({height:"0px",},0);
		}
		if(i==6){
			$(".jnd_allLi").eq(6).css({"font-weight":"800","color":"black"});
			$(".jnd_allLi").eq(6).siblings("li").css({"font-weight":"100","color":"#666666"});
			$(".jnd_allLi").eq(6).find(".jnd_dian").css("background","red");
			$(".jnd_allLi").eq(6).siblings("li").find(".jnd_dian").css("background","#666666");
			$(".jnd_allLi").eq(6).find("b").animate({height:"40px",},3000);
			$(".jnd_allLi").eq(6).siblings("li").find("b").animate({height:"0px",},0);
		}
		if(i==7){
			$(".jnd_allLi").eq(7).css({"font-weight":"800","color":"black"});
			$(".jnd_allLi").eq(7).siblings("li").css({"font-weight":"100","color":"#666666"});
			$(".jnd_allLi").eq(7).find(".jnd_dian").css("background","red");
			$(".jnd_allLi").eq(7).siblings("li").find(".jnd_dian").css("background","#666666");
			$(".jnd_allLi").eq(7).find("b").animate({height:"40px",},3000);
			$(".jnd_allLi").eq(7).siblings("li").find("b").animate({height:"0px",},0);
		}
		if(i==8){
			$(".jnd_allLi").eq(8).css({"font-weight":"800","color":"black"});
			$(".jnd_allLi").eq(8).siblings("li").css({"font-weight":"100","color":"#666666"});
			$(".jnd_allLi").eq(8).find(".jnd_dian").css("background","red");
			$(".jnd_allLi").eq(8).siblings("li").find(".jnd_dian").css("background","#666666");
			$(".jnd_allLi").eq(8).find("b").animate({height:"40px",},3000);
			$(".jnd_allLi").eq(8).siblings("li").find("b").animate({height:"0px",},0);
		}
		if(i==9){
			$(".jnd_allLi").eq(9).css({"font-weight":"800","color":"black"});
			$(".jnd_allLi").eq(9).siblings("li").css({"font-weight":"100","color":"#666666"});
			$(".jnd_allLi").eq(9).find(".jnd_dian").css("background","red");
			$(".jnd_allLi").eq(9).siblings("li").find(".jnd_dian").css("background","#666666");
			$(".jnd_allLi").eq(9).find("b").animate({height:"40px",},3000);
			$(".jnd_allLi").eq(9).siblings("li").find("b").animate({height:"0px",},0);
		}
		i++;
		if(i==10){
			i=0;
		}
	},3000)
	
//	公司环境开始
$("#jnd_corporate li").mouseenter(function(){
	$(this).find(".jnd_huanjing").hide();
	$(this).find(".jnd_xianshi").animate({width:300},300);
})
$("#jnd_corporate li").mouseleave(function(){
	$(this).find(".jnd_huanjing").show();
	$(this).find(".jnd_xianshi").animate({width:0},0);
})
	
$("#jnd_book li").mouseenter(function(){
	$(this).find("div").animate({top:-80},300);
	$(this).css("border","1px solid blue");
})
$("#jnd_book li").mouseleave(function(){
	$(this).find("div").animate({top:10},300);
	$(this).css("border","none");
})
	
$("#jnd_hotBook li").mouseenter(function(){
	$(this).find("img").animate({width:40},300);
	$(this).css({"box-shadow":"darkgray 5px 5px 40px 2px"});
})
$("#jnd_hotBook li").mouseleave(function(){
	$(this).find("img").animate({width:80},300);
	$(this).css({"box-shadow":"none"});
})
	
	
	
})
