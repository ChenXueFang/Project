$(function(){
	$(".X_top>ul>li").mouseenter(function(){
		$(this).css({"border-bottom":"2px solid red","color":"red"}).siblings("li").css({"border-bottom":"2px solid #ffffff","color":"#000"});
	});

	
//	大图背景部分
	
	
//点击国内商家入驻和国外商家入驻实现切换
$(".select>li:eq(0)").click(function(){
	$(".merchants_informaition1").fadeIn();
	$(".merchants_informaition2").fadeOut();
	$(".select1>p:eq(2)").css("background","#2bd8ff");
	$(".select2>p:eq(2)").css("background","#ffffff");
})
$(".select>li:eq(1)").click(function(){
	$(".merchants_informaition2").fadeIn();
	$(".merchants_informaition1").fadeOut();
	$(".select2>p:eq(2)").css("background","#2bd8ff");
	$(".select1>p:eq(2)").css("background","#ffffff");
})


//	商家入驻信息部分鼠标移动到问号图标显示相应证书
//三证合一证
$("#pic_select").mouseenter(function(){
	$(".pic1").show();
})
$("#pic_select").mouseleave(function(){
	$(".pic1").hide();
})

//营业执照
$("#pic_select2").mouseenter(function(){
	$(".pic2").show();
})
$("#pic_select2").mouseleave(function(){
	$(".pic2").hide();
})

//税务登记证
$("#pic_select3").mouseenter(function(){
	$(".pic3").show();
})
$("#pic_select3").mouseleave(function(){
	$(".pic3").hide();
})

//组织机构代码证
$("#pic_select4").mouseenter(function(){
	$(".pic4").show();
})
$("#pic_select4").mouseleave(function(){
	$(".pic4").hide();
})

//财务信息部分的效果
//银行开户许可证
$("#pic_select5").mouseenter(function(){
	$(".pic5").show();
})
$("#pic_select5").mouseleave(function(){
	$(".pic5").hide();
})

//申请书
$("#pic_select6").mouseenter(function(){
	$(".pic6").show();
})
$("#pic_select6").mouseleave(function(){
	$(".pic6").hide();
})

//国外入驻开始
//证书部分
$("#pic_select7").mouseenter(function(){
	$(".pic7").show();
})
$("#pic_select7").mouseleave(function(){
	$(".pic7").hide();
})

$("#pic_select8").mouseenter(function(){
	$(".pic8").show();
})
$("#pic_select8").mouseleave(function(){
	$(".pic8").hide();
})

//常见问题部分,点击效果
$(".problems_select>li").click(function(){
//	点击谁,谁的文字为白色,背景为灰色
	$(this).css({"background":"#aeaeae","color":"#ffffff"}).siblings("li").css({"background":"#ffffff","color":"#000"});
//	点击显示相应的内容
     if ($(this).index()==0){
     	$(".show_contant1").show();
     }
     else{
     	$(".show_contant1").hide();
     }
     
     if ($(this).index()==1){
     	$(".show_contant2").show();
     }
     else{
     	$(".show_contant2").hide();
     }
    
     if ($(this).index()==2){
     	$(".show_contant3").show();
     }
     else{
     	$(".show_contant3").hide();
     }
    
     if ($(this).index()==3){
     	$(".show_contant4").show();
     }
     else{
     	$(".show_contant4").hide();
     }            
});
})