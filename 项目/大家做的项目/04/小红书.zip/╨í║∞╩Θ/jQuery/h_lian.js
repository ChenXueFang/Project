$(document).ready(function(){
	$("#h_dao li:eq(0)").mouseenter(function(){
		$("#h_dao li:eq(0)").children("span").show();
	})
	$("#h_dao li:eq(0)").mouseleave(function(){
		$("#h_dao li:eq(0)").children("span").hide();
	})
	$("#h_dao li:eq(1)").mouseenter(function(){
		$("#h_dao li:eq(1)").children("span").show();
	})
	$("#h_dao li:eq(1)").mouseleave(function(){
		$("#h_dao li:eq(1)").children("span").hide();
	})
	$("#h_dao li:eq(2)").mouseenter(function(){
		$("#h_dao li:eq(2)").children("div").show();
	})
	$("#h_dao li:eq(2)").mouseleave(function(){
		$("#h_dao li:eq(2)").children("div").hide();
	})
		$("#h_dao li:eq(3)").mouseenter(function(){
		$("#h_dao li:eq(3)").children("span").show();
	})
	$("#h_dao li:eq(3)").mouseleave(function(){
		$("#h_dao li:eq(3)").children("span").hide();
	})
		$("#h_dao li:eq(4)").mouseenter(function(){
		$("#h_dao li:eq(4)").children("span").show();
	})
	$("#h_dao li:eq(4)").mouseleave(function(){
		$("#h_dao li:eq(4)").children("span").hide();
	})
	$("#h_dao li:eq(5)").mouseenter(function(){
		$("#h_dao li:eq(5)").children("span").show();
	})
	$("#h_dao li:eq(5)").mouseleave(function(){
		$("#h_dao li:eq(5)").children("span").hide();
	})
//	图片的点击
 $(function (){
    $('.nav li').on('click', function () {
      $(this).addClass('on').siblings().removeClass('on');
      $('.p').eq($(this).index()).addClass('show').siblings().removeClass('show');
    })
  })
 $(".h_heng_top>ul>li:eq(0)").mouseenter(function(){
 	$(".h_li").hide();
 	$(".h_zhuang_tu").show();
 })
 
  $(".h_heng_top>ul>li:eq(0)").mouseleave(function(){
 	$(".h_li").show();
 	$(".h_zhuang_tu").hide();
 })
   $(".h_heng_top>ul>li:eq(1)").mouseenter(function(){
 	$(".h_xia_zai").hide();
 	$(".h_zhuang_tu1").show();
 })
 
  $(".h_heng_top>ul>li:eq(1)").mouseleave(function(){
 	$(".h_xia_zai").show();
 	$(".h_zhuang_tu1").hide();
 })
  
    $(".h_ding b").mouseenter(function(){
    	$(".h_xia").show();
    })
      $(".h_ding b").mouseleave(function(){
    	$(".h_xia").hide();
    })  
  
  //换内容的开始
    $(".h_ding a").mouseenter(function(){  	
    	$(".h_ding a").children("i").hide();
    	$(".h_ding a").css({"font-size":"16px","color":"black"}).text("返回顶部");
    })
    $(".h_ding a").mouseleave(function(){
    	$(".h_ding a").children("i").show();
//  	console.log($(".h_ding span").text())
    	$(".h_ding a").css("font-size","16px").text("").html('<i class="iconfont icon-shuangjiantouxiangshang inner"></i>');
    	
    })
//滑动的时候去判断
    $(window).scroll(function(){
    	if($(document).scrollTop()<1200){
		    $(".h_ding a").hide();
	   }else{
		    $(".h_ding a").show();
	}
    })
    
    $(window).scroll(function(){
    	if($(document).scrollTop()<1200){
		    $(".h_ding b").hide();
	   }else{
		    $(".h_ding b").show();
	}
    })
//点击卷动的页面
    $(".h_ding>a").click(function(){
    	$("body,html").animate({
    		scrollTop:0
    	},1000);
//  	console.log($(window).scrollTop());
    })
})