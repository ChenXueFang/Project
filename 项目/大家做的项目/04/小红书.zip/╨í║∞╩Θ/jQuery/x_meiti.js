
//	往期报道中鼠标移动到左边右边跟着显示
//2018年的
$(".report_left1>a").mouseenter(function(){
	$(".report_right1>a").eq($(this).index()-3).css("color","red").siblings("a").css("color","#000");
})
$(".report_right1>a").mouseenter(function(){
	$(this).css("color","red").siblings("a").css("color","#000");
})
$(".report_right1>a").mouseleave(function(){
	$(this).css("color","#000").siblings("a").css("color","#000");
})
	
	
//2017年的
$(".report_left2>a").mouseenter(function(){
	$(".report_right2>a").eq($(this).index()-3).css("color","red").siblings("a").css("color","#000");
})
$(".report_right2>a").mouseenter(function(){
	$(this).css("color","red").siblings("a").css("color","#000");
})
$(".report_right2>a").mouseleave(function(){
	$(this).css("color","#000").siblings("a").css("color","#000");
})
	
//2016年的
$(".report_left3>a").mouseenter(function(){
	$(".report_right3>a").eq($(this).index()-3).css("color","red").siblings("a").css("color","#000");
})
$(".report_right3>a").mouseenter(function(){
	$(this).css("color","red").siblings("a").css("color","#000");
})
$(".report_right3>a").mouseleave(function(){
	$(this).css("color","#000").siblings("a").css("color","#000");
})
		
//2015年的
$(".report_left4>a").mouseenter(function(){
	$(".report_right4>a").eq($(this).index()-3).css("color","red").siblings("a").css("color","#000");
})
$(".report_right4>a").mouseenter(function(){
	$(this).css("color","red").siblings("a").css("color","#000");
})
$(".report_right4>a").mouseleave(function(){
	$(this).css("color","#000").siblings("a").css("color","#000");
})

//2014年的
$(".report_left5>a").mouseenter(function(){
	$(".report_right5>a").eq($(this).index()-3).css("color","red").siblings("a").css("color","#000");
})
$(".report_right5>a").mouseenter(function(){
	$(this).css("color","red").siblings("a").css("color","#000");
})
$(".report_right5>a").mouseleave(function(){
	$(this).css("color","#000").siblings("a").css("color","#000");
})
	
//2013年的
$(".report_left6>a").mouseenter(function(){
	$(".report_right6>a").eq($(this).index()-3).css("color","red").siblings("a").css("color","#000");
})
$(".report_right6>a").mouseenter(function(){
	$(this).css("color","red").siblings("a").css("color","#000");
})
$(".report_right6>a").mouseleave(function(){
	$(this).css("color","#000").siblings("a").css("color","#000");
})