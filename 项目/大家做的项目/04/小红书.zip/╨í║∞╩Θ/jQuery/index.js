$(function(){
	var str = "全世界的好东西";
	var str2 ="";
	var x = 0;

	var num = 0;//控制数组下标
	var timer = null;
	$(".typed_cursor").show();
	//定时器
	timer = setInterval(function(){
	str2 += str[num];
			x++;
			//文字区域插入字符
			$(".j_word").text(str2);
			//索引值
			num++;
			if(x==7){
				num=0;
				str2="";
				str="找到你想要的生活";				
			}
			if(x==15){
				num=0;
				str2="";
				str="明星生活的另一面";	
			}
			if(x==23){
				num=0;
				x=0;
				str2="";
				str="吃穿玩乐买的爽";					
			}

	},400);
	
//	关注我们开始
var y = 0;
$(".left_jnd_guanzhu li").click(function(){
	$(this).children().children().children("p").css({"font-size":"80px","transition":"2s"});
	$(this).find(".jnd_line").animate({width:"300px"},2);
	$(this).find(".jnd_line").children("span").animate({width:"300px"},2000);
	
	$(this).siblings("li").children().children().children("p").css("font-size","25px");
	$(this).siblings("li").find(".jnd_line").animate({width:"100px"},2);
	$(this).siblings("li").find(".jnd_line").children("span").animate({width:"0px"},2);
	clearInterval(timer2);
	timer2=setInterval(fangfa,2000);
	y=$(this).index();
})

	var timer2 = setInterval(fangfa,2000)
	function fangfa(){
		console.log(y)
		if(y==0){
			$(".j_banner_li:eq(0)").find("p").css({"font-size":"80px","transition":"2s"});
			$(".j_banner_li:eq(0)").find(".jnd_line").animate({width:"300px",},2);
			$(".j_banner_li:eq(0)").find("span").animate({width:"300px"},2000);
	
			$(".j_banner_li:eq(0)").siblings("li").find("p").css({"font-size":"25px","transition":"0s"});
			$(".j_banner_li:eq(0)").siblings("li").find(".jnd_line").animate({width:"100px"},2);
			$(".j_banner_li:eq(0)").siblings("li").find("span").animate({width:"0px"},2);
			$(".right_jnd_guanzhu li").eq(0).fadeIn().siblings("li").hide();
		}
		if(y==1){
			$(".j_banner_li:eq(1)").find("p").css({"font-size":"80px","transition":"2s"});
			$(".j_banner_li:eq(1)").find(".jnd_line").animate({width:"300px"},2);
			$(".j_banner_li:eq(1)").find("span").animate({width:"300px"},2000);
	
			$(".j_banner_li:eq(1)").siblings("li").find("p").css({"font-size":"25px","transition":"0s"});
			$(".j_banner_li:eq(1)").siblings("li").find(".jnd_line").animate({width:"100px"},2);
			$(".j_banner_li:eq(1)").siblings("li").find("span").animate({width:"0px"},2);
			$(".right_jnd_guanzhu li").eq(1).fadeIn().siblings("li").hide();
		}
		if(y==2){
			$(".j_banner_li:eq(2)").find("p").css({"font-size":"80px","transition":"2s"});
			$(".j_banner_li:eq(2)").find(".jnd_line").animate({width:"300px"},2);
			$(".j_banner_li:eq(2)").find("span").animate({width:"300px"},2000);
	
			$(".j_banner_li:eq(2)").siblings("li").find("p").css({"font-size":"25px","transition":"0s"});
			$(".j_banner_li:eq(2)").siblings("li").find(".jnd_line").animate({width:"100px"},2);
			$(".j_banner_li:eq(2)").siblings("li").find("span").animate({width:"0px"},2);
			$(".right_jnd_guanzhu li").eq(2).fadeIn().siblings("li").hide();
		}
		if(y==3){
			$(".j_banner_li:eq(3)").find("p").css({"font-size":"80px","transition":"2s"});
			$(".j_banner_li:eq(3)").find(".jnd_line").animate({width:"300px"},2);
			$(".j_banner_li:eq(3)").find("span").animate({width:"300px"},2000);
	
			$(".j_banner_li:eq(3)").siblings("li").find("p").css({"font-size":"25px","transition":"0s"});
			$(".j_banner_li:eq(3)").siblings("li").find(".jnd_line").animate({width:"100px"},2);
			$(".j_banner_li:eq(3)").siblings("li").find("span").animate({width:"0px"},2);
			$(".right_jnd_guanzhu li").eq(3).fadeIn().siblings("li").hide();
		}
		y++;
		if(y==4){
			y=0;
		}
	}

//	2亿用户开始
$(".bot_million li").mouseenter(function(){
	$(this).find(".jnd_mengmian").show();
	$(this).siblings("li").find(".jnd_mengmian").hide();
})
var a=1;
var timer3 = setInterval(function(){
	if(a==1){
		$(".one_bot_million").fadeIn();
		$(".two_bot_million").hide();
		$(".three_bot_million").hide();
	}
	if(a==2){
		$(".one_bot_million").hide();
		$(".two_bot_million").fadeIn();
		$(".three_bot_million").hide();
	}
	if(a==3){
		$(".one_bot_million").hide();
		$(".two_bot_million").hide();
		$(".three_bot_million").fadeIn();
	}
	if(a>2){
		a=0;
	}
	a++;
	
},3000)
	
	
	
	
})