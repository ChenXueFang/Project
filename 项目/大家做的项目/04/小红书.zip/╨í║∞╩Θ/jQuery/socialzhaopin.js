$(function(){
	$("#z_header_lastLi").mouseenter(function(){
		$(".z_header_erweima").show();
	})
	$("#z_header_lastLi").mouseleave(function(){
		$(".z_header_erweima").hide();
	})
	
	//tab切换上面部分li
	$(".z_qiehuan_top>div>dl>dd").click(function(){
		console.log(111);
	$(this).addClass("z_qiehuan_topB").siblings("dd").removeClass("z_qiehuan_topB");
	})
	
//	tab切换下面隔行变色
	$(".z_qiehuan_buttonT dd:even").css("background","#ffffff");
	console.log(111);
	$(".z_qiehuan_buttonT dd:odd").css("background","#fbfbfb");
	
//	点击全部1
//$(".z_jishu").click(function(){
//		$(".z_qiehuan_button").children("div:eq(0)").removeClass("shows_box");
//		$(".z_qiehuan_button").children("div:eq(1)").addClass("shows_box");
//	})

	$(".z_qiehuan1").click(function(){
		$(".z_qiehuan_button").children("div:eq(1)").removeClass("shows_box");
		$(".z_qiehuan_button").children("div:eq(2)").removeClass("shows_box");
		$(".z_qiehuan_button").children("div:eq(3)").removeClass("shows_box");
		$(".z_qiehuan_button").children("div:eq(0)").addClass("shows_box");
	
	})
//	点击技术这个盒子
	$(".z_jishu").click(function(){
		$(".z_qiehuan_button").children("div:eq(0)").removeClass("shows_box");
		$(".z_qiehuan_button").children("div:eq(2)").removeClass("shows_box");
		$(".z_qiehuan_button").children("div:eq(3)").removeClass("shows_box");
		$(".z_qiehuan_button").children("div:eq(1)").addClass("shows_box");
	})
//	点击全部2
$(".z_quanbu").click(function(){
	$(".z_qiehuan_button").children("div:eq(0)").removeClass("shows_box");
	$(".z_qiehuan_button").children("div:eq(1)").removeClass("shows_box");
	$(".z_qiehuan_button").children("div:eq(2)").addClass("shows_box");
	$(".z_qiehuan_button").children("div:eq(3)").removeClass("shows_box");
})
//	点击北京
$(".z_beijing").click(function(){
	$(".z_qiehuan_button").children("div:eq(0)").removeClass("shows_box");
	$(".z_qiehuan_button").children("div:eq(1)").removeClass("shows_box");
	$(".z_qiehuan_button").children("div:eq(2)").removeClass("shows_box");
	$(".z_qiehuan_button").children("div:eq(3)").addClass("shows_box");
})
//	数字变化
var num = 1;
$("#z_jiantou_top").click(function(){
	
	num++;
	$("#z_shuzi").text(num);
	console.log(num);
})
	$("#z_jiantou_button").click(function(){
	
	num--;
	if(num<1){
		num=1;
	}
	$("#z_shuzi").text(num);
	console.log(num);
})
	$("#z_shuzi").mouseenter(function(){
		$("#z_jiantou").show();
	})
	
	$("#z_shuzi").mouseleave(function(){
		$("#z_jiantou").hide();
	})
	$("#z_jiantou").mouseenter(function(){
		$("#z_jiantou").show();
	})
	
	$("#z_jiantou").mouseleave(function(){
		$("#z_jiantou").hide();
	})
	})

