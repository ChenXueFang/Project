$(function(){
	$("#z_header_lastLi").mouseenter(function(){
		$(".z_header_erweima").show();
	})
	$("#z_header_lastLi").mouseleave(function(){
		$(".z_header_erweima").hide();
	})
	
	//加载部分
	$(".z_load_pic").load(function(){
		$(this).css("transform","scale(125)");
		$(this).css("transition","0.8s");
		
		$(".z_load_pic1").css("transform","scale(125)");
		$(".z_load_pic1").css("transition","1.6s");
		
		$(".z_load_pic2").css("transform","scale(125)");
		$(".z_load_pic2").css("transition","2.4s");
	})
	
//	炫彩梦想文字部分
	$(".z_dream").mouseenter(function(){ 
	 $(".z_dream_left").animate({"marginRight":200}).fadeOut(500);  
	 $(".z_dream_right").animate({"marginLeft":200}).fadeOut(500);  
	 $(".z_dream_your").fadeOut(500);
	 $(".z_dalay").show(1500);
	 
	 $(".z_dream_button1").animate({"marginBottom":100}).show(1000); 
	 $(".z_dream_button2").animate({"marginTop":100}).show(1000);
	 $(".z_dream_button3").animate({"marginBottom":100}).show(1000); 
	 $(".z_dream_button4").animate({"marginTop":100}).show(1000); 
//	 $(".z_dream_button1").show().animate({"top":10});  
	})
	 $(".z_dream").mouseleave(function(){ 
	 	
	
	 $(".z_dream_left").fadeIn(500).animate({"marginRight":0});   	
	 $(".z_dream_right").fadeIn(500).animate({"marginLeft":0});  
	  $(".z_dream_your").fadeIn(500);
	  
	 $(".z_dream_button1").animate({"marginBottom":-100}).hide(1000); 
	 $(".z_dream_button2").animate({"marginTop":-100}).hide(1000);
	 $(".z_dream_button3").animate({"marginBottom":-100}).hide(1000); 
	 $(".z_dream_button4").animate({"marginTop":-100}).hide(1000); 
//	 console.log(z_dream_button:eq(1));

});  

//图片效果
//竖线加载
$(".z_animate_first").mouseenter(function(){
	$(this).find("i").animate({"bottom":"0px"});
	$(this).find(".z_animate_firstDiv").css("transform","translate(0%,-100%)");
})
	$(".z_animate_first").mouseleave(function(){
	$(this).find("i").animate({"bottom":"-80px"});
	$(this).find(".z_animate_firstDiv").css("transform","translate(0%,0%)");
	
})
//	鼠标放在第一个li上
$(".z_animate_first").mouseenter(function(){
	$(this).css("backgroundPosition","0px -11px");
	$(this).find("b").css("background","rgba(30, 144, 255,0.8)");
	$(this).find(".z_animate_first_Ul").animate({"opacity":"1"},500);
//	$(this).siblings("li").find(".z_animate_first_Ul").animate({"opacity":"0"},1);
	$(this).children("p:eq(0)").animate({"font-size":"10px"},10);
	$(this).children("p:eq(1)").animate({"font-weight":100},100);
})

$(".z_animate_first").mouseleave(function(){
	$(this).css("backgroundPosition","0px 0px");
	$(".z_animate_first_Ul").animate({"opacity":"0"},100);
	$(this).find("b").css("background","rgba(30, 144, 255,0)");
	
	$(this).children("p:eq(0)").animate({"font-size":"16px"},10);
	$(this).children("p:eq(1)").animate({"font-weight":900},100);

})
		
})