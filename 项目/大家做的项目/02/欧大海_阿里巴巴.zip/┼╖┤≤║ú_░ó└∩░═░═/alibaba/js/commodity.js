var bigbox=document.getElementById("bigbox"); 
var itemss=bigbox.getElementsByTagName("li");
var dago1 = document.getElementById("dago1");
var dago2 = document.getElementById("dago2");
var dago3 = document.getElementById("dago3");
var dago4 = document.getElementById("dago4");
var boin = document.getElementById("boin");
//console.log(banner);
//console.log(inside);
 function addListener(element,e,fn){ 
     if(element.addEventListener){ 
          element.addEventListener(e,fn,false); 
          } 
         else 
	       { 
	          element.attachEvent("on" + e,fn); 
	       } 
        } 
//console.log(dago);
  addListener(itemss[0],"click",function(){ 
       dago1.style.display="block"; 
       dago2.style.display="none";
       dago3.style.display="none";
       dago4.style.display="none";
        itemss[0].setAttribute("id","boin");
       itemss[1].removeAttribute("id","boin");
       itemss[2].removeAttribute("id","boin");
       itemss[3].removeAttribute("id","boin");
   }) 
   addListener(itemss[1],"click",function(){ 
   	  dago1.style.display="none"; 
       dago2.style.display="block";
       dago3.style.display="none";
       dago4.style.display="none";
       itemss[1].setAttribute("id","boin");
       itemss[0].removeAttribute("id","boin");
       itemss[2].removeAttribute("id","boin");
       itemss[3].removeAttribute("id","boin");
   }) 
    addListener(itemss[2],"click",function(){ 
       dago1.style.display="none"; 
       dago2.style.display="none";
       dago3.style.display="block";
       dago4.style.display="none"; 
       itemss[2].setAttribute("id","boin");
       itemss[0].removeAttribute("id","boin");
       itemss[1].removeAttribute("id","boin");
       itemss[3].removeAttribute("id","boin");
   })
   addListener(itemss[3],"click",function(){ 
   	   dago1.style.display="none"; 
       dago2.style.display="none";
       dago3.style.display="none";
       dago4.style.display="block";
        itemss[3].setAttribute("id","boin");
       itemss[0].removeAttribute("id","boin");
       itemss[2].removeAttribute("id","boin");
       itemss[1].removeAttribute("id","boin");
   }) 
