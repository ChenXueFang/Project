 var datu = document.getElementById("datu");
 var datu1 = document.getElementById("datu1");
 var datu2 = document.getElementById("datu2");
 var datu3 = document.getElementById("datu3");
 var datu4 = document.getElementById("datu4");
    datu.onmouseover=function(){
    	var chufa1 = document.getElementById("chufa1");
    	chufa1.style.display = "block";
 }
    datu1.onmouseover=function(){
    	var chufa2 = document.getElementById("chufa2");
    	chufa2.style.display = "block";
 }
       datu2.onmouseover=function(){
    	var chufa3 = document.getElementById("chufa3");
    	chufa3.style.display = "block";
 }
        datu3.onmouseover=function(){
    	var chufa4 = document.getElementById("chufa4");
    	chufa4.style.display = "block";
 }
        datu4.onmouseover=function(){
    	var chufa5 = document.getElementById("chufa5");
    	chufa5.style.display = "block";
 }
      
        /*出图片*/
    datu.onmouseout=function(){
    	var chufa1 = document.getElementById("chufa1");
    	chufa1.style.display = "none";
}
       datu1.onmouseout=function(){
    	var chufa2 = document.getElementById("chufa2");
    	chufa2.style.display = "none";
 }
       datu2.onmouseout=function(){
    	var chufa3 = document.getElementById("chufa3");
    	chufa3.style.display = "none";
 }
        datu3.onmouseout=function(){
    	var chufa4 = document.getElementById("chufa4");
    	chufa4.style.display = "none";
 }
        datu4.onmouseout=function(){
    	var chufa5 = document.getElementById("chufa5");
    	chufa5.style.display = "none";
 }
 var xada1 = document.getElementById("xada1");
 var xada2 = document.getElementById("xada2");
 var xada3 = document.getElementById("xada3");
 var xada4 = document.getElementById("xada4");
 var xada5 = document.getElementById("xada5");
    xada1.onmouseover=function(){
    tu1 = document.getElementById("tu1");
    	tu1.style.display = "block";
 }
      xada1.onmouseout=function(){
    	var tu1 = document.getElementById("tu1");
    	tu1.style.display = "none";
}
         xada2.onmouseover=function(){
    tu2 = document.getElementById("tu2");
    	tu2.style.display = "block";
 }
      xada2.onmouseout=function(){
    	var tu2 = document.getElementById("tu2");
    	tu2.style.display = "none";
}
      xada3.onmouseover=function(){
    tu3 = document.getElementById("tu3");
    	tu3.style.display = "block";
 }
      xada3.onmouseout=function(){
    	var tu3 = document.getElementById("tu3");
    	tu3.style.display = "none";
}
       xada4.onmouseover=function(){
    tu4 = document.getElementById("tu4");
    	tu4.style.display = "block";
 }
      xada4.onmouseout=function(){
    	var tu4 = document.getElementById("tu4");
    	tu4.style.display = "none";
}
          xada5.onmouseover=function(){
    tu5 = document.getElementById("tu5");
    	tu5.style.display = "block";
 }
      xada5.onmouseout=function(){
    	var tu5 = document.getElementById("tu5");
    	tu5.style.display = "none";
}
   