   function displaySubMenu(li){
        var subMenu = li.getElementsByTagName("ul")[0];
        subMenu.style.display = "block"; 
       }
        function hideSubMenu(li) {
      var subMenu = li.getElementsByTagName("ul")[0];
         subMenu.style.display = "none";
}
 function addListener(element,e,fn){ 
     if(element.addEventListener){ 
          element.addEventListener(e,fn,false); 
          } 
         else 
	       { 
	          element.attachEvent("on" + e,fn); 
	       } 
         } 
        /*以下为收索框中的js效果*/
    var wen = document.getElementById("wen");/*输入框*/
    var tiwen = document.getElementById("tiwen");
    var overText = document.getElementById("overText");
    var check = document.getElementById("check");
//   console.log(wen);
//  console.log(tiwen);
     addListener(wen,"click",function(){ 
            wen.value = ""; 
            overText.style.display="block";
//          wen.value.length=30;
//          console.log(wen.value.length);
          document.getElementById('check').innerHTML = (30);
            }) 
            
      addListener(wen,"blur",function(){
                wen.value = "请简单描述您的问题关键字，如“忘记密码”";
                overText.style.display="none";
      })
     addListener(tiwen,"click",function(){ 
            wen.value = ""; 
            overText.style.display="block";
            }) 
     addListener(tiwen,"blur",function(){ 
           wen.value = "请简单描述您的问题关键字，如“忘记密码”";
                overText.style.display="none";
            })
     
     
showLen(document.getElementById("wen"));
function showLen(obj){
	var len=30;
	var shuji=len-obj.value.length;
	console.log(obj.value.length);
	if(obj.value.length>30){
		return true;
	}
	 if(shuji>=0){
	document.getElementById('check').innerHTML = (shuji);	
}else{
//	MaxLenth=40;
//	obj.value.length=30;
	document.getElementById('check').innerHTML = (0);
 }
}
/*一下为隐藏显示的部分*/
  function displaySubMenu(li){
        var subMenu = li.getElementsByTagName("ul")[0];
        subMenu.style.display = "block"; 
       }
        function hideSubMenu(li) {
      var subMenu = li.getElementsByTagName("ul")[0];
         subMenu.style.display = "none";
}
     

