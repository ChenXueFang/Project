//var icoon = document.getElementById("icoon");

  ion = function(){
  	var icoon = document.getElementById("icoon");
  	var ff = document.getElementById("ff");
//	console.log(ff1);
//   for(var i=0;i<icoon.length;i++){
     	icoon.style.backgroundColor = "#0C6ABF";
       ff.style.color = "#fff";
    
  }
ioon = function(){
	var ff = document.getElementById("ff");
	var icoon = document.getElementById("icoon");
	icoon.style.backgroundColor = "#fff";
	ff.style.color = "#363636";
}


/*第二个*/
  ion1 = function(){
  	var icoon1 = document.getElementById("icoon1");
  	var ff1 = document.getElementById("ff1");
//	console.log(ff1);
//   for(var i=0;i<icoon.length;i++){
     	icoon1.style.backgroundColor = "#0C6ABF";
       ff1.style.color = "#fff";
    
  }
ioon1 = function(){
	var ff1 = document.getElementById("ff1");
	var icoon1 = document.getElementById("icoon1");
	icoon1.style.backgroundColor = "#fff";
	ff1.style.color = "#363636";
}

/*第三个*/
  ion2 = function(){
  	var icoon1 = document.getElementById("icoon2");
  	var ff1 = document.getElementById("ff2");
//	console.log(ff1);
//   for(var i=0;i<icoon.length;i++){
     	icoon1.style.backgroundColor = "#0C6ABF";
       ff1.style.color = "#fff";
    
  }
ioon2 = function(){
	var ff2 = document.getElementById("ff2");
	var icoon2 = document.getElementById("icoon2");
	icoon2.style.backgroundColor = "#fff";
	ff2.style.color = "#363636";
}
/*第四个*/
  ion3 = function(){
  	var icoon3 = document.getElementById("icoon3");
  	var ff3 = document.getElementById("ff3");
//	console.log(ff1);
//   for(var i=0;i<icoon.length;i++){
     	icoon3.style.backgroundColor = "#0C6ABF";
       ff3.style.color = "#fff";
    
  }
ioon3 = function(){
	var ff3 = document.getElementById("ff3");
	var icoon3 = document.getElementById("icoon3");
	icoon3.style.backgroundColor = "#fff";
	ff3.style.color = "#363636";
}
/*第五个*/
  ion4 = function(){
  	var icoon3 = document.getElementById("icoon4");
  	var ff3 = document.getElementById("ff4");
//	console.log(ff1);
//   for(var i=0;i<icoon.length;i++){
     	icoon3.style.backgroundColor = "#0C6ABF";
       ff3.style.color = "#fff";
    
  }
ioon4 = function(){
	var ff3 = document.getElementById("ff4");
	var icoon3 = document.getElementById("icoon4");
	icoon3.style.backgroundColor = "#fff";
	ff3.style.color = "#363636";
}