  function mouseIn(that) {    //鼠标移入效果
        var first=that.getElementsByTagName("div")[0],second=that.getElementsByTagName("div")[1];

        first.setAttribute("class","");
        second.setAttribute("class","");
        first.setAttribute("class","rotate1");
        second.setAttribute("class","rotate2");
    }

    function mouseOut(that) {  //鼠标移出效果
        var first=that.getElementsByTagName("div")[0],second=that.getElementsByTagName("div")[1];

        first.setAttribute("class","");
        second.setAttribute("class","");
        first.setAttribute("class","rotate2");
        second.setAttribute("class","rotate1");
    }
