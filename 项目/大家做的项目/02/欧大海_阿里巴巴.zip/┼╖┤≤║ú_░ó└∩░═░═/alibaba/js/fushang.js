
function ge(li){
	var head1 = document.getElementById("head1");
	var al = document.getElementById("a1");
	var a2 = document.getElementById("a2");
	var a3 = document.getElementById("a3");
	var head2 = document.getElementById("head2");
	var head3 = document.getElementById("head3");
	var d1 = document.getElementById("d1");
	var d2 = document.getElementById("d2");
    al.style.color="#704F88";
    a2.style.color="#f7f6f6";
    a3.style.color="#f7f6f6";
	head2.style.background ="#704F88";
	head1.style.background ="#f7f6f6";
	head3.style.background ="#704F88";
	d1.style.display="block";
	d2.style.display="none";
}
function gese(li){
	var head2 = document.getElementById("head2");
	var al = document.getElementById("a1");
	var a2 = document.getElementById("a2");
	var a3 = document.getElementById("a3");
	var d1 = document.getElementById("d1");
	var d2 = document.getElementById("d2");
	head1.style.background ="#704F88";
	 al.style.color="#f7f6f6";
	 a2.style.color="#704F88";
	 a3.style.color="#f7f6f6";
	head2.style.background ="#f7f6f6";
	head3.style.background ="#704F88";
	d1.style.display="block";
	d2.style.display="none";
}
/*进入标题三后的样式*/
function wsea(li){
	var head3 = document.getElementById("head3");
	var al = document.getElementById("a1");
	var a2 = document.getElementById("a2");
	var a3 = document.getElementById("a3");
	var d1 = document.getElementById("d1");
	var d2 = document.getElementById("d2");
	head1.style.background ="#704F88";
	head2.style.background ="#704F88";
	head3.style.background ="#f7f6f6";
	al.style.color="#f7f6f6";
	a2.style.color="#f7f6f6";
	a3.style.color="#704F88";
	d1.style.display="none";
	d2.style.display="block";
}
function dada(div){
	var daright = document.getElementById("d3")
	daright.style.display = "block";
}
function dala(div){
	var daright = document.getElementById("d3")
	daright.style.display = "block";
}

function xiala(div){
	var daright = document.getElementById("d3")
	daright.style.display = "none";
}

function se(li){
//	var head1 = document.getElementById("head1");
//	var head2 = document.getElementById("head2");
//	var head3 = document.getElementById("head3");
//	head1.style.background ="#f7f6f6";
//	head2.style.background =#f7f6f6";
//	head3.style.background ="#f7f6f6";
}

