	var interval=1000;//两次滚动之间的时间间隔 
var stepsize=26;//滚动一次的长度，必须是行高的倍数,这样滚动的时候才不会断行 
var objInterval=null; 
$(document).ready(function(){ 
//用上部的内容填充下部 
 $("#bottom").html($("#top").html()); 
 
//给显示的区域绑定鼠标事件 
$("#content").bind("mouseover",function(){StopScroll();}); 
$("#content").bind("mouseout",function(){StartScroll();}); 
 
//启动定时器 
StartScroll(); 
}); 
 
//启动定时器，开始滚动 
function StartScroll(){ 
objInterval=setInterval("verticalloop()",interval); 
} 
 
//清除定时器，停止滚动 
function StopScroll(){ 
window.clearInterval(objInterval); 
} 
 
//控制滚动 
function verticalloop(){ 
//判断是否上部内容全部移出显示区域 
//如果是，从新开始;否则，继续向上移动 
if($("#content").scrollTop()>=$("#top").outerHeight()){ 
$("#content").scrollTop($("#content").scrollTop()-$("#top").outerHeight()); 
} 
//使用jquery创建滚动时的动画效果 
$("#content").animate( 
{"scrollTop" : $("#content").scrollTop()+stepsize +"px"},600,function(){ 
//这里用于显示滚动区域的scrollTop，实际应用中请删除 
// $("#foot").html("scrollTop:"+$("#content").scrollTop()); 
}); 
}