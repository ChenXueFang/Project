  function addListener(element,e,fn){ 
     if(element.addEventListener){ 
          element.addEventListener(e,fn,false); 
          } 
         else 
	       { 
	          element.attachEvent("on" + e,fn); 
	       } 
         } 
 /*以上为事件的监听*/
 window.onscroll=function(){
                var bignav  = document.getElementById("but");//获取到导航栏id
             var  aood = document.getElementsByClassName("aood");
                if(scroll().top > 220){  //当滚动距离大于250px时执行下面的东西
                    bignav.style.position = 'fixed';
                     bignav.style.top = '209px';
                     bignav.style.left = '162px';
                     bignav.style.zIndex = '30';
                     bignav.style.width = "1197px"
                     for(var i=0;i<aood.length;i++){
                     	aood[i].style.display = "block";
                     }
                 }else{//当滚动距离小于250的时候执行下面的内容，也就是让导航栏恢复原状
                    bignav.style.position = 'static';
                     for(var i=0;i<aood.length;i++){
                     	aood[i].style.display = "none";
                     }
                 }
             }
 
   function fanan(div){
       	var  aood = document.getElementById("aood");
         aood.style.display = "block"; 
       	console.log(aood);
       }
   function File(div){
   	    var  aood = document.getElementById("aood");
   	    aood.style.display = "none"; 
   }
   
   /*点击后返回顶部*/
  var timer = null;
   var leader = 0; //显示区域自身的位置
   var target = 0; //目标位置
  var  aood = document.getElementById("aood");
   addListener(aood,"click",function(){
   	     leader = scroll().top;
   	  console.log(scroll().top);
       clearInterval(timer);
         timer = setInterval(function () {
                    //setInterval设置时间间隔
                    //获取步长
                    var step = (target-leader)/10;
                    //二次处理步长
                    step = step>0?Math.ceil(step):Math.floor(step);
                    //Math.ceil(step)向右取整
                    //Math.floor(step);向左取整
                    leader = leader +step;
                    //显示区域移动
                    //移动窗口的可见度区域
                    window.scrollTo(0,leader);
                    //清除定时器
                    if(leader === 0){
                        clearInterval(timer);
                    }
                },25); 
       
    })
