	   function displaySubMenu(li){
        var arr_ow = li.getElementById("arr_ow")[0];
       arr_ow.style.display = "block"; 
       }
        function hideSubMenu(li) {
      var arr_ow = li.getElementById("arr_ow")[0];
         arr_ow.style.display = "none";
}