 window.onscroll = function(){ //绑定scroll事件
var t = document.documentElement.scrollTop || document.body.scrollTop; //获取滚动距离
var top_div = document.getElementById( "shichang" ); //查询并定义div元素
if( t >= 100) { //判断
top_div.style.display = "block"; 
} else { 
top_div.style.display = "none"; 
} 
} 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 //获取图片所在的div对象
 var img=document.getElementById("land");
   var meimg=document.getElementById("mejia");
// var img =land.getElementsByTagName("img"); 
 //设置div 左上角坐标 ，起始点的坐标
   var x=750,y=300;
   var a=250,b=50;
 //设置图片的行进速度
// var xSpeed=2;
   var ySpeed=2;
   var bSpeed = 2;
 //设置图片的最大浮动的高度和宽度
// var w=document.documentElement.clientWidth-110,h=document.documentElement.clientHeight-160;
 function floatimg(){
   b+=bSpeed;
  y-=ySpeed;
   meimg.style.top=b+"px";
 meimg.style.left=a+"px";
 img.style.top=y+"px";
 img.style.left=x+"px"; 

 if(y===90){
 	ySpeed=0;
 }
 if(b===150){
 	bSpeed=0;
 }
 //延迟调用函数floatimg()，每个40毫秒调用一次
   setTimeout("floatimg()",10);
 }
   floatimg();

/*第二部分开始*/
var tutu = document.getElementById("tutu");
var tutu1 = document.getElementById("tutu1");
var tutu2 = document.getElementById("tutu2");
var tutu3 = document.getElementById("tutu3");
var tutu4 = document.getElementById("tutu4");
var tutu5 = document.getElementById("tutu5");
var x1=250,y1=300;
var x2=530,y2=80;
var x3=700,y3=200;
var x4=470,y4=180;
var x5=850,y5=250;
var x6=300,y6=380;
var x1Speed=x2Speed=x3Speed=x4Speed=x5Speed=x6Speed=2;
var y1Speed=y2Speed=y3Speed=y4Speed=y5Speed=y6Speed=2;

function floa(){
	x1+=x1Speed;
	y1-=y1Speed;
	x2+=x2Speed;
	y2+=y2Speed;
	x3-=x3Speed;
	y3+=y3Speed;
	x4+=x4Speed;
	y4+=y4Speed;
	x5-=x5Speed;
	y5+=y5Speed;
	x6+=x6Speed;
	y6-=y6Speed;
	
	tutu.style.top=y1+"px";
	tutu.style.left=x1+"px";
	tutu1.style.top=y2+"px";
	tutu1.style.left=x2+"px";
	tutu2.style.top=y3+"px";
	tutu2.style.left=x3+"px";
	tutu3.style.top=y4+"px";
	tutu3.style.left=x4+"px";
	tutu4.style.top=y5+"px";
	tutu4.style.left=x5+"px";
	tutu5.style.top=y6+"px";
	tutu5.style.left=x6+"px";
	
	
	
	

	setTimeout("floa()",10);

	if(x1===390){
		x1Speed=0,y1Speed=0;
	}
	if(x2===590){
		x2Speed=0,y2Speed=0;
	}
	if(x3===650){
		x3Speed=0,y3Speed=0;
	}
	if(x4===650){
		x4Speed=0,y4Speed=0;
	}
	if(x5===800){
		x5Speed=0,y5Speed=0;
	}
	if(x6===460){
		x6Speed=0,y6Speed=0;
	}
	
} 
floa();







