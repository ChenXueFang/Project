	/*广告的tab却换*/	
		function fn(n,m){
		for (var i = 1; i <= 7; i++) {
			var allli = document.getElementById("li"+i);
			allli.style.borderBottom = "1px solid red";
			allli.style.background = "#F3F3F3";
			var alldiv = document.getElementById("d"+i);
			alldiv.style.display = "none";
		}
		n.style.borderBottom = "white";
		var div = document.getElementById("d"+m);
		div.style.display = "block";
	}