/*
* @Author: PC
* @Date:   2019-02-21 11:05:48
* @Last Modified by:   PC
* @Last Modified time: 2019-02-21 11:14:24
*/

'use strict';
var lis = document.getElementById('erwei');
var uls = lis.childNodes[4];
console.log(uls);

lis.onmouseover= function(){
	uls.style.display ="block";
}
lis.onmouseout= function(){
	uls.style.display ="";
}