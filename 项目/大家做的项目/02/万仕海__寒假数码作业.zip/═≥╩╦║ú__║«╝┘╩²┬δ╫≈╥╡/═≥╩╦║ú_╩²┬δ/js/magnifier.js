


var ULd = document.getElementById('ULd');
// var LId = ULd.getElementsByTagName('li');
var spand = ULd.getElementsByTagName('span');
var ddTu = document.getElementById('ddTu');
var liTu = ddTu.getElementsByTagName('span');
var oBigImg = document.getElementById("bigImg");//大图
// var oBigImg2 = document.getElementById("bigImg2");//大图
console.log(liTu[1]);
var ULx = document.getElementById('ULx');
var LIx = ULx.getElementsByTagName('li');
var oMask = document.getElementById("mask");//黄色跟随鼠标盒子
var cenTu = document.getElementById('cenTu');

ULd.onmouseover = function(){
	 oMask.style.display = ddTu.style.display  ="block";


	console.log(1111111111111);

}
ULd.onmouseout = function(){
	  oMask.style.display = ddTu.style.display = "none";
}

ULd.onmousemove = function(ev){
	//3.1设置l与t的值 
	var l = ev.clientX-ULd.offsetLeft-oMask.offsetWidth/2;
	var t = ev.clientY-ULd.offsetTop-oMask.offsetHeight/2;
	console.log(11112212121);
	//3.3限定黄色盒子移动的范围
	//限定l与t 
	if(l<0){
		l=0;
	}
	if(l>ULd.offsetWidth-oMask.offsetWidth){
		l=ULd.offsetWidth-oMask.offsetWidth;
	}
	if(t<0){
		t=0;
	}
	if(t>ULd.offsetHeight-oMask.offsetHeight){
		t=ULd.offsetHeight-oMask.offsetHeight
	}
	//3.2给黄色盒子设置 
	oMask.style.left = l+"px";
	oMask.style.top= t +"px";

	//3.4设置大图 
	// oDiv.offsetWidth-oMask.offsetWidth
	// oBigImg.offsetWidth-oBigDiv.offsetWidth
	oBigImg.style.left = -l/(ULd.offsetWidth-oMask.offsetWidth) *(oBigImg.offsetWidth-ddTu.offsetWidth)+"px";
	oBigImg.style.top =-t/(ULd.offsetHeight-oMask.offsetHeight) *(oBigImg.offsetHeight-ddTu.offsetHeight)   +"px";
}

// ULd.onmousemove = function(ev){
// 	//3.1设置l与t的值 
// 	var l = ev.clientX-ULd.offsetLeft-oMask.offsetWidth/2;
// 	var t = ev.clientY-ULd.offsetTop-oMask.offsetHeight/2;
// 	console.log(11112212121);
// 	//3.3限定黄色盒子移动的范围
// 	//限定l与t 
// 	if(l<0){
// 		l=0;
// 	}
// 	if(l>ULd.offsetWidth-oMask.offsetWidth){
// 		l=ULd.offsetWidth-oMask.offsetWidth;
// 	}
// 	if(t<0){
// 		t=0;
// 	}
// 	if(t>ULd.offsetHeight-oMask.offsetHeight){
// 		t=ULd.offsetHeight-oMask.offsetHeight
// 	}
// 	//3.2给黄色盒子设置 
// 	oMask.style.left = l+"px";
// 	oMask.style.top= t +"px";

// 	//3.4设置大图 
// 	// oDiv.offsetWidth-oMask.offsetWidth
// 	// oBigImg.offsetWidth-oBigDiv.offsetWidth
// 	oBigImg2.style.left = -l/(ULd.offsetWidth-oMask.offsetWidth) *(oBigImg2.offsetWidth-ddTu.offsetWidth)+"px";
// 	oBigImg2.style.top =-t/(ULd.offsetHeight-oMask.offsetHeight) *(oBigImg2.offsetHeight-ddTu.offsetHeight)   +"px";
// }



//2循环遍历,遍历所有的li,绑定点击事件 
for(var i=0; i<LIx.length; i++){
	LIx[i].onmouseover = function(){
	    //i = 0, lis[0] spans[0]
		//3.第二层循环,用来给li与span绑定类的
		//点击到哪一个,哪一个就具有类
		for(var j=0; j<LIx.length; j++){
			//4.this指向lis[i]
				if(this == LIx[j]){
					LIx[j].className = "ULselt";
					spand[j].className = "ULshow";
					liTu[j].className = "bigImgg";

					// liTu[j].className = "ddLi"
				}else{
					LIx[j].className = "";
					liTu[j].className = "";
					spand[j].className = "";
					// liTu[j].className = ""

				}
		}	
	}	
}

