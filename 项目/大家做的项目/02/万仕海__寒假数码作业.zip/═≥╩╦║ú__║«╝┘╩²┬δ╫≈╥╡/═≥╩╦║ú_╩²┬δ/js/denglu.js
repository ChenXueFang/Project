
var Dlul = document.getElementById('chooseDL');
var DLlis =Dlul.getElementsByTagName('li'); 
var DLcen = document.getElementById('CHcenter');
var DLspans = DLcen.getElementsByTagName('span');


for(var i=0; i<DLlis.length; i++){
		DLlis[i].onclick = function(){
		    //i = 0, lis[0] spans[0]
			//3.第二层循环,用来给li与span绑定类的
			//点击到哪一个,哪一个就具有类
			for(var j=0; j<DLlis.length; j++){
				//4.this指向lis[i]
 				if(this == DLlis[j]){
 					DLlis[j].className = "chooesShow";
 					DLspans[j].className = "CHshow";
 				}else{
 					DLlis[j].className = "";
 					DLspans[j].className = "";
 				}
			}	
		}	
	}



// 手机注册-------------------------------------------

var inpt1 = document.getElementById("inp1");
var inpt2 = document.getElementById("inp2");
var spans = document.getElementById('inSpan');
var sunbmits = document.getElementById('submits');
var linker = document.getElementById('linker');
console.log(spans.value);

console.log(spans);

inpt1.onblur= function()
{
	//手机号
	var reg = /^((13[0-9])|(15[^4,\D])|(18[0-9]))\d{8}$/; 	
	var uuu = 18785522347;
	console.log(reg.test(uuu));
	var num = inpt1.value;
	console.log(reg.test(num));
	inpt2.onblur= function()
	{
	var reg2 = /^[0-9]{1,10}$/;
	var mima =  inpt2.value;
	if (reg2.test(mima)) 
		{
		if(reg.test(num)){ 
		    spans.className = "right";
		    spans.innerHTML="恭喜您,输入正确！";
		    linker.style.display = "block";
		   }
		else {
	        spans.className = "wrong";
	        spans.innerHTML="电话错误！";
		    }	
		}

		else 
		{
			spans.className = "wrong";
	        spans.innerHTML="密码有误";
		}


	sunbmits.onclick = function()
		{
			spans.style.display = "block";

		}

	}
	 
}   









