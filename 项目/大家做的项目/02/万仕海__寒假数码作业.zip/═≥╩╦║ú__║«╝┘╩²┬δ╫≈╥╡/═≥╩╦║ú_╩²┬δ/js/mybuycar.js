
var ul= document.getElementById('plusUl');
var lis = ul.getElementsByTagName('li');
var arrow = document.getElementById('arrow');
var arrLeft = document.getElementById('left');
var arrRight = document.getElementById('right');
	console.log(1111111);

ul.onmouseover = function(){
	arrow.style.display = "block";
	console.log(1111111);
}


// ul.onmouseout = function(){
// 	arrow.style.display = "";
// }

arrow.onmouseout = function(){
	arrow.style.display = "";
}
arrLeft.onclick = function(){
	lis[0].className = "showBuy";
	lis[1].className = "";
}

arrRight.onclick = function(){
	lis[0].className = "";
	lis[1].className = "showBuy";
}





