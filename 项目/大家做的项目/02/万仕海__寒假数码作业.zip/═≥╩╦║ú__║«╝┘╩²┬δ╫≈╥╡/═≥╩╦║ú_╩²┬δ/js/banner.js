
// 获取元素
var banner = document.getElementById('banner');

var ulsTab1 = banner.children[0];
var lisTab1 = ulsTab1.getElementsByTagName('li');
var tabContent = document.getElementById('tabContent');
var spanTab =tabContent.getElementsByTagName('span');
// li的背景
var lis1 = document.getElementById('goodthing');
var lis2 = document.getElementById('newthing');
var lis3 = document.getElementById('sellthing');
// span的背景
var span1 = document.getElementById('goodthingIn');
var span2 = document.getElementById('newthingIn');
var span3 = document.getElementById('sellthingIn');


console.log(ulsTab1);

console.log(lis2);
// console.log(lis3);



// 绑定事件 一定要做笔记 不能打开留着看
// lis1.onmouseover = function(){
// 	span1.className = "none";
// 	lis1.style.color= "red";
// 	span2.className = "none";
// 	span3.className = "none";
// // console.log(11111111111);
	
// }

// lis2.onmouseover = function(){
// 	span1.className ="goodthingInin";
// 	span2.className = "newthingInin";
// 	span3.className = "none";
// 	lis1.style.color = "black";
// // console.log(222222222222222);

// }
// lis3.onmouseover = function(){
// 	span3.className = "sellthingInin";
// 	span2.className = "none";
// 	span1.className = "goodthingInin";
// 	lis1.style.color = "black";
// }

for(var i=0; i<lisTab1.length; i++){
		lisTab1[i].onmouseover = function(){
		    //i = 0, lis[0] spans[0]
			//3.第二层循环,用来给li与span绑定类的
			//点击到哪一个,哪一个就具有类
			for(var j=0; j<lisTab1.length; j++){
				//4.this指向lis[i]
 				if(this == lisTab1[j]){
 					spanTab[j].className = "show";
 					if (this==lisTab1[0]) {
 						span1.className = "none";
						lis1.style.color= "red";
						span2.className = "none";
						span3.className = "none";
 					}
 					if (this==lisTab1[1]){
 						span1.className ="goodthingInin";
						span2.className = "newthingInin";
						span3.className = "none";
						lis1.style.color = "black";
 					}
 					if (this==lisTab1[2]){
 						span3.className = "sellthingInin";
						span2.className = "none";
						span1.className = "goodthingInin";
						lis1.style.color = "black";
 					}
 				}else{
 					spanTab[j].className = "";
 				}
			}	
		}	
	}

// 切换精品———————————————————————————————————————————————
// 1 获取元素
var goodsDirect= document.getElementById('goodsDirect');
var ulgs = goodsDirect.children[0];
var ligs =ulgs.getElementsByTagName('li');
var tabGoods = document.getElementById('tabGoods');
var spangs = tabGoods.getElementsByTagName('span');


//2循环遍历,遍历所有的li,绑定点击事件 
	for(var i=0; i<ligs.length; i++){
		ligs[i].onmouseover = function(){
		    //i = 0, lis[0] spans[0]
			//3.第二层循环,用来给li与span绑定类的
			//点击到哪一个,哪一个就具有类
			for(var j=0; j<ligs.length; j++){
				//4.this指向lis[i]
 				if(this == ligs[j]){
 					ligs[j].className = "goodsSelect";
 					spangs[j].className = "goodsShow";
 				}else{
 					ligs[j].className = "";
 					spangs[j].className = "";

 				}
			}	
		}	
	}

// /* 显示隐藏条 */


var ulssP= document.getElementById('ulssP1');
var ulssP2= document.getElementById('ulssP2');
var ulssP3= document.getElementById('ulssP3');
var ulssP4= document.getElementById('ulssP4');
var lissP = ulssP.getElementsByTagName('li');
var lissP2 = ulssP2.getElementsByTagName('li');
var lissP3 = ulssP3.getElementsByTagName('li');
var lissP4 = ulssP4.getElementsByTagName('li');

var price = document.getElementById("price");
var price1 = document.getElementById("price1");
var price2 = document.getElementById("price2");
var price3 = document.getElementById("price3");
var price4 = document.getElementById("price4");


var price00 = document.getElementById("price00");
var price11 = document.getElementById("price11");
var price22 = document.getElementById("price22");
var price33= document.getElementById("price33");
var price44 = document.getElementById("price44");


var price000 = document.getElementById("price000");
var price111 = document.getElementById("price111");
var price222 = document.getElementById("price222");
var price333 = document.getElementById("price333");
var price444 = document.getElementById("price444");


var price0000 = document.getElementById("price0000");
var price1111 = document.getElementById("price1111");
var price2222 = document.getElementById("price2222");
var price3333 = document.getElementById("price3333");
var price4444 = document.getElementById("price4444");

var timer = null;

// --------------0---------------
lissP[0].onmouseover = function(){		
 price.style.display = "block";
 console.log(11111);
}



lissP[0].onmouseout = function(){
    price.style.display = "none";
}

// ----------------1------------------
lissP[1].onmouseover = function(){		
 price1.style.display = "block";
}
lissP[1].onmouseout = function(){
    price1.style.display = "none";
}
// ----------------------2-------------
lissP[2].onmouseover = function(){		
 price2.style.display = "block";
}
lissP[2].onmouseout = function(){
    price2.style.display = "none";
}
// // ------------------3-----------------
lissP[3].onmouseover = function(){		
 price3.style.display = "block";
}
lissP[3].onmouseout = function(){
    price3.style.display = "none";
}
// ------------4------------------
lissP[4].onmouseover = function(){		
 price4.style.display = "block";
}
lissP[4].onmouseout = function(){
    price4.style.display = "none";
}


// --------------00---------------
lissP2[0].onmouseover = function(){		
 price00.style.display = "block";
 console.log(11111);
}
lissP2[0].onmouseout = function(){
    price00.style.display = "none";
}
// ----------------1------------------
lissP2[1].onmouseover = function(){		
 price11.style.display = "block";
}
lissP2[1].onmouseout = function(){
    price11.style.display = "none";
}
// ----------------------2-------------
lissP2[2].onmouseover = function(){		
 price22.style.display = "block";
}
lissP2[2].onmouseout = function(){
    price22.style.display = "none";
}
// // ------------------3-----------------
lissP2[3].onmouseover = function(){		
 price33.style.display = "block";
}
lissP2[3].onmouseout = function(){
    price33.style.display = "none";
}
// ------------4------------------
lissP2[4].onmouseover = function(){		
 price44.style.display = "block";
}
lissP2[4].onmouseout = function(){
    price44.style.display = "none";
}


// --------------000---------------
lissP3[0].onmouseover = function(){		
 price000.style.display = "block";
 console.log(11111);
}
lissP3[0].onmouseout = function(){
    price000.style.display = "none";
}
// ----------------1------------------
lissP3[1].onmouseover = function(){		
 price111.style.display = "block";
}
lissP3[1].onmouseout = function(){
    price111.style.display = "none";
}
// ----------------------2-------------
lissP3[2].onmouseover = function(){		
 price222.style.display = "block";
}
lissP3[2].onmouseout = function(){
    price222.style.display = "none";
}
// // ------------------3-----------------
lissP3[3].onmouseover = function(){		
 price333.style.display = "block";
}
lissP3[3].onmouseout = function(){
    price333.style.display = "none";
}
// ------------4------------------
lissP3[4].onmouseover = function(){		
 price444.style.display = "block";
}
lissP3[4].onmouseout = function(){
    price444.style.display = "none";
}


// --------------0000---------------
lissP4[0].onmouseover = function(){		
 price0000.style.display = "block";
 console.log(11111);
}
lissP4[0].onmouseout = function(){
    price0000.style.display = "none";
}
// ----------------1------------------
lissP4[1].onmouseover = function(){		
 price1111.style.display = "block";
}
lissP4[1].onmouseout = function(){
    price1111.style.display = "none";
}
// ----------------------2-------------
lissP4[2].onmouseover = function(){		
 price2222.style.display = "block";
}
lissP4[2].onmouseout = function(){
    price2222.style.display = "none";
}
// // ------------------3-----------------
lissP4[3].onmouseover = function(){		
 price3333.style.display = "block";
}
lissP4[3].onmouseout = function(){
    price3333.style.display = "none";
}
// ------------4------------------
lissP4[4].onmouseover = function(){		
 price4444.style.display = "block";
}
lissP4[4].onmouseout = function(){
    price4444.style.display = "none";
}
// 结束_______________________________________________________



// ----------------智能家居-----------------------------
var ddAi2 = document.getElementById('ddAi2');
var spanAis = ddAi2.getElementsByTagName('span');
var ddAi1 = document.getElementById('ddAi1');
console.log(ddAi1);
var aAis = ddAi1.getElementsByTagName('li');

var spannAi = ddAi2.children[0]; 
var spannAi11 = ddAi2.children[1]; 
var spannAi22 = ddAi2.children[2]; 
console.log(spannAi22);

var spannAiA = spannAi.children[0];
var spannAiA2 = spannAi.children[1];
 
var spannAiA11 = spannAi11.children[0];
var spannAiA211 = spannAi11.children[1];
 
var spannAiA22 = spannAi22.children[0];
var spannAiA222 = spannAi22.children[1];

spannAiA.onmouseover = function(){
	spannAiA222.style.display = 'none';
	spannAiA211.style.display = 'none';
	spannAiA2.style.display = 'block';
}

spannAiA11.onmouseover = function(){
	spannAiA211.style.display = 'block';
	spannAiA222.style.display = 'none';
	spannAiA2.style.display = 'none';
}

spannAiA22.onmouseover = function(){
	spannAiA222.style.display = 'block';
	spannAiA2.style.display = 'none';
	spannAiA211.style.display = 'none';

}

//2循环遍历,遍历所有的li,绑定点击事件 
	for(var i=0; i<spanAis.length; i++){
		spanAis[i].onmouseover = function(){
		    //i = 0, lis[0] spans[0]
			//3.第二层循环,用来给li与span绑定类的
			//点击到哪一个,哪一个就具有类
			for(var j=0; j<spanAis.length; j++){
				//4.this指向lis[i]
 				if(this == spanAis[j]){
 					spanAis[j].className = "spanShow";
 					aAis[j].className = "Aishow";
 				}else{
 					spanAis[j].className = "";
 					aAis[j].className = "";
 				}
			}	
		}	
	}

// --------------------2------------


var ddAi2Two = document.getElementById('ddAi2Two');
var spanAisTwo = ddAi2Two.getElementsByTagName('span');
var ddAi1Two = document.getElementById('ddAi1Two');
console.log(ddAi1Two);
var aAisTwo = ddAi1Two.getElementsByTagName('li');

var spannAiTwo = ddAi2Two.children[0]; 
var spannAi11Two = ddAi2Two.children[1]; 
var spannAi22Two = ddAi2Two.children[2]; 
console.log(spannAi22);

var spannAiATwo = spannAiTwo.children[0];
var spannAiA2Two= spannAiTwo.children[1];
 
var spannAiA11Two = spannAi11Two.children[0];
var spannAiA211Two = spannAi11Two.children[1];
 
var spannAiA22Two = spannAi22Two.children[0];
var spannAiA222Two = spannAi22Two.children[1];

spannAiATwo.onmouseover = function(){
	spannAiA222Two.style.display = 'none';
	spannAiA211Two.style.display = 'none';
	spannAiA2Two.style.display = 'block';
}

spannAiA11Two.onmouseover = function(){
	spannAiA211Two.style.display = 'block';
	spannAiA222Two.style.display = 'none';
	spannAiA2Two.style.display = 'none';
}

spannAiA22Two.onmouseover = function(){
	spannAiA222Two.style.display = 'block';
	spannAiA2Two.style.display = 'none';
	spannAiA211Two.style.display = 'none';

}

//2循环遍历,遍历所有的li,绑定点击事件 
	for(var i=0; i<spanAisTwo.length; i++){
		spanAisTwo[i].onmouseover = function(){
		    //i = 0, lis[0] spans[0]
			//3.第二层循环,用来给li与span绑定类的
			//点击到哪一个,哪一个就具有类
			for(var j=0; j<spanAisTwo.length; j++){
				//4.this指向lis[i]
 				if(this == spanAisTwo[j]){
 					spanAisTwo[j].className = "spanShowTwo";
 					aAisTwo[j].className = "AishowTwo";
 				}else{
 					spanAisTwo[j].className = "";
 					aAisTwo[j].className = "";
 				}
			}	
		}	
	}


// -----------------3-----------

var ddAi2Three = document.getElementById('ddAi2Three');
var spanAisThree = ddAi2Three.getElementsByTagName('span');
var ddAi1Three = document.getElementById('ddAi1Three');
console.log(ddAi1);
var aAisThree = ddAi1Three.getElementsByTagName('li');

var spannAiThree = ddAi2Three.children[0]; 
var spannAi11Three = ddAi2Three.children[1]; 
var spannAi22Three = ddAi2Three.children[2]; 
console.log(spannAi22);

var spannAiAThree = spannAiThree.children[0];
var spannAiA2Three = spannAiThree.children[1];
 
var spannAiA11Three = spannAi11Three.children[0];
var spannAiA211Three = spannAi11Three.children[1];
 
var spannAiA22Three = spannAi22Three.children[0];
var spannAiA222Three = spannAi22Three.children[1];

spannAiAThree.onmouseover = function(){
	spannAiA222Three.style.display = 'none';
	spannAiA211Three.style.display = 'none';
	spannAiA2Three.style.display = 'block';
}

spannAiA11Three.onmouseover = function(){
	spannAiA211Three.style.display = 'block';
	spannAiA222Three.style.display = 'none';
	spannAiA2Three.style.display = 'none';
}

spannAiA22Three.onmouseover = function(){
	spannAiA222Three.style.display = 'block';
	spannAiA2Three.style.display = 'none';
	spannAiA211Three.style.display = 'none';

}

//2循环遍历,遍历所有的li,绑定点击事件 
	for(var i=0; i<spanAisThree.length; i++){
		spanAisThree[i].onmouseover = function(){
		    //i = 0, lis[0] spans[0]
			//3.第二层循环,用来给li与span绑定类的
			//点击到哪一个,哪一个就具有类
			for(var j=0; j<spanAisThree.length; j++){
				//4.this指向lis[i]
 				if(this == spanAisThree[j]){
 					spanAisThree[j].className = "spanShowThree";
 					aAisThree[j].className = "AishowThree";
 				}else{
 					spanAisThree[j].className = "";
 					aAisThree[j].className = "";
 				}
			}	
		}	
	}




