/*
* @Author: 27242
* @Date:   2019-01-18 19:15:24
* @Last Modified by:   27242
* @Last Modified time: 2019-01-26 18:40:35
*/
window.onload = function(){
	function getId(id) {
        return document.getElementById(id);
    }
    // 我有艺龙合作卡
    var forms = document.getElementsByTagName("form")[0];
    var have_card = forms.getElementsByTagName("input")[0];
    var form_div = forms.getElementsByTagName("div");
    var form_em = forms.getElementsByTagName("em")[0];

    var number = document.getElementsByClassName("number")[0];
    var g_color = document.getElementsByClassName("g_color")[0];
    var g_colors = document.getElementsByClassName("g_color")[1];
    var g_color1 = document.getElementsByClassName("g_color1")[0];
    var g_color2 = document.getElementsByClassName("g_color2")[0];
    var g_color3 = document.getElementsByClassName("g_color3")[0];
    var g_color4 = document.getElementsByClassName("g_color4")[0];
    // 短信
    var mg = document.getElementsByClassName("mg")[0];
    var message = document.getElementsByClassName("message")[0];
    var ms_gain = message.getElementsByClassName("gain")[0];
    // 手机
    var phone_box = forms.getElementsByClassName("phone_box")[0];
    var msb = phone_box.getElementsByTagName("b")[0];
    // 同意及立即注册
    var agree = forms.getElementsByClassName("agree3")[0];
    var at_once = document.getElementsByClassName("at_once")[0];
    var agree_input = agree.getElementsByTagName("input")[0];
    console.log(at_once);
    // 验证码
    var txt=getId("txt");//输入框
    var code=getId("code");//验证码
    var submit=getId("submit");//提交按钮
    var arr=new Array(0,1,2,3,4,5,6,7,8,9,'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z');
   // 邮箱
    var e_mail = document.getElementsByClassName("e_mail")[1];
    var e_input = e_mail.getElementsByTagName("input")[0];
    // 再次输入密码
    var again = document.getElementsByClassName("again")[0];
    var ag_input = again.getElementsByTagName("input")[0];
    // 填写出行习惯
    var going = document.getElementsByClassName("going")[0];
    var go_span = going.getElementsByTagName("span")[0];
    var go_ul = going.getElementsByTagName("ul")[0];
    form_em.onclick = function(){
        is_check();
    }
    function is_check(){       
        if(have_card.checked){        
         for(let i = 0;i<3;i++){
            form_div[i].style.display = "block";
         }
        }else{ 
        for(let i = 0;i<3;i++){     
           form_div[i].style.display = "none";
        }
        }
    }

// 我有艺龙合作卡
    number.onfocus = function(){
        g_color.className = "right";
        g_color.style.display = "inline-block";
         g_color.innerText="请正确填写您的手机号码以便及时确认预定信息";
    }
    number.onblur = function(){
        g_color.style.display = "none";

    }

    mg.onfocus = function(){
        g_color1.style.display = "inline-block";

    }
    mg.onblur = function(){
        g_color1.style.display = "none";
    }
console.log(number);
    // 手机号码验证
    number.onblur = function(){
        var reg = /^1[34578]\d{9}$/;
        var number = this.value;
        if (reg.test(number)) {
            g_color.className = "";
            g_color.innerText="";
        }else if(this.value==""){
            g_color.className = "";
            g_color.innerText="";
        }else{
            g_color.innerText="请正确输入手机号";
            g_color.className = "error";
        }
    }
    // 输入验证码
    function shengchengCode(){
        code.value = ""
        for (var i = 0; i <4 ; i++) {
            //随机生成的下标
            var index = Math.floor(Math.random()*arr.length);
            code.value += arr[index];
        }
    }
        var r = Math.floor(Math.random()*256);
        var g = Math.floor(Math.random()*256);
        var b = Math.floor(Math.random()*256);
        code.style.color = "rgb("+r+","+g+","+b+")";
    shengchengCode();
    code.onclick = shengchengCode;
    submit.onclick = function(){
        shengchengCode();
    }
    // 短信后面的按钮事件
    ms_gain.onclick = function(){
        var reg1 = /^1[34578]\d{9}$/;
        var number1 = number.value;
        var txvalue=text.value;
        if(number1==""){
            g_color.innerText="请正确输入手机号";
            g_color.className = "error";
        }else if(reg1.test(number1)) {
            g_color.className = "";
            g_color.innerText="";

            if(txvalue==""){
                g_color3.style.display= "block";
                g_color3.innerText = "请输入验证码"
            }else if(txvalue!=code.value){
                g_color3.innerText="请输入正确验证码";
                g_color3.className = "error";
            }else{
                 g_color3.innerText="";
                g_color3.className = "";
            }
        }
    }

    // 密码
    e_input.onfocus = function(){
        g_color2.style.display = "inline-block";
    }
    e_input.onblur = function(){
        g_color2.style.display = "none";
    }
    // 再次输入密码
    ag_input.onfocus = function(){
        g_colors.style.display = "inline-block";
    }
    ag_input.onblur = function(){
        g_colors.style.display = "none";
    }
    go_span.onclick = function(){
        go_ul.style.display = "block";
            go_span.onclick = function(){
            go_ul.style.display = "none";
        }
    }

    // 立即注册
    at_once.onclick = function(){
        check();
    }
    function check(){       
        if(agree_input.checked){        
            g_color4.style.display = "none";
        }else{     
           g_color4.style.display = "block";
        }
    }











}