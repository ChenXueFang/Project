/*
* @Author: 27242
* @Date:   2019-01-19 18:08:27
* @Last Modified by:   27242
* @Last Modified time: 2019-01-20 19:37:03
*/
window.onload = function(){
	function getId(id) {
        return document.getElementById(id);
    }
// 验证码
    var txt=getId("text");//输入框
    var code=getId("code");//验证码
    var submit=getId("submit");//提交按钮
    var txt1=getId("text1");//输入框
    var code1=getId("code1");//验证码
    var submit1=getId("submit1");//提交按钮
    var arr=new Array(0,1,2,3,4,5,6,7,8,9,'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z');

    var input = document.getElementsByTagName("input");
    var care = document.getElementsByClassName("care")[0];
    var care1 = document.getElementsByClassName("care1")[0];
    var care2 = document.getElementsByClassName("care2")[0];
    var user = document.getElementsByClassName("user")[0];
    var phone_box = document.getElementsByClassName("phone_box")[0];
    var password = document.getElementsByClassName("password")[0];
    var validation = document.getElementsByClassName("validation")[0];
    var validation1 = document.getElementsByClassName("validation1")[0];
    var dongtai = document.getElementsByClassName("dongtai")[0];
    var dtspan = dongtai.getElementsByTagName("span")[0];
    var menber1 = document.getElementsByClassName("menber1")[0];
    var menber = document.getElementsByClassName("menber")[0];
    // 立即登录
    var log = document.getElementsByClassName("log")[0];
    

    var form_em = document.getElementsByTagName("em");

    var no_number = document.getElementsByClassName("no_number")[0];

    input[2].onfocus = function(){
    	input[2].placeholder = "";
    	care.style.display = "none";
    }
    input[2].onblur = function(){
    	if(input[2].value==""){
    		input[2].placeholder = "用户名/卡号/手机号邮箱";
   		}
    }
 //    	pwd.onblur = function(){
	// 	var userPwd = this.value;
	// 	var reghefa = /^1[34578]\d{9}$/;
	// 	//密码1位到10位都算合法
	// 	if(reghefa.test(userPwd)) {
	// 		spanmima.className = "right";
	// 		spanmima.innerHTML="输入正确";
	// 	}else{
	// 		spanmima.className = "wrong";
	// 		spanmima.innerHTML="格式不对";
	// 	}
	// }

    // 普通登录密码
    input[4].onfocus = function(){
    	input[4].placeholder = "";
    	care1.style.display = "none";
    }
    input[4].onblur = function(){
    	if(input[4].value==""){
    		input[4].placeholder = "密码";
   		}
    }


// 普通按钮验证码
    input[7].onfocus = function(){
    	input[7].placeholder = "";
    	input[7].style.borderColor = "#ccc";
    	care2.style.display = "none";
    }
    input[7].onblur = function(){
    	if(input[7].value==""){
    		input[7].placeholder = "验证码";
    		input[7].style.borderColor = "red";
   		}else if(input[7].value!=""){
   			input[7].style.borderColor = "red";
   		}
    }

    // 立即登录
    log.onclick = function(){
    	if(input[2].value==""){
    		care.style.display = "block";
    		care.innerText = "请输入账号名";
    	}
    	if(input[2].value!="" && input[4].value==""){
    		care1.style.display = "block";
    	}
    	if(input[2].value!="" && input[4].value!="" && input[7].value==""){
  			care2.style.display = "block";
  			care2.innerText = "请输入验证码";
  		}
  		if(input[2].value!="" && input[4].value!="" && (txt1.value!=code1.value)){
  			care2.innerText = "您输入的验证码不正确";
  			care2.style.display = "block";

  		}
  		if(input[4].value.length<6 && 31>input[4].value.length && input[7].value!="" && (txt1.value==code1.value)){
  			care.innerText = "密码长度不在6到32之间";
  			care.style.display = "block";
  		}
    	if(input[2].value!="6666666" && input[4].value!="6666666" && (txt1.value==code1.value)){
  			care.style.display = "block";
  			care.innerText = "登录用户名和密码不匹配";
  		}
     	if(input[2].value=="6666666" && input[4].value=="6666666" && (txt1.value==code1.value)){
  			alert("登录成功");
  		}
	}

    // 输入验证码
    function shengchengCode(){
        code.value = ""
        for (var i = 0; i <4 ; i++) {
            //随机生成的下标
            var index = Math.floor(Math.random()*arr.length);
            code.value += arr[index];
        }
    }
        var r = Math.floor(Math.random()*256);
        var g = Math.floor(Math.random()*256);
        var b = Math.floor(Math.random()*256);
        code.style.color = "rgb("+r+","+g+","+b+")";
    shengchengCode();
    code.onclick = shengchengCode;
    submit.onclick = function(){
        shengchengCode();
    }

    function shengchengCode1(){
        code1.value = ""
        for (var i = 0; i <4 ; i++) {
            //随机生成的下标
            var index = Math.floor(Math.random()*arr.length);
            code1.value += arr[index];
        }
    }
        var r = Math.floor(Math.random()*256);
        var g = Math.floor(Math.random()*256);
        var b = Math.floor(Math.random()*256);
        code1.style.color = "rgb("+r+","+g+","+b+")";
    shengchengCode1();
    code1.onclick = shengchengCode;
    submit1.onclick = function(){
        shengchengCode1();
    }
    form_em[1].onclick = function(){
        is_check();
        console.log("xx");
    }
    function is_check(){       
        if(input[1].checked){        
            user.style.display = "none";
            password.style.display = "none";
            validation1.style.display = "none";
            care.style.display = "none";
            care1.style.display = "none";
            care2.style.display = "none";
            menber1.style.display = "none";
            no_number.style.display = "block";
            menber.style.display = "block";
            validation.style.display = "block";
            dongtai.style.display = "block";
            phone_box.style.display = "block";


                // 登录
	    log.onclick = function(){
	    	var userPwd2 = input[3].value;
			var reghefa2 = /^1[34578]\d{9}$/;

			if(input[3].value==""){
	    		input[3].placeholder = "请输入手机号";
	    		care.style.display = "block";
	   		}
	   		if(reghefa2.test(userPwd2) && input[5].value!=input[6].value){
	   			care2.style.display = "block";
	   		}
	   		if(reghefa2.test(userPwd2) && input[5].value==input[6].value){
	   			alert("登录成功");
	   			care2.style.display = "none";
	   		}
	    }
    }console.log(input[6]);
    
    form_em[0].onclick = function(){
        is_check1();
        // console.log("xx");
    }
    function is_check1(){       
        if(input[0].checked){        
            user.style.display = "block";
            password.style.display = "block";
            validation1.style.display = "block";
            menber1.style.display = "block";
            no_number.style.display = "none";
            menber.style.display = "none";
            validation.style.display = "none";
            dongtai.style.display = "none";
            phone_box.style.display = "none";
        }
    }

    // 获取验证码
    dtspan.onclick = function(){
    	var userPwd = input[3].value;
		var reghefa = /^1[34578]\d{9}$/;
    	if(input[3].value==""){
    		care.style.display = "block";
    	}
		if(reghefa.test(userPwd) && input[5].value!=code.value){
   			care1.style.display = "block";
   			care1.innerText = "您输入的验证码不正确";
   		}else{
   			care1.style.display = "none";
   		}
    }

    // 手机动态1
    console.log(input[5]);
    input[3].onfocus = function(){
    	input[3].placeholder = "";
    	care.style.display = "none";
    }
    input[3].onblur = function(){
    	var userPwd1 = this.value;
		var reghefa1 = /^1[34578]\d{9}$/;
    	if(input[3].value==""){
    		input[3].placeholder = "请输入手机号";
   		}
   		if(reghefa1.test(userPwd1)){
   			care.style.display = "none";
   		}else if(input[3].value!=""){
   			input[3].value = "";
   			input[3].placeholder = "请输入手机号";
   			care.style.display = "block";
   		}else{
   			care.style.display = "block";
   			care.innerText = "请输入合法手机号";
   		}
    }

    // 手机动态验证码1
    input[5].onfocus = function(){
    	input[5].placeholder = "";
    	care1.style.display = "none";
    }
    input[5].onblur = function(){
    	if(input[5].value==""){
    		input[5].placeholder = "验证码";
   		}
   		care.style.display = "none";
    }

    input[9].onfocus = function(){
    	input[9].placeholder = "";
    	care2.style.display = "none";
    }
    input[9].onblur = function(){
    	if(input[9].value==""){
    		input[9].placeholder = "请输入验证码";
   		}
   		care.style.display = "none";
    }




}}