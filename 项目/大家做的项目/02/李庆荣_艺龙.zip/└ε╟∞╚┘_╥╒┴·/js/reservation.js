/*
* @Author: 27242
* @Date:   2019-01-21 10:27:51
* @Last Modified by:   27242
* @Last Modified time: 2019-01-26 16:04:04
*/
window.onload = function(){
	var hd = document.getElementsByTagName("header")[0];
	var ul1 = hd.getElementsByTagName("ul")[0];
	// 获取语言标签
	var ul2 = ul1.getElementsByTagName("ul")[0];
	// 获取语言里面鼠标放上去才显示的标签
	var li1 = ul2.getElementsByTagName("li")[1];
	var li2 = ul2.getElementsByTagName("li")[2];
	// 获取头部三个定位的父元素
	var little_pg = document.getElementById("little_pg");
	var phone = document.getElementById("phone");
	var edphone = document.getElementById("edphone");
	// 头部第二个图片手机
	var phonesvg = phone.getElementsByTagName("svg")[0];
	// 获取三个头部定位内容
	var xcx_pic = document.getElementsByClassName("xcx")[0];
	var ph = document.getElementsByClassName("ph")[0];
	var phumber = document.getElementById("phumber");
	// 获取获取头部第一个箭头向上定位内容
	var jt_up = document.getElementById("up");

	// 黄山市
	var mdd = document.getElementsByClassName("mdd")[0];
	var mdd_input = mdd.getElementsByTagName("input")[0];
	
	var chengshi = document.getElementsByClassName("chengShi")[0];
	// 城市里的p标签
	var cs_p = chengshi.getElementsByTagName("p")[0];
	// 城市里的span标签
	var cs_span = chengshi.getElementsByTagName("span");
	// console.log(cs_p);
	var cs = chengshi.getElementsByTagName("div");
	console.log(mdd_input);
		var title_cs = chengshi.getElementsByClassName("title_cs")[0];
	var title_li = title_cs.getElementsByTagName("li");
		// 语言设置效果
		// 
		// 
			// 酒店的日历
	var date = document.getElementsByClassName("date")[0];
	var dttable = date.getElementsByTagName("table");
	// 年月日显示
	var dtspan = date.getElementsByTagName("span");
	// date里面的上面部分
	var dt_title = date.getElementsByClassName("dt_title")[0];
	// date里面的下面部分
	var date_list = date.getElementsByClassName("date_list")[0];
	// date里面的下面部分的背景
	var date_bg = date_list.getElementsByTagName("div");
	var dt_img = dt_title.getElementsByTagName("img");

	var go_zhu = document.getElementsByClassName("go_zhu")[0];
	var go_zhu_input = go_zhu.getElementsByTagName("input")[0];
	// console.log(go_zhu_span);
	// 
	// 	// 关键字
	var keyWord = document.getElementsByClassName("keyWord")[0];

	var reserve_keywords = document.getElementsByClassName("reserve_keywords")[0];
	var keyword_input = reserve_keywords.getElementsByTagName("input")[0];

	// 热门
	var Hot = document.getElementsByClassName("Hot")[0];
	var hotul = Hot.getElementsByTagName("ul")[0];
	var hotli1 = hotul.getElementsByTagName("li");
	var hotul2 = Hot.getElementsByTagName("ul")[1];
	var hotli2 = hotul2.getElementsByTagName("li");
	// 右边按钮
	var hotspan = hotul2.getElementsByTagName("span");
	console.log(hotspan);
	var Hot_right_con = Hot.getElementsByClassName("Hot_right_con")[0];
	// 隐藏部分
	var Hot_right_con_div = Hot_right_con.getElementsByTagName("div");
	
	var locked = document.getElementsByClassName("locked")[0];
	var locked1 = document.getElementsByClassName("locked")[1];
	var lockedUl = locked.getElementsByTagName("ul")[0];
	var lockedUl_li = lockedUl.getElementsByTagName("li");

	var locked_choose = locked.getElementsByClassName("locked_choose")[0];
	var locked_choose_son = locked_choose.children;

	var locked1svg = locked1.getElementsByTagName("svg");
	// 自定义
	var aotu_set = document.getElementsByClassName("aotu_set");
	var up_jt = document.getElementById('up_jt');
	var up_jt1 = document.getElementById('up_jt1');
	var up_jt2 = document.getElementById('up_jt2');
	// 最后一个隐藏部分
	var xljc = document.getElementById('xljc');
	var xljc1 = document.getElementById('xljc1');

	var Hots = document.getElementById('Hots');
	var hotsafter = Hots.getElementsByTagName("input:after");


	var reserve_pic1 = document.getElementsByClassName("reserve_pic1")[0];
	var banner_pic = document.getElementsByClassName("banner_pic")[0];
	// 达人推荐左右箭头及大盒子
	var recommended = document.getElementsByClassName("recommended")[0];
	var recommended_left_pic = recommended.getElementsByClassName("recommended_left_pic")[0];
	var recommended_right_pic = recommended.getElementsByClassName("recommended_right_pic")[0];

	var recommended1 = document.getElementsByClassName("recommended")[1];
	var recommended_left_pic1 = recommended1.getElementsByClassName("recommended_left_pic")[0];
	var recommended_right_pic1 = recommended1.getElementsByClassName("recommended_right_pic")[0];
	// 历史浏览
	var History_title = document.getElementsByClassName("History_title")[0];
	var historyspan = History_title.children;

	var History = document.getElementsByClassName("History")[0];
	var Historys = document.getElementById("Historys");
	var Historycon = Historys.children;
	// var Historycon = Historys.children;

	var Collection = document.getElementsByClassName("Collection")[0];
	var Historycon_li = Historycon[5].children;

	var next_page =  document.getElementsByClassName("next_page")[0];
	var next_page_a = next_page.children;

	var jd_info = document.getElementsByClassName("jd_info")[0];
	var jd_info_b = jd_info.children[1];

	var jd_info_word = document.getElementsByClassName("jd_info_word")[0];


	var Box_right = document.getElementsByClassName("Box_right")[0];
	console.log(jd_info_b);
	// console.log(logo_icon_icon[2]);
	ul2.onmouseover = function(){
		li1.style.display = "block";
		li2.style.display = "block";
		ul2.style.zIndex = "4";
		li1.className = "bref" ;
		ul2.style.borderColor = "#999";
	}
	ul2.onmouseout = function(){	
		li1.style.display = "none";
		li2.style.display = "none";
		ul2.style.borderColor = "#fff";
	}

	// 右边图片设置效果
	little_pg.onmouseover = function(){
		xcx_pic.style.display = "block";
		jt_up.style.display = "block";

	}
	little_pg.onmouseout = function(){
		xcx_pic.style.display = "none";
		jt_up.style.display = "none";

	}
	phone.onmouseover = function(){
		ph.style.display = "block";

	}
	phone.onmouseout = function(){
		ph.style.display = "none";

	}
	edphone.onmouseover = function(){
		phumber.style.display = "block";

	}
	edphone.onmouseout = function(){
		phumber.style.display = "none";

	}
	// 让手机动起来
	var timer = setInterval(function(){
		phonesvg.style.transform = "rotate(15deg)";
	},250);
	var timer1 = setInterval(function(){
		phonesvg.style.transform = "rotate(-15deg)";
	},500);



	// 酒店目的地默认（最开始进入网站时）样式
	mdd_input.onfocus = function(){
		chengshi.style.display = "block";
		cs[0].style.display = "block";
	}


	// 字母列表切换及样式
	// 一、目的地
	for(let k = 0;k<title_li.length;k++){
		title_li[k].onclick = function(){
			for(let l = 0;l<title_li.length;l++){
				title_li[l].className = "";
				cs[l].style.display = "none";
			}
			this.className = "title_bg";
			cs[k].style.display = "block";
		}
	}

		// 鼠标点击区域内。不会消失。点击外面就会消失
	document.onclick=function(event){
       var e=event || window.event;//兼容ie和非ie的event
       var aim=e.srcElement || e.target; //兼容ie和非ie的事件源
       if(e.srcElement){
        var aim=e.srcElement;

		if(aim!=mdd_input && aim!=chengshi && aim!=title_cs && aim!=title_li[0] && aim!=title_li[1] && aim!=title_li[2] && aim!=title_li[3] && aim!=title_li[4]&& aim!=title_li[5]){
          chengshi.style.display="none";
         }
		if(aim!=mdd_input && aim!=chengshi && aim!=title_cs && aim!=title_li[0] && aim!=title_li[1] && aim!=title_li[2] && aim!=title_li[3] && aim!=title_li[4]&& aim!=title_li[5]){
          chengshi.style.display="none";
         }
		if(aim != go_zhu_input && aim!=dt_img[0] && aim!=dt_img[1]){
			date.style.display = "none";
		}
       }else{
         var aim=e.target;
		if(aim!=mdd_input && aim!=chengshi && aim!=title_cs && aim!=title_li[0] && aim!=title_li[1] && aim!=title_li[2] && aim!=title_li[3] && aim!=title_li[4]&& aim!=title_li[5]){
          chengshi.style.display="none";
         }
		if(aim!=dt_img[0] && aim!=dt_img[1]){
			date.style.display = "none";
		}
       }
      }



	dttable[2].style.display = "block";
	dttable[3].style.display = "block";
	date_bg[2].style.display = "block";
	date_bg[3].style.display = "block";
	go_zhu_input.onfocus = function(){
		date.style.display = "block";
		dtspan[0].innerText = "2019年1月";
		dtspan[1].innerText = "2019年2月";
	}
	dt_img[0].onclick = function(){
		for(let i = 0;i<6;i++){
			dttable[i].style.display = "none";
			date_bg[i].style.display = "none";
		}
		dttable[0].style.display = "block";
		dttable[1].style.display = "block";
		date_bg[0].style.display = "block";
		date_bg[1].style.display = "block";
		dtspan[0].innerText = "2018年11月";
		dtspan[1].innerText = "2018年12月";

		dt_img[1].onclick = function(){
			for(let i = 0;i<6;i++){
				dttable[i].style.display = "none";
				date_bg[i].style.display = "none";
			}
			dttable[2].style.display = "block";
			dttable[3].style.display = "block";
			date_bg[2].style.display = "block";
			date_bg[3].style.display = "block";
			dtspan[0].innerText = "2019年1月";
			dtspan[1].innerText = "2019年2月";

			dt_img[1].onclick = function(){
				for(let i = 0;i<6;i++){
					dttable[i].style.display = "none";
					date_bg[i].style.display = "none";
				}
				dttable[4].style.display = "block";
				dttable[5].style.display = "block";
				date_bg[4].style.display = "block";
				date_bg[5].style.display = "block";
				dtspan[0].innerText = "2019年3月";
				dtspan[1].innerText = "2019年4月";
				dt_img[0].onclick = function(){
					for(let i = 0;i<6;i++){
						dttable[i].style.display = "none";
						date_bg[i].style.display = "none";
					}
					dttable[0].style.display = "block";
					dttable[1].style.display = "block";
					date_bg[0].style.display = "block";
					date_bg[1].style.display = "block";
					dtspan[0].innerText = "2018年11月";
					dtspan[1].innerText = "2018年12月";

					dt_img[1].onclick = function(){
						for(let i = 0;i<6;i++){
							dttable[i].style.display = "none";
							date_bg[i].style.display = "none";
						}
						dttable[2].style.display = "block";
						dttable[3].style.display = "block";
						date_bg[2].style.display = "block";
						date_bg[3].style.display = "block";
						dtspan[0].innerText = "2019年1月";
						dtspan[1].innerText = "2019年2月";

						dt_img[1].onclick = function(){
							for(let i = 0;i<6;i++){
								dttable[i].style.display = "none";
								date_bg[i].style.display = "none";
							}
							dttable[4].style.display = "block";
							dttable[5].style.display = "block";
							date_bg[4].style.display = "block";
							date_bg[5].style.display = "block";
							dtspan[0].innerText = "2019年3月";
							dtspan[1].innerText = "2019年4月";
						}
					}
				}
			}
		}
	}
	dt_img[1].onclick = function(){
		for(let i = 0;i<6;i++){
			dttable[i].style.display = "none";
			date_bg[i].style.display = "none";
		}
		dttable[4].style.display = "block";
		dttable[5].style.display = "block";
		date_bg[4].style.display = "block";
		date_bg[5].style.display = "block";
		dtspan[0].innerText = "2019年3月";
		dtspan[1].innerText = "2019年4月";

		dt_img[0].onclick = function(){
			for(let i = 0;i<6;i++){
				dttable[i].style.display = "none";
				date_bg[i].style.display = "none";
			}
			dttable[2].style.display = "block";
			dttable[3].style.display = "block";
			date_bg[2].style.display = "block";
			date_bg[3].style.display = "block";
			dtspan[0].innerText = "2018年11月";
			dtspan[1].innerText = "2018年12月";

			dt_img[0].onclick = function(){
				for(let i = 0;i<6;i++){
					dttable[i].style.display = "none";
					date_bg[i].style.display = "none";
				}
				dttable[0].style.display = "block";
				dttable[1].style.display = "block";
				date_bg[0].style.display = "block";
				date_bg[1].style.display = "block";
				dtspan[0].innerText = "2018年11月";
				dtspan[1].innerText = "2018年12月";


				dt_img[0].onclick = function(){
					for(let i = 0;i<6;i++){
						dttable[i].style.display = "none";
						date_bg[i].style.display = "none";
					}
					dttable[0].style.display = "block";
					dttable[1].style.display = "block";
					date_bg[0].style.display = "block";
					date_bg[1].style.display = "block";
					dtspan[0].innerText = "2018年11月";
					dtspan[1].innerText = "2018年12月";

					dt_img[1].onclick = function(){
						for(let i = 0;i<6;i++){
							dttable[i].style.display = "none";
							date_bg[i].style.display = "none";
						}
						dttable[2].style.display = "block";
						dttable[3].style.display = "block";
						date_bg[2].style.display = "block";
						date_bg[3].style.display = "block";
						dtspan[0].innerText = "2019年1月";
						dtspan[1].innerText = "2019年2月";

						dt_img[1].onclick = function(){
							for(let i = 0;i<6;i++){
								dttable[i].style.display = "none";
								date_bg[i].style.display = "none";
							}
							dttable[4].style.display = "block";
							dttable[5].style.display = "block";
							date_bg[4].style.display = "block";
							date_bg[5].style.display = "block";
							dtspan[0].innerText = "2019年3月";
							dtspan[1].innerText = "2019年4月";
						}
					}
				}
			}
		}
	}


	//关键字
	keyword_input.onfocus = function(){
		keyWord.style.display = "block";
	}
	keyword_input.onblur = function(){
		keyWord.style.display = "none";
	}
	// 热门下拉列表
	for(let j = 0;j<3;j++){
		hotli1[j].onclick = function(){
			hotli1[j].index = j+1;
			for(let i = 0;i<3;i++){
				hotli1[i].index = i+1;
				hotli1[i].className = "";
				Hot_right_con_div[i+1].style.display = "none";
			}
			this.className = "remen_ckeck";
			Hot_right_con_div[j+1].style.display = "block";
			console.log("chenggong");
		}
	}
	// 热门radio
	for(let j = 0;j<3;j++){
		hotli2[j].index = j;
		hotli2[j].onmouseover = function(){
			this.style.color = "#4598ff";
			// hotsafter.style.display = "none";
			hotspan[j].style.borderColor = "#4598ff";
		}
		hotli2[j].onmouseout = function(){
			this.style.color = "#555";
			hotspan[j].style.borderColor = "#ccc";
			// hotsafter.style.display = "none";
		}
	}
	// 热门下拉列表
	for(let j = 0;j<7;j++){
		lockedUl_li[j].onclick = function(){
			lockedUl_li[j].index = j;
			for(let i = 0;i<7;i++){
				lockedUl_li[i].index = i;
				lockedUl_li[i].className = "";
				locked_choose_son[i].style.display = "none";
				// locked_choose.style.display = "none";
			}
			this.className = "remen_ckeck";
			// Hot_right_con_div[j+1].style.display = "block";
			locked_choose_son[j].style.display = "block";
			locked_choose.style.display = "block";
			console.log("chenggong");
		}
	}

	// 自加与自减按钮
	locked1svg[0].onmouseover = function(){
		locked1svg[0].style.display = "block";
		locked1svg[2].style.display = "block";
	}
	locked1svg[2].onmouseover = function(){
		locked1svg[0].style.display = "block";
		locked1svg[2].style.display = "block";
	}
	locked1svg[1].onmouseover = function(){
		locked1svg[1].style.display = "block";
		locked1svg[3].style.display = "block";
	}
	locked1svg[3].onmouseover = function(){
		locked1svg[1].style.display = "block";
		locked1svg[3].style.display = "block";
	}
	aotu_set[0].onmouseover = function(){
		locked1svg[0].style.display = "block";
		locked1svg[2].style.display = "block";
	}
	aotu_set[0].onmouseout = function(){
		locked1svg[0].style.display = "none";
		locked1svg[2].style.display = "none";
	}
	aotu_set[1].onmouseover = function(){
		locked1svg[1].style.display = "block";
		locked1svg[3].style.display = "block";
	}
	aotu_set[1].onmouseout = function(){
		locked1svg[1].style.display = "none";
		locked1svg[3].style.display = "none";
	}
	// 自加与自减
	var g = 0;
	locked1svg[0].onclick = function(){
		g++;
		aotu_set[0].value = g;
		aotu_set[0].focus();
	}
	locked1svg[1].onclick = function(){
		g++;
		aotu_set[1].value = g;
		aotu_set[1].focus();
	}
	locked1svg[2].onclick = function(){
		g--;
		aotu_set[0].value = g;
		aotu_set[0].focus();
	}
	locked1svg[3].onclick = function(){
		g--;
		aotu_set[1].value = g;
		aotu_set[1].focus();
	}

	up_jt.onclick = function(){
		// this.style.color = "red";
		this.style.background = "#ccc";
		this.style.borderRadius = "100%";
		up_jt.className = "logo icon-arrow-right-copy";
		up_jt.onclick = function(){
			// this.style.color = "red";
			up_jt.className = "logo icon-icon";
		}
		up_jt.onmouseover = function(){
			this.style.background = "blue";
			this.style.color = "#fff";
		}
		up_jt.onmouseout = function(){
			this.style.background = "#fff";
			this.style.color = "#555";
		}
	}
	up_jt1.onclick = function(){
		// this.style.color = "red";
		this.style.background = "#ccc";
		this.style.borderRadius = "100%";
		up_jt1.className = "logo icon-arrow-right-copy";
		up_jt1.onclick = function(){
			// this.style.color = "red";
			up_jt1.className = "logo icon-icon";
		}
		up_jt1.onmouseover = function(){
			this.style.background = "blue";
			this.style.color = "#fff";
		}
		up_jt1.onmouseout = function(){
			this.style.background = "#fff";
			this.style.color = "#555";
		}
	}
	up_jt2.onclick = function(){
		this.style.background = "#ccc";
		this.style.borderRadius = "100%";
		xljc.style.display = "block";
		xljc1.style.display = "block";
		up_jt2.className = "logo icon-arrow-right-copy";
		up_jt2.onclick = function(){
			xljc.style.display = "none";
			xljc1.style.display = "none";
			up_jt2.className = "logo icon-icon";
		}
		up_jt2.onmouseover = function(){
			this.style.background = "blue";
			this.style.color = "#fff";
		}
		up_jt2.onmouseout = function(){
			this.style.background = "#fff";
			this.style.color = "#555";
		}
	}

	// banner预定房子图片
	reserve_pic1.onmouseover = function(){
		banner_pic.style.display = "block";
	}
	reserve_pic1.onmouseout = function(){
		banner_pic.style.display = "none";
	}


// 达人推荐

	recommended_left_pic.onclick = function(){
		recommended1.style.display = "block";
		recommended.style.display = "none";
	}
	recommended_right_pic.onclick = function(){
		recommended1.style.display = "block";
		recommended.style.display = "none";
	}
	recommended_left_pic1.onclick = function(){
		recommended.style.display = "block";
		recommended1.style.display = "none";
		console.log("00000");
	}
	recommended_right_pic1.onclick = function(){
		recommended.style.display = "block";
		recommended1.style.display = "none";
	}


	// 历史浏览
	historyspan[0].onclick = function(){
		historyspan[0].style.color = "#49f";
		historyspan[1].style.color = "#555";
		historyspan[2].style.left = "30px";
		Historys.style.display = "block";
		History.style.height = "274px";
		Collection.style.display = "none";
	}
	historyspan[1].onclick = function(){
		historyspan[0].style.color = "#555";
		historyspan[1].style.color = "#49f";
		historyspan[2].style.left = "100px";
		Historys.style.display = "none";
		History.style.height = "234px";
		Collection.style.display = "block";
	}
	Historycon_li[0].style.background = "#49f";
	Historycon_li[0].onclick = function(){
		for(let i = 0;i<5;i++){
			Historycon[i].style.display = "none";
		}
		for(let i = 0;i<3;i++){
			Historycon_li[i].style.background = "#e6eff8";
		}
		this.style.background = "#49f";
		Historycon[0].style.display = "block";
		Historycon[1].style.display = "block";
	}
	Historycon_li[1].onclick = function(){
		for(let i = 0;i<5;i++){
			Historycon[i].style.display = "none";
		}
		for(let i = 0;i<3;i++){
			Historycon_li[i].style.background = "#e6eff8";
		}
		this.style.background = "#49f";
		Historycon[2].style.display = "block";
		Historycon[3].style.display = "block";
	}
	Historycon_li[2].onclick = function(){
		for(let i = 0;i<5;i++){
			Historycon[i].style.display = "none";
		}
		for(let i = 0;i<3;i++){
			Historycon_li[i].style.background = "#e6eff8";
		}
		this.style.background = "#49f";
		Historycon[4].style.display = "block";
	}


	for(let i = 0;i<9;i++){
		next_page_a[i].onclick = function(){
			for(let j = 0;j<9;j++){
				next_page_a[j].style.background = "#fff";
			}
			this.style.background = "#49f";
		}
	}
// 黄山市酒店信息
	
	jd_info_b.onclick = function(){
		if(jd_info_b.className=="logo icon-jia"){
			jd_info_b.className = "logo icon-jian";
			jd_info_word.style.display = "block";
		}else{
			jd_info_b.className = "logo icon-jia";
			jd_info_word.style.display = "none";
		}
	}
	
             //1.老三步。
             //右边大盒子
    var topDiv = document.getElementsByClassName("go_login")[0];
    window.onscroll = function computedDisplay(){//不管怎么操作的，只要滚动条动了就会触发这个行为
	    var curTop = document.documentElement.scrollTop || document.body.scrollTop;
	    var curHeight = document.documentElement.clientHeight || document.body.clientHeight;
	    console.log(curTop);
	    if(curTop>=540 && curTop < 2200){
	      Box_right.style.display = "block";
	      Box_right.className = "fixed";
	    }else if(curTop>=2200){
	      Box_right.style.display = "block";
	      Box_right.className = "fixed_1";
	    }else{
	    	Box_right.style.display = "block";
	      	Box_right.className = "Box_right";
	    }
	}







}