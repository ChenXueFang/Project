/*
* @Author: 27242
* @Date:   2019-01-07 12:17:35 lvyou
* @Last Modified by:   chenxuefang
* @Last Modified time: 2019-02-23 17:13:42
*/
window.onload = function(){
	var hd = document.getElementsByTagName("header")[0];
	var ul1 = hd.getElementsByTagName("ul")[0];
	// 获取语言标签
	var ul2 = ul1.getElementsByTagName("ul")[0];
	// 获取语言里面鼠标放上去才显示的标签
	var li1 = ul2.getElementsByTagName("li")[1];
	var li2 = ul2.getElementsByTagName("li")[2];
	// 获取头部三个定位的父元素
	var little_pg = document.getElementById("little_pg");
	var phone = document.getElementById("phone");
	var edphone = document.getElementById("edphone");
	// 头部第二个图片手机
	var phonesvg = phone.getElementsByTagName("svg")[0];
	// 获取三个头部定位内容
	var xcx_pic = document.getElementsByClassName("xcx")[0];
	var ph = document.getElementsByClassName("ph")[0];
	var phumber = document.getElementById("phumber");
	// 获取获取头部第一个箭头向上定位内容
	var jt_up = document.getElementById("up");
	
	// banner区域的
	var banners = document.getElementById("banner");
	var ul = banners.getElementsByTagName("ul")[0];
	var aArr = ul.getElementsByTagName("a");
	var imgs = ul.getElementsByTagName("img")[0];
	var div = banners.getElementsByTagName("div")[0];
	var spans = div.getElementsByTagName("span");
	var timer = null;

	// banner定位大区域
	var service = banners.getElementsByClassName("service")[0];
	var banner_service = service.children;
	console.log(banner_service[3]);
	// 关键字
	var keyWord = document.getElementsByClassName("keyWord")[0];
	var banner_service0 = document.getElementById("banner_service0");
	var banner_service1 = document.getElementById("banner_service1");
	var banner_service2 = document.getElementById("banner_service2");
	var focus_ad = banner_service0.getElementsByTagName("form")[0];
	// 酒店的日历
	var date = document.getElementsByClassName("date")[0];
	var dttable = date.getElementsByTagName("table");
	// 年月日显示
	var dtspan = date.getElementsByTagName("span");
	// date里面的上面部分
	var dt_title = date.getElementsByClassName("dt_title")[0];
	// date里面的下面部分
	var date_list = date.getElementsByClassName("date_list")[0];
	// date里面的下面部分的背景
	var date_bg = date_list.getElementsByTagName("div");
	var dt_img = dt_title.getElementsByTagName("img");
	console.log(date_bg);
	// 酒店日历获取
	var ruzhu = focus_ad.getElementsByTagName("input")[1];
	console.log(ruzhu);
	var jiudian = service.getElementsByTagName("ul")[0];
	//酒店图标
	var use_1 = jiudian.getElementsByTagName("use")[0];
	// 目的地
	var focus_sp = focus_ad.getElementsByTagName("input")[0];
	// 入住
	// var ruzhu_sp = focus_ad.getElementsByTagName("input")[1];
	//退房
	var tuifang_sp = focus_ad.getElementsByTagName("input")[2];
	// 关键字
	var gjz_sp = focus_ad.getElementsByTagName("input")[3];
	// 地图搜索
	var map_a = focus_ad.getElementsByTagName("a")[1];
	// 机票
	var hclx = banner_service1.getElementsByTagName("div")[1];
	// 单程
	var single = hclx.getElementsByTagName("input")[0];
	// 往返
	var wf = hclx.getElementsByTagName("input")[1];
	// 往返城市
	var wfcs = banner_service1.getElementsByTagName("div")[2];
	// 北京
	var bj = wfcs.getElementsByTagName("input")[0];
	// 上海
	var sh = wfcs.getElementsByTagName("input")[1];
	// 去程返程
	var qcfc = banner_service1.getElementsByTagName("div")[3];
	// 去程
	var qc = qcfc.getElementsByTagName("input")[0];
	// 返程
	var fc = qcfc.getElementsByTagName("input")[1];
	// 火车票往返城市
	var hcp = banner_service2.getElementsByTagName("div")[0];
	// 火车票北京
	var bj1 = hcp.getElementsByTagName("input")[0];
	// 火车票上海
	var sh1 = hcp.getElementsByTagName("input")[1];
	var service_ul = service.getElementsByTagName("ul")[0];
	var service_li = service_ul.getElementsByTagName("li");
	console.log(div);
	// console.log(sh1);

	// 国际酒店
	var guojiSpan1 = banner_service0.getElementsByTagName("span")[0];
	var guojiSpan2 = banner_service0.getElementsByTagName("span")[1];
	// 机票
	var guojiSpan3 = banner_service1.getElementsByTagName("span")[0];
	var guojiSpan4 = banner_service1.getElementsByTagName("span")[1];
	//热门内容
	
	var chengshi = document.getElementsByClassName("chengShi")[0];
	var chengshi1 = document.getElementById("chengShi1");
	var chengshi2 = document.getElementById("chengShi2");
	var chengshi3 = document.getElementById("chengShi3");
	var chengshi4 = document.getElementById("chengShi4");
	// 城市里的p标签
	var cs_p = chengshi.getElementsByTagName("p")[0];
	// 城市里的span标签
	var cs_span = chengshi.getElementsByTagName("span");
	// console.log(cs_p);
	var cs = chengshi.getElementsByTagName("div");
	var cs1 = chengshi1.getElementsByTagName("div");
	var cs2 = chengshi2.getElementsByTagName("div");
	var cs3 = chengshi3.getElementsByTagName("div");
	var cs4 = chengshi4.getElementsByTagName("div");

	var title_cs = chengshi.getElementsByClassName("title_cs")[0];
	var title_li = title_cs.getElementsByTagName("li");
	// console.log(cs1);
	var title_cs1 = chengshi1.getElementsByClassName("title_cs")[0];
	var title_li1 = title_cs1.getElementsByTagName("li");

	var title_cs2 = chengshi2.getElementsByClassName("title_cs")[0];
	var title_li2 = title_cs2.getElementsByTagName("li");
	// console.log(chengshi_2);
	// 
	var title_cs3 = chengshi3.getElementsByClassName("title_cs")[0];
	var title_li3 = title_cs3.getElementsByTagName("li");
	// console.log(title_li11);

	var title_cs4 = chengshi4.getElementsByClassName("title_cs")[0];
	var title_li4 = title_cs4.getElementsByTagName("li");
	
	// fation_style开始
    var fation_Style = document.getElementById("fation_Style");
    var fs_liArr = fation_Style.getElementsByTagName("li");
    // console.log(fs_liArr.length);
	// 目的地指数
	// 国内
	var domestic = document.getElementsByClassName("domestic")[0];
	var dulArr = domestic.getElementsByTagName("ul")[0];
	var ddivArr = domestic.getElementsByTagName("div");

	var domestic1 = document.getElementsByClassName("domestic")[1];
	var dulArr1 = domestic1.getElementsByTagName("ul")[0];
	var ddivArr1 = domestic1.getElementsByTagName("div");

	var dliArr = domestic.getElementsByTagName("li");
	var daArr = domestic.getElementsByTagName("a");
	var dspans = domestic.getElementsByTagName("span");
	var dbArr = domestic.getElementsByTagName("b");

	var dliArr1 = domestic1.getElementsByTagName("li");
	var daArr1 = domestic1.getElementsByTagName("a");
	var dspans1 = domestic1.getElementsByTagName("span");
	console.log(dbArr);

	// 旅游指南
	var jiaju = document.getElementsByClassName("jiaju")[0];
	var jjliArr = jiaju.getElementsByTagName("li");
	var jjspan = jiaju.getElementsByTagName("span")[0];
	// console.log(jjliArr);
	// 旅游指南后面两张图
	var zhinan_1 = document.getElementsByClassName("zhinan_1")[0];
	var zhinan_2 = document.getElementsByClassName("zhinan_2")[0];

	var znspan1 = zhinan_1.getElementsByTagName("span")[0];
	var znspan2 = zhinan_2.getElementsByTagName("span")[0];
	// console.log(znspan2);

	// 全球110万家酒店
	var more_jiudian = document.getElementsByClassName("more_jiudian")[0];
	var mliArr = more_jiudian.getElementsByTagName("li");
	var msvgArr = more_jiudian.getElementsByTagName("svg");
	console.log(msvgArr);
	// 首页footer
	var index_footer = document.getElementsByClassName("index_footer")[0];
	var ftdd = index_footer.getElementsByTagName("dd");
	var ftli = index_footer.getElementsByTagName("li");
	console.log(ftli);
	// 首页最底部
	var bottom_box = document.getElementById("bottom_box")
	var index_bottom = document.getElementsByClassName("index_bottom")[0];
	var inbli = index_bottom.getElementsByTagName("li");
	var bottom_1 = bottom_box.getElementsByTagName("div");


	// 语言设置效果
	ul2.onmouseover = function(){
		li1.style.display = "block";
		li2.style.display = "block";
		ul2.style.zIndex = "4";
		li1.className = "bref" ;
		ul2.style.borderColor = "#999";
	}
	ul2.onmouseout = function(){	
		li1.style.display = "none";
		li2.style.display = "none";
		ul2.style.borderColor = "#fff";
	}

	// 右边图片设置效果
	little_pg.onmouseover = function(){
		xcx_pic.style.display = "block";
		jt_up.style.display = "block";

	}
	little_pg.onmouseout = function(){
		xcx_pic.style.display = "none";
		jt_up.style.display = "none";

	}
	phone.onmouseover = function(){
		ph.style.display = "block";

	}
	phone.onmouseout = function(){
		ph.style.display = "none";

	}
	edphone.onmouseover = function(){
		phumber.style.display = "block";

	}
	edphone.onmouseout = function(){
		phumber.style.display = "none";

	}
	// 让手机动起来
	var timer = setInterval(function(){
		phonesvg.style.transform = "rotate(15deg)";
	},250);
	var timer1 = setInterval(function(){
		phonesvg.style.transform = "rotate(-15deg)";
	},500);

	// banner区域轮播图
	// 指示器指定才能动
	for(var i = 0;i<spans.length;i++){
		//指示器添加属性
		spans[i].index = i+1;
		//指示器添加事件
		spans[i].onclick = function(){
			for(var j = 0;j<spans.length;j++){
				//遍历让指示器全部为灰色
				spans[j].style.background = "#5d4847";
			}
			//让轮播图片跟随指示器出现相应的图片
			imgs.src = "../img/banner_"+this.index+".png";
			//点击此指示器的背景
			this.style.background = "red";	
		}
	}
	//让图片自动动起来
	var k = 0;
	//默认最开始打开页面时第一个指示器背景为红色
	spans[0].style.background = "red";	
	//让指示器和背景自动轮播方法
	function autoPlay(){
		//8个指示器
		k++;
		if(k>8){
			k=1;
		}
		for(var i = 0;i<8;i++){
			spans[i].style.background = "#5d4847";
		}
		spans[k-1].style.background = "red";
		imgs.src = "../img/banner_"+k+".png";
	}
	timer = setInterval(autoPlay,1000);
	//清除定时器
	banners.onmouseover = function(){
		clearInterval(timer);
	}
	banners.onmouseout = function(){
		timer = setInterval(autoPlay,1000);
	}
// banner定位大区域
		// 国际酒店
		// 点击国际酒店时盒子中有些内容的改变
	guojiSpan2.onclick = function(){
		guojiSpan2.className = "inner";
		guojiSpan1.style.color = "#555";
		guojiSpan2.style.color = "#33a4ec";
		guojiSpan1.className = "";
		focus_sp.value = "首尔";
		ruzhu_sp.value = "2019-01-12";
		tuifang_sp.value = "2019-01-12";
		gjz_sp.placeholder = "商圈/位置/酒店名";
		map_a.style.opacity = "0";
		
	}
	guojiSpan1.onclick = function(){
		guojiSpan1.className = "inner";
		guojiSpan2.className = "";
		guojiSpan2.style.color = "#555";
		guojiSpan1.style.color = "#33a4ec";
		focus_sp.value = "黄山市";
		ruzhu_sp.value = "2019-01-9";
		tuifang_sp.value = "2019-01-9";
		gjz_sp.placeholder = "如位置\酒店名\品牌";
		map_a.style.opacity = "1";
		// console.log("444444");
	}
	// 国际机票方法
	guojiSpan3.onclick = function(){
		guojiSpan3.className = "inner";
		guojiSpan3.style.color = "#33a4ec";
		guojiSpan4.className = "";
		guojiSpan4.style.color = "#555";
		single.checked = "checked";
		sh.placeholder = "上海";
		qc.placeholder = "2019-01-10"
		fc.placeholder = "2019-01-12"
	}
	guojiSpan4.onclick = function(){
		guojiSpan4.className = "inner";
		guojiSpan4.style.color = "#33a4ec";
		guojiSpan3.className = "";
		guojiSpan3.style.color = "#555";
		wf.checked = "checked";
		sh.placeholder = "香港";
		qc.placeholder = "2019-01-12"
		fc.placeholder = "2019-01-14"
	}
	// 旁边酒店飞机火车票样式
	for(var k = 0;k<title_li.length;k++){
		title_li[k].onclick = function(){
			for(var l = 0;l<title_li.length;l++){
				title_li[l].className = "";
			}
			this.className = "title_bg";
			console.log(this.className);
		}
	}
	for(let k = 0;k<service_li.length;k++){
		service_li[k].index = k+1;
		service_li[k].onclick = function(){
			for(var l = 0;l<service_li.length;l++){
				service_li[l].index = l+1;
				banner_service[l+1].style.display = "none";
				service_li[l].style.background = "#f3f3f3";
				service_li[l].style.color = "#999";
			}
			this.style.background = "#fff";	
			this.style.color = "#33a4ec";
			banner_service[k+1].style.display = "block";
		}
	}
	// 字母列表切换及样式
	// 一、目的地
	for(let k = 0;k<title_li.length;k++){
		title_li[k].onclick = function(){
			for(let l = 0;l<title_li.length;l++){
				title_li[l].className = "";
				cs[l].style.display = "none";
			}
			this.className = "title_bg";
			cs[k].style.display = "block";
		}
	}
	//二、机票  往返城市北京
	for(let k = 0;k<title_li1.length;k++){
		title_li1[k].onclick = function(){
			for(let l = 0;l<title_li1.length;l++){
				title_li1[l].className = "";
				cs1[l].style.display = "none";
			}
			this.className = "title_bg";
			cs1[k].style.display = "block";
		}
	}
	//三、机票  往返城市上海

		for(let k = 0;k<title_li2.length;k++){
		title_li2[k].onclick = function(){
			for(let l = 0;l<title_li2.length;l++){
				title_li2[l].className = "";
				cs2[l].style.display = "none";
			}
			this.className = "title_bg";
		}
	}
	//四、火车票  往返城市北京
		for(let k = 0;k<title_li3.length;k++){
		title_li3[k].onclick = function(){
			for(let l = 0;l<title_li3.length;l++){
				title_li3[l].className = "";
				cs3[l].style.display = "none";
			}
			this.className = "title_bg";
			cs3[k].style.display = "block";
		}
	}
	//四、火车票  往返城市上海
		for(let k = 0;k<title_li4.length;k++){
		title_li4[k].onclick = function(){
			for(let l = 0;l<title_li4.length;l++){
				title_li4[l].className = "";
				cs4[l].style.display = "none";
			}
			this.className = "title_bg";
			cs4[k].style.display = "block";
		}
	}
	// 酒店目的地默认（最开始进入网站时）样式
	focus_sp.onfocus = function(){
		chengshi.style.display = "block";
		cs[0].style.display = "block";
	}
	//关键字
	gjz_sp.onfocus = function(){
		keyWord.style.display = "block";
	}
	gjz_sp.onblur = function(){
		keyWord.style.display = "none";
	}
	// 机票北京默认（最开始进入网站时）样式
	bj.onfocus = function(){
		chengshi1.style.display = "block";
		cs1[0].style.display = "block";
	}
	// 机票上海默认（最开始进入网站时）样式
	sh.onfocus = function(){
		chengshi2.style.display = "block";
		cs2[0].style.display = "block";
	}
	// 火车票北京默认（最开始进入网站时）样式
	bj1.onfocus = function(){
		chengshi3.style.display = "block";
		cs3[0].style.display = "block";
	}
	// 火车票上海默认（最开始进入网站时）样式
	sh1.onfocus = function(e){
		chengshi4.style.display = "block";
		cs4[0].style.display = "block";
	}
	// 鼠标点击区域内。不会消失。点击外面就会消失
	document.onclick=function(event){
       var e=event || window.event;//兼容ie和非ie的event
       var aim=e.srcElement || e.target; //兼容ie和非ie的事件源
       if(e.srcElement){
        var aim=e.srcElement;
         if(aim!=sh1 && aim!=chengshi4 && aim!=title_cs4 && aim!=title_li4[0] && aim!=title_li4[1] && aim!=title_li4[2] && aim!=title_li4[3] && aim!=title_li4[4]&& aim!=title_li4[5] && aim!=cs_p){
          chengshi4.style.display="none";
         }
		if(aim!=bj1 && aim!=chengshi3 && aim!=title_cs3 && aim!=title_li3[0] && aim!=title_li3[1] && aim!=title_li3[2] && aim!=title_li3[3] && aim!=title_li3[4]&& aim!=title_li3[5]){
          chengshi3.style.display="none";
         }
		if(aim!=sh && aim!=chengshi2 && aim!=title_cs2 && aim!=title_li2[0] && aim!=title_li2[1] && aim!=title_li2[2] && aim!=title_li2[3] && aim!=title_li2[4]&& aim!=title_li2[5]){
          chengshi2.style.display="none";
         }
		if(aim!=bj && aim!=chengshi1 && aim!=title_cs1 && aim!=title_li1[0] && aim!=title_li1[1] && aim!=title_li1[2] && aim!=title_li1[3] && aim!=title_li1[4]&& aim!=title_li1[5]){
          chengshi1.style.display="none";
         }
		if(aim!=focus_sp && aim!=chengshi && aim!=title_cs && aim!=title_li[0] && aim!=title_li[1] && aim!=title_li[2] && aim!=title_li[3] && aim!=title_li[4]&& aim!=title_li[5]){
          chengshi.style.display="none";
         }
		if(aim!=focus_sp && aim!=chengshi && aim!=title_cs && aim!=title_li[0] && aim!=title_li[1] && aim!=title_li[2] && aim!=title_li[3] && aim!=title_li[4]&& aim!=title_li[5]){
          chengshi.style.display="none";
         }
		if(aim != ruzhu && aim!=dt_img[0] && aim!=dt_img[1]){
			date.style.display = "none";
		}
       }else{
         var aim=e.target;
         if(aim!=sh1 && aim!=chengshi4 && aim!=title_cs4 && aim!=title_li4[0] && aim!=title_li4[1] && aim!=title_li4[2] && aim!=title_li4[3] && aim!=title_li4[4] && aim!=title_li4[5] && aim!= cs_p){
          chengshi4.style.display="none";
         }
		if(aim!=bj1 && aim!=chengshi3 && aim!=title_cs111 && aim!=title_li3[0] && aim!=title_li3[1] && aim!=title_li3[2] && aim!=title_li3[3] && aim!=title_li3[4] && aim!=title_li3[5]){
          chengshi3.style.display="none";
         }
		if(aim!=sh && aim!=chengshi2 && aim!=title_cs2 && aim!=title_li2[0] && aim!=title_li2[1] && aim!=title_li2[2] && aim!=title_li2[3] && aim!=title_li2[4]&& aim!=title_li2[5]){
          chengshi2.style.display="none";
         }
		if(aim!=bj && aim!=chengshi1 && aim!=title_cs1 && aim!=title_li1[0] && aim!=title_li1[1] && aim!=title_li1[2] && aim!=title_li1[3] && aim!=title_li1[4]&& aim!=title_li1[5]){
          chengshi1.style.display="none";
         }
		if(aim!=focus_sp && aim!=chengshi && aim!=title_cs && aim!=title_li[0] && aim!=title_li[1] && aim!=title_li[2] && aim!=title_li[3] && aim!=title_li[4]&& aim!=title_li[5]){
          chengshi.style.display="none";
         }
		if(aim!=dt_img[0] && aim!=dt_img[1]){
			date.style.display = "none";
		}
       }
      }

// fation_style开始
    //1.给li添加背景
    fs_liArr[0].style.width="310px";
    var l;
    // fs_liArr[0].style.background = url(../img/1.png);
    for(var i=0;i<fs_liArr.length;i++){
        fs_liArr[i].style.background = "url(../img/"+(i+1)+".png) no-repeat -80px 0";
        fs_liArr[0].style.background = "url(../img/1.png) no-repeat";
        fs_liArr[i].index = i+1;
        //2.绑定onmouseover事件，鼠标放入到li中该盒子变宽，其他的盒子变窄
        fs_liArr[i].onmouseover = function () {
        	// fs_liArr[i].index = l;
            //排他思想
            for(var j=0;j<fs_liArr.length;j++){
                //引用框架实现宽度变窄
                animate(fs_liArr[j],{"width":148});
                fs_liArr[j].style.background = "url(../img/"+(j+1)+".png) no-repeat -80px 0";
            }
            //剩下他自己
            animate(this,{"width":310});
            this.style.background = "url(../img/"+(i)+".png) no-repeat";
        }
    }


    //3.移开大盒子，回复原样
    div.onmouseout = function () {
        for(var j=0;j<fs_liArr.length;j++){
            //引用框架实现宽度变窄
            animate(fs_liArr[j],{"width":148});
            // fs_liArr[i].style.background = "url(../img/"+(i+1)+".png) no-repeat";
        }
    }

	// 目的地指数
	// 国内title文字
	for(let k = 1;k<dliArr.length-1;k++){
		dliArr[1].style.backgroundColor = "#f55";
		dliArr[1].style.borderColor = "#f55";
		dliArr[1].style.color = "#fff";

		dliArr1[1].style.backgroundColor = "#f55";
		dliArr1[1].style.borderColor = "#f55";
		dliArr1[1].style.color = "#fff";

		dliArr[k].onmouseover = function(){
			this.style.color = "#f55";	
			this.style.borderColor = "#f55";
		}
		dliArr[k].onmouseout = function(){
			this.style.color = "#555";	
			this.style.borderColor = "#fff";
		}
		dliArr1[k].onmouseover = function(){
			this.style.color = "#f55";	
			this.style.borderColor = "#f55";
		}
		dliArr1[k].onmouseout = function(){
			this.style.color = "#555";	
			this.style.borderColor = "#fff";
		}
		dliArr[k].index = k;
		// console.log(dbArr[0].innerText);
		dliArr[k].onclick = function(){

			if(k==1){
					for(let l = 1;l<5;l++){
					daArr[l].index = l;
					daArr[l].style.background = "url('../img/inner"+l+".jpg')no-repeat"
				}
				dbArr[0].innerText = "黄山";
				dbArr[1].innerText = "峨眉山";
				dbArr[2].innerText = "五台山";
				dbArr[3].innerText = "庐山";
				dspans[0].innerText = "春意撩人 登高踏青赏春色"
				dspans[1].innerText = "阳春三月 闻着茶香去峨眉"
				dspans[2].innerText = "迎春 祈福 登五台"
				dspans[3].innerText = "亲近自然 春游庐山"
			}else if(k==2){
				for(let l = 1;l<5;l++){
						daArr[l].index =  l+4;
						daArr[l].style.background = "url('../img/inner"+(l+4)+".jpg')no-repeat"
				}
				dbArr[0].innerText = "江苏天目湖";
				dbArr[1].innerText = "威海天沐威海温泉";
				dbArr[2].innerText = "广东中山温泉";
				dbArr[3].innerText = "辽宁大连安波温泉";
				dspans[0].innerText = "古树错落 帝王温泉"
				dspans[1].innerText = "森林温泉 草本养生"
				dspans[2].innerText = "毗邻港澳 商务养生"
				dspans[3].innerText = "延年益寿 名誉中外"

			}else if(k==3){
				for(let l = 1;l<5;l++){
					daArr[l].index =  l+8;
					daArr[l].style.background = "url('../img/inner"+(l+8)+".jpg')no-repeat"
				}	
				dbArr[0].innerText = "拉萨";
				dbArr[1].innerText = "大理";
				dbArr[2].innerText = "舟山";
				dbArr[3].innerText = "厦门";
				dspans[0].innerText = "高原古城 圣山天湖 沁人心脾"
				dspans[1].innerText = "文献名邦 彩云之南 空谷幽兰"
				dspans[2].innerText = "东海翡翠 舟山群岛 气候宜人"
				dspans[3].innerText = "天风海涛 鼓浪岛屿 鸟语芬芳"
			}else if(k==4){
				for(let l = 1;l<5;l++){
					daArr[l].index =  l+12;
					daArr[l].style.background = "url('../img/inner"+(l+12)+".jpg')no-repeat"
				}	
				dbArr[0].innerText = "锡林郭勒";
				dbArr[1].innerText = "坝上";
				dbArr[2].innerText = "若尔盖";
				dbArr[3].innerText = "祁连山";
				dspans[0].innerText = "草原 牧民 小马驹"
				dspans[1].innerText = "帝都最近的草原"
				dspans[2].innerText = "高原上的绿洲"
				dspans[3].innerText = "风景如画 醉美祁连山"
			}else if(k==5){
				for(let l = 1;l<5;l++){
					daArr[l].index =  l+16;
					daArr[l].style.background = "url('../img/inner"+(l+16)+".jpg')no-repeat"
				}	
				dbArr[0].innerText = "西塘";
				dbArr[1].innerText = "和顺";
				dbArr[2].innerText = "乌镇";
				dbArr[3].innerText = "平遥";
				dspans[0].innerText = "烟雨长廊 景色好似宣纸画"
				dspans[1].innerText = "古风犹存 如诗如画"
				dspans[2].innerText = "推窗见水 小桥人家"
				dspans[3].innerText = "晋商遗风 古城探幽"
			}else if(k==6){
				for(let l = 1;l<5;l++){
					daArr[l].index =  l+20;
					daArr[l].style.background = "url('../img/inner"+(l+20)+".jpg')no-repeat"
				}	
				dbArr[0].innerText = "香港";
				dbArr[1].innerText = "成都";
				dbArr[2].innerText = "扬州";
				dbArr[3].innerText = "长沙";
				dspans[0].innerText = "只有想不到，没有找不到"
				dspans[1].innerText = "不只有火锅，吃是头等事"
				dspans[2].innerText = "吴侬软语 淮味养人"
				dspans[3].innerText = "美食怕不辣，湘味最十足"
			}else{
				{
					for(let l = 1;l<5;l++){
					daArr[l].index = l;
					daArr[l].style.background = "url('../img/inner"+l+".jpg')no-repeat"
				}
				dbArr[0].innerText = "黄山";
				dbArr[1].innerText = "峨眉山";
				dbArr[2].innerText = "五台山";
				dbArr[3].innerText = "庐山";
								dspans[0].innerText = "古树错落 帝王温泉"
				dspans[1].innerText = "森林温泉 草本养生"
				dspans[2].innerText = "毗邻港澳 商务养生"
				dspans[3].innerText = "延年益寿 名誉中外"
			}
			}
			for(let l = 1;l<dliArr.length-1;l++){
				dliArr[l].style.color = "#555";
				dliArr[l].style.backgroundColor = "#fff";
				dliArr[l].style.borderColor = "#fff";
			}
			this.style.color = "#fff";	
			this.style.borderColor = "#f55";
			this.style.backgroundColor = "#f55";
		}

		dliArr1[k].onclick = function(){
			dliArr1[k].index = k;
			for(let l = 1;l<dliArr.length-1;l++){
				dliArr1[l].style.color = "#555";
				dliArr1[l].style.backgroundColor = "#fff";
				dliArr1[l].style.borderColor = "#fff";
			}
			this.style.color = "#fff";	
			this.style.borderColor = "#f55";
			this.style.backgroundColor = "#f55";
		}
	}


// 国内图片js
	for(let i = 0;i<ddivArr.length;i++){
		ddivArr[i].onmouseover = function(){
			dspans[i].style.borderBottomColor = "#f55";

			daArr[i+1].style.backgroundPosition = "0px -10px"
		}
		ddivArr[i].onmouseout = function(){
			dspans[i].style.borderBottomColor = "#ccc";
			daArr[i+1].style.backgroundPosition = "0px 0px"
		}
	}

// 海外图片js
	for(let g = 0;g<ddivArr1.length;g++){
		ddivArr1[g].onmouseover = function(){
			dspans1[g].style.borderBottomColor = "#f55";
			daArr1[g+1].style.background = "url('../img/outer"+(g+1)+".jpg')no-repeat 0px -10px";
		}
		ddivArr1[g].onmouseout = function(){
			dspans1[g].style.borderBottomColor = "#ccc";
			daArr1[g+1].style.background = "url('../img/outer"+(g+1)+".jpg')no-repeat 0px 0px";
		}
	}
	for(let k = 0;k<jjliArr.length;k++){
		jjliArr[k].index = k+1;
		jjliArr[k].onmouseover = function(){
			for(var l = 0;l<jjliArr.length;l++){
				jjliArr[l].style.background = "#fff";
			}
			this.style.background = "#89ca00";	
			jjspan.style.background = "url('../img/lvyou"+(k+1)+".png') no-repeat -1px 0px";
			jjspan.style.backgroundSize="360px 220px";
		}
	}

// 旅游指南
	zhinan_1.onmouseover = function(){
		znspan1.style.borderColor = "#89ca00";
	}
	zhinan_2.onmouseover = function(){
		znspan2.style.borderColor = "#89ca00";
	}
	zhinan_1.onmouseout = function(){
		znspan1.style.borderColor = "#ccc";
	}
	zhinan_2.onmouseout = function(){
		znspan2.style.borderColor = "#ccc";
	}

	// 全球110万家酒店图标
	var timer2;
	var timer3;
	for(let m = 0;m<mliArr.length;m++){
		mliArr[m].onmouseover = function(){
			timer2 = setInterval(function(){
				msvgArr[m].style.transform = "rotate(15deg)";
			},150);
			timer3 = setInterval(function(){
				msvgArr[m].style.transform = "rotate(-15deg)";
			},300);		
		}
		mliArr[m].onmouseout = function(){
			clearInterval(timer3);
			clearInterval(timer2);	
		}
	}
// 加盟合作关于艺龙
	for(var k = 0;k<ftdd.length;k++){
		ftdd[k].index = k+1;
		ftdd[k].onmouseover = function(){
			this.style.paddingLeft = "5px";
		}
		ftdd[k].onmouseout = function(){
			this.style.paddingLeft = "0";
		}
	}

// 酒店预订机票查询热门城市合作伙伴常见酒店
	console.log(bottom_1);
	for(let k = 0;k<inbli.length;k++){
		inbli[k].index = k+1;
		inbli[k].onclick = function(){
			for(var l = 0;l<inbli.length;l++){
				bottom_1[l].style.display  = "none";
			}
			this.style.background = "#c0d2e4";	
			bottom_1[k].style.display  = "block";
			
		}
	}

	for(let k = 0;k<ftli.length;k++){
		ftli[k].index = k+1;
		ftli[k].onmouseover = function(){
			for(var l = 0;l<ftli.length;l++){
				ftli[l].style.marginTop = "0px";
			}
			this.style.marginTop = "-20px";
		}
		ftli[k].onmouseout = function(){
			this.style.marginTop = "0px";
		}
	}




	dttable[2].style.display = "block";
	dttable[3].style.display = "block";
	date_bg[2].style.display = "block";
	date_bg[3].style.display = "block";
	ruzhu.onfocus = function(){
		date.style.display = "block";
		dtspan[0].innerText = "2019年1月";
		dtspan[1].innerText = "2019年2月";
	}
	dt_img[0].onclick = function(){
		for(let i = 0;i<6;i++){
			dttable[i].style.display = "none";
			date_bg[i].style.display = "none";
		}
		dttable[0].style.display = "block";
		dttable[1].style.display = "block";
		date_bg[0].style.display = "block";
		date_bg[1].style.display = "block";
		dtspan[0].innerText = "2018年11月";
		dtspan[1].innerText = "2018年12月";

		dt_img[1].onclick = function(){
			for(let i = 0;i<6;i++){
				dttable[i].style.display = "none";
				date_bg[i].style.display = "none";
			}
			dttable[2].style.display = "block";
			dttable[3].style.display = "block";
			date_bg[2].style.display = "block";
			date_bg[3].style.display = "block";
			dtspan[0].innerText = "2019年1月";
			dtspan[1].innerText = "2019年2月";

			dt_img[1].onclick = function(){
				for(let i = 0;i<6;i++){
					dttable[i].style.display = "none";
					date_bg[i].style.display = "none";
				}
				dttable[4].style.display = "block";
				dttable[5].style.display = "block";
				date_bg[4].style.display = "block";
				date_bg[5].style.display = "block";
				dtspan[0].innerText = "2019年3月";
				dtspan[1].innerText = "2019年4月";
				dt_img[0].onclick = function(){
					for(let i = 0;i<6;i++){
						dttable[i].style.display = "none";
						date_bg[i].style.display = "none";
					}
					dttable[0].style.display = "block";
					dttable[1].style.display = "block";
					date_bg[0].style.display = "block";
					date_bg[1].style.display = "block";
					dtspan[0].innerText = "2018年11月";
					dtspan[1].innerText = "2018年12月";

					dt_img[1].onclick = function(){
						for(let i = 0;i<6;i++){
							dttable[i].style.display = "none";
							date_bg[i].style.display = "none";
						}
						dttable[2].style.display = "block";
						dttable[3].style.display = "block";
						date_bg[2].style.display = "block";
						date_bg[3].style.display = "block";
						dtspan[0].innerText = "2019年1月";
						dtspan[1].innerText = "2019年2月";

						dt_img[1].onclick = function(){
							for(let i = 0;i<6;i++){
								dttable[i].style.display = "none";
								date_bg[i].style.display = "none";
							}
							dttable[4].style.display = "block";
							dttable[5].style.display = "block";
							date_bg[4].style.display = "block";
							date_bg[5].style.display = "block";
							dtspan[0].innerText = "2019年3月";
							dtspan[1].innerText = "2019年4月";
						}
					}
				}
			}
		}
	}
	dt_img[1].onclick = function(){
		for(let i = 0;i<6;i++){
			dttable[i].style.display = "none";
			date_bg[i].style.display = "none";
		}
		dttable[4].style.display = "block";
		dttable[5].style.display = "block";
		date_bg[4].style.display = "block";
		date_bg[5].style.display = "block";
		dtspan[0].innerText = "2019年3月";
		dtspan[1].innerText = "2019年4月";

		dt_img[0].onclick = function(){
			for(let i = 0;i<6;i++){
				dttable[i].style.display = "none";
				date_bg[i].style.display = "none";
			}
			dttable[2].style.display = "block";
			dttable[3].style.display = "block";
			date_bg[2].style.display = "block";
			date_bg[3].style.display = "block";
			dtspan[0].innerText = "2018年11月";
			dtspan[1].innerText = "2018年12月";

			dt_img[0].onclick = function(){
				for(let i = 0;i<6;i++){
					dttable[i].style.display = "none";
					date_bg[i].style.display = "none";
				}
				dttable[0].style.display = "block";
				dttable[1].style.display = "block";
				date_bg[0].style.display = "block";
				date_bg[1].style.display = "block";
				dtspan[0].innerText = "2018年11月";
				dtspan[1].innerText = "2018年12月";


				dt_img[0].onclick = function(){
					for(let i = 0;i<6;i++){
						dttable[i].style.display = "none";
						date_bg[i].style.display = "none";
					}
					dttable[0].style.display = "block";
					dttable[1].style.display = "block";
					date_bg[0].style.display = "block";
					date_bg[1].style.display = "block";
					dtspan[0].innerText = "2018年11月";
					dtspan[1].innerText = "2018年12月";

					dt_img[1].onclick = function(){
						for(let i = 0;i<6;i++){
							dttable[i].style.display = "none";
							date_bg[i].style.display = "none";
						}
						dttable[2].style.display = "block";
						dttable[3].style.display = "block";
						date_bg[2].style.display = "block";
						date_bg[3].style.display = "block";
						dtspan[0].innerText = "2019年1月";
						dtspan[1].innerText = "2019年2月";

						dt_img[1].onclick = function(){
							for(let i = 0;i<6;i++){
								dttable[i].style.display = "none";
								date_bg[i].style.display = "none";
							}
							dttable[4].style.display = "block";
							dttable[5].style.display = "block";
							date_bg[4].style.display = "block";
							date_bg[5].style.display = "block";
							dtspan[0].innerText = "2019年3月";
							dtspan[1].innerText = "2019年4月";
						}
					}
				}
			}
		}
	}
}

