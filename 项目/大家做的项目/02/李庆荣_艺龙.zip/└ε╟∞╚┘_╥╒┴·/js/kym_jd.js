/*
* @Author: 27242 jd_banner_word
* @Date:   2019-01-25 11:43:39
* @Last Modified by:   27242
* @Last Modified time: 2019-02-02 12:21:57
*/
window.onload = function(){

//1.通过id获取元素
function getId(id){
	return  document.getElementById(id);
}

//2.通过标签名获取元素数组
function getEle(ele){
	return  document.getElementsByTagName(ele);
}

//3.通过类名获取元素数组
function getClass(cls){
	//找到所有的标签
	var elem = document.all?document.all:document.getElementsByTagName("*");
	//新建数组 
	var arr = [];
	//遍历找到所有标签数组
	for(var i=0; i<elem.length;i++){
		//判断标签数组所有的元素的类名与传进来的参数cls是否相等 
		if(elem[i].className==cls){
			//把具有这个类的元素放进arr数组 
			arr.push(elem[i]);
		}
	}
	//把找到的数组传出去
	return arr;
}


	var hd = document.getElementsByTagName("header")[0];
	var ul1 = hd.getElementsByTagName("ul")[0];
	// 获取语言标签
	var ul2 = ul1.getElementsByTagName("ul")[0];
	// 获取语言里面鼠标放上去才显示的标签
	var li1 = ul2.getElementsByTagName("li")[1];
	var li2 = ul2.getElementsByTagName("li")[2];
	// 获取头部三个定位的父元素
	var little_pg = document.getElementById("little_pg");
	var phone = document.getElementById("phone");
	var edphone = document.getElementById("edphone");
	// 头部第二个图片手机
	var phonesvg = phone.getElementsByTagName("svg")[0];
	// 获取三个头部定位内容
	var xcx_pic = document.getElementsByClassName("xcx")[0];
	var ph = document.getElementsByClassName("ph")[0];
	var phumber = document.getElementById("phumber");
	// 获取获取头部第一个箭头向上定位内容
	var jt_up = document.getElementById("up");

	var jd_banner_con_left = document.getElementsByClassName("jd_banner_con_left")[0];
	var jd_banner_img = jd_banner_con_left.children[1];
	// 周边其它
	var jd_banner_li = jd_banner_con_left.getElementsByTagName("li");

	var img_box = getClass("img_box")[0];
	var banner_pic = getClass("banner_pic")[0];
	var img_box_img = img_box.getElementsByTagName("img");

	var img_box_jt = banner_pic.getElementsByTagName("span");
	// 外景
	var wj = getClass("wj");
	// 内景
	var nj = getClass("nj");

	var people_left = getId("people_left");
	var people_right = getId("people_right");

	var jd_banner_word = getClass("jd_banner_word")[0];
	var jd_banner_word_ul = jd_banner_word.children[0];
				// 酒店的日历
	var date = document.getElementsByClassName("date")[0];
	var dttable = date.getElementsByTagName("table");
	// 年月日显示
	var dtspan = date.getElementsByTagName("span");
	// date里面的上面部分
	var dt_title = date.getElementsByClassName("dt_title")[0];
	// date里面的下面部分
	var date_list = date.getElementsByClassName("date_list")[0];
	// date里面的下面部分的背景
	var date_bg = date_list.getElementsByTagName("div");
	var dt_img = dt_title.getElementsByTagName("img");

	var go_zhu = document.getElementsByClassName("go_zhu")[0];
	var go_zhu_input = go_zhu.getElementsByTagName("input")[0];
	// console.log(go_zhu_span);
	
	var jd_Box_con = document.getElementsByClassName("jd_Box_con")[0];
	var jd_house_li1 = document.getElementsByClassName("jd_house_li1")[0];
	var yuiding_xuzhi = document.getElementsByClassName("yuiding_xuzhi")[0];
	var jd_house_i = jd_house_li1.children[0];


	var jd_Box_con1 = getClass("jd_Box_con1");
	var jd_house2_titlebox = getClass("jd_house2_titlebox");
	var jd_house2_p = document.getElementsByClassName("jd_house2_product");

	var jd_house2_jt = document.getElementsByTagName("strong");

	var jd_house2_YC = getClass("jd_house2_YC");
	var jd_house2_YC_ul = document.getElementsByClassName("jd_house2_YC_ul");


	var JD_box_info_icon = getClass("JD_box_info_icon")[0];
	var DianPin_title_con = document.getElementsByClassName("DianPin_title_con")[0];
	var DianPin_title_con_li = DianPin_title_con.getElementsByTagName("li");
	var JD_box_info_p = JD_box_info_icon.getElementsByTagName("p");
	var JD_box_jt = getId("JD_box_jt");
	var JD_box_jt1 = getId("JD_box_jt1");

	var DianPin_titleyc = getClass("DianPin_titleyc");
	var zhankai = getId("zhankai");


	var DianPin_bottom_li = getClass("DianPin_bottom_li");
	console.log(DianPin_bottom_li);

	// 语言设置效果
	ul2.onmouseover = function(){
		li1.style.display = "block";
		li2.style.display = "block";
		ul2.style.zIndex = "4";
		li1.className = "bref" ;
		ul2.style.borderColor = "#999";
	}
	ul2.onmouseout = function(){	
		li1.style.display = "none";
		li2.style.display = "none";
		ul2.style.borderColor = "#fff";
	}

	// 右边图片设置效果
	little_pg.onmouseover = function(){
		xcx_pic.style.display = "block";
		jt_up.style.display = "block";

	}
	little_pg.onmouseout = function(){
		xcx_pic.style.display = "none";
		jt_up.style.display = "none";

	}
	phone.onmouseover = function(){
		ph.style.display = "block";

	}
	phone.onmouseout = function(){
		ph.style.display = "none";

	}
	edphone.onmouseover = function(){
		phumber.style.display = "block";

	}
	edphone.onmouseout = function(){
		phumber.style.display = "none";

	}
	// 让手机动起来
	var timer = setInterval(function(){
		phonesvg.style.transform = "rotate(15deg)";
	},250);
	var timer1 = setInterval(function(){
		phonesvg.style.transform = "rotate(-15deg)";
	},500);


	for(let i = 0;i<img_box_img.length;i++){
		
		img_box_img[i].onclick = function(){img_box_img[i].index = i;
			console.log("dianjil");
			if(i<6){
				console.log(i);
				jd_banner_img.style.background = "url(../img/w"+(i+1)+".jpg) no-repeat";
				jd_banner_img.style.backgroundSize = "732px 325px";	
			}
			if(5<i && i<37){
				console.log(i);
				jd_banner_img.style.background = "url(../img/n"+(i+1)+".jpg) no-repeat";
				jd_banner_img.style.backgroundSize = "732px 325px";	
			}

		}
	}

		var x = 0;
		img_box_jt[1].onclick = function(){
			x+=1;
			if(x>4){
				x=4
			}
			var leftzhi = (-738)*x;
			img_box.style.marginLeft = leftzhi+"px";
			console.log(leftzhi);			

		}
		img_box_jt[0].onclick = function(){
			x-=1;
			if(x<1){
				x=0;
			}
			var leftzhi = (-738)*x;
			img_box.style.marginLeft = leftzhi+"px";
			console.log(leftzhi);
		}


		jd_banner_li[2].onclick = function(){
			for(let i = 0;i<31;i++){
				nj[i].style.display = "none";
				for(let i = 0;i<6;i++){
					wj[i].style.display = "inline-block";
				}
			}

		}
		jd_banner_li[4].onclick = function(){
			for(let i = 0;i<6;i++){
				wj[i].style.display = "none";
				for(let i = 0;i<31;i++){
					nj[i].style.display = "inline-block";
				}
			}
		}
		jd_banner_li[0].onclick = function(){
			for(let i = 0;i<36;i++){
				img_box_img[i].style.display = "inline-block";
			}
		}


		// people_right.onclick = function(){
		// 	jd_banner_word_ul.style.marginLeft = "-420px";
		// }
		var y = 0;
		people_right.onclick = function(){
			clearInterval(timer);
			y+=1;
			if(y>2){
				y=2;
				people_right.style.display = "none";
				people_left.style.display = "block";
			}
			var jd_banner_leftzhi = (-420)*y;
			jd_banner_word_ul.style.marginLeft = jd_banner_leftzhi+"px";
			console.log(jd_banner_leftzhi);	

		}
		people_left.onclick = function(){
			clearInterval(timer);
			y-=1;
			if(y<1){
				y=0;
				people_left.style.display = "none";
			}
			var jd_banner_leftzhi = (-420)*y;			
			jd_banner_word_ul.style.marginLeft = jd_banner_leftzhi+"px";
			console.log(jd_banner_leftzhi);	
		}
		// 棒极了下面轮播
		var timer = setInterval(function(){
			y+=1;
			if(y>2){
				y=0;
			}
			var jd_banner_leftzhi = (-420)*y;
			jd_banner_word_ul.style.marginLeft = jd_banner_leftzhi+"px";
		}, 3000);


		// 鼠标点击区域内。不会消失。点击外面就会消失
	document.onclick=function(event){
       var e=event || window.event;//兼容ie和非ie的event
       var aim=e.srcElement || e.target; //兼容ie和非ie的事件源
       if(e.srcElement){
        var aim=e.srcElement;
		if(aim != go_zhu_input && aim!=dt_img[0] && aim!=dt_img[1]){
			date.style.display = "none";
		}
       }else{
         var aim=e.target;
		if(aim!=dt_img[0] && aim!=dt_img[1]){
			date.style.display = "none";
		}
       }
      }



	dttable[2].style.display = "block";
	dttable[3].style.display = "block";
	date_bg[2].style.display = "block";
	date_bg[3].style.display = "block";
	go_zhu_input.onfocus = function(){
		date.style.display = "block";
		dtspan[0].innerText = "2019年1月";
		dtspan[1].innerText = "2019年2月";
	}
	dt_img[0].onclick = function(){
		for(let i = 0;i<6;i++){
			dttable[i].style.display = "none";
			date_bg[i].style.display = "none";
		}
		dttable[0].style.display = "block";
		dttable[1].style.display = "block";
		date_bg[0].style.display = "block";
		date_bg[1].style.display = "block";
		dtspan[0].innerText = "2018年11月";
		dtspan[1].innerText = "2018年12月";

		dt_img[1].onclick = function(){
			for(let i = 0;i<6;i++){
				dttable[i].style.display = "none";
				date_bg[i].style.display = "none";
			}
			dttable[2].style.display = "block";
			dttable[3].style.display = "block";
			date_bg[2].style.display = "block";
			date_bg[3].style.display = "block";
			dtspan[0].innerText = "2019年1月";
			dtspan[1].innerText = "2019年2月";

			dt_img[1].onclick = function(){
				for(let i = 0;i<6;i++){
					dttable[i].style.display = "none";
					date_bg[i].style.display = "none";
				}
				dttable[4].style.display = "block";
				dttable[5].style.display = "block";
				date_bg[4].style.display = "block";
				date_bg[5].style.display = "block";
				dtspan[0].innerText = "2019年3月";
				dtspan[1].innerText = "2019年4月";
				dt_img[0].onclick = function(){
					for(let i = 0;i<6;i++){
						dttable[i].style.display = "none";
						date_bg[i].style.display = "none";
					}
					dttable[0].style.display = "block";
					dttable[1].style.display = "block";
					date_bg[0].style.display = "block";
					date_bg[1].style.display = "block";
					dtspan[0].innerText = "2018年11月";
					dtspan[1].innerText = "2018年12月";

					dt_img[1].onclick = function(){
						for(let i = 0;i<6;i++){
							dttable[i].style.display = "none";
							date_bg[i].style.display = "none";
						}
						dttable[2].style.display = "block";
						dttable[3].style.display = "block";
						date_bg[2].style.display = "block";
						date_bg[3].style.display = "block";
						dtspan[0].innerText = "2019年1月";
						dtspan[1].innerText = "2019年2月";

						dt_img[1].onclick = function(){
							for(let i = 0;i<6;i++){
								dttable[i].style.display = "none";
								date_bg[i].style.display = "none";
							}
							dttable[4].style.display = "block";
							dttable[5].style.display = "block";
							date_bg[4].style.display = "block";
							date_bg[5].style.display = "block";
							dtspan[0].innerText = "2019年3月";
							dtspan[1].innerText = "2019年4月";
						}
					}
				}
			}
		}
	}
	dt_img[1].onclick = function(){
		for(let i = 0;i<6;i++){
			dttable[i].style.display = "none";
			date_bg[i].style.display = "none";
		}
		dttable[4].style.display = "block";
		dttable[5].style.display = "block";
		date_bg[4].style.display = "block";
		date_bg[5].style.display = "block";
		dtspan[0].innerText = "2019年3月";
		dtspan[1].innerText = "2019年4月";

		dt_img[0].onclick = function(){
			for(let i = 0;i<6;i++){
				dttable[i].style.display = "none";
				date_bg[i].style.display = "none";
			}
			dttable[2].style.display = "block";
			dttable[3].style.display = "block";
			date_bg[2].style.display = "block";
			date_bg[3].style.display = "block";
			dtspan[0].innerText = "2018年11月";
			dtspan[1].innerText = "2018年12月";

			dt_img[0].onclick = function(){
				for(let i = 0;i<6;i++){
					dttable[i].style.display = "none";
					date_bg[i].style.display = "none";
				}
				dttable[0].style.display = "block";
				dttable[1].style.display = "block";
				date_bg[0].style.display = "block";
				date_bg[1].style.display = "block";
				dtspan[0].innerText = "2018年11月";
				dtspan[1].innerText = "2018年12月";


				dt_img[0].onclick = function(){
					for(let i = 0;i<6;i++){
						dttable[i].style.display = "none";
						date_bg[i].style.display = "none";
					}
					dttable[0].style.display = "block";
					dttable[1].style.display = "block";
					date_bg[0].style.display = "block";
					date_bg[1].style.display = "block";
					dtspan[0].innerText = "2018年11月";
					dtspan[1].innerText = "2018年12月";

					dt_img[1].onclick = function(){
						for(let i = 0;i<6;i++){
							dttable[i].style.display = "none";
							date_bg[i].style.display = "none";
						}
						dttable[2].style.display = "block";
						dttable[3].style.display = "block";
						date_bg[2].style.display = "block";
						date_bg[3].style.display = "block";
						dtspan[0].innerText = "2019年1月";
						dtspan[1].innerText = "2019年2月";

						dt_img[1].onclick = function(){
							for(let i = 0;i<6;i++){
								dttable[i].style.display = "none";
								date_bg[i].style.display = "none";
							}
							dttable[4].style.display = "block";
							dttable[5].style.display = "block";
							date_bg[4].style.display = "block";
							date_bg[5].style.display = "block";
							dtspan[0].innerText = "2019年3月";
							dtspan[1].innerText = "2019年4月";
						}
					}
				}
			}
		}
	}

	// 为你推荐
	jd_Box_con.onclick = function(){
		if(jd_house_i.className =="logo icon-icon"){
			console.log(jd_house_i.className);
			jd_house_i.className ="logo icon-arrow-right-copy";
			yuiding_xuzhi.style.display = "block";
		}else{
			jd_house_i.className ="logo icon-icon";
			yuiding_xuzhi.style.display = "none";
		}
	}
	jd_Box_con.onmouseover = function(){
		if(jd_house_i.className =="logo icon-icon"){
			jd_Box_con.style.background = "#ddd";
		}else{
			jd_Box_con.style.background = "#fffbf9";
		}
	}
	jd_Box_con.onmouseout = function(){
			jd_Box_con.style.background = "#fffbf9";
	}
	// 为你推荐下面第一个房间
	for(let k = 0;k<6;k++){
		jd_house2_titlebox[k].index = k;
		jd_house2_titlebox[k].onclick = function(){

			if(jd_house2_jt[k].className =="logo icon-jiantou-down"){
			// 	console.log(jd_house2_jt.className);
				jd_house2_jt[k].className ="logo icon-jiantouarrow486-copy";
				jd_house2_YC[k].style.display = "block";
				jd_Box_con1[k].style.borderColor = "#ccc";
				jd_house2_titlebox[k].style.background = "#ddd";		
				jd_house2_titlebox[k].onmouseover = function(){
					jd_house2_titlebox[k].style.background = "#ddd";
				}
				jd_house2_titlebox[k].onmouseout = function(){
					jd_house2_titlebox[k].style.background = "#ddd";
				}
			}else{
				jd_house2_jt[k].className ="logo icon-jiantou-down";
				jd_house2_YC[k].style.display = "none";
				jd_Box_con1[k].style.borderColor = "#fff";
				jd_house2_titlebox[k].onmouseover = function(){
					jd_house2_titlebox[k].style.background = "#ddd";
				}
				jd_house2_titlebox[k].onmouseout = function(){
					jd_house2_titlebox[k].style.background = "#fff";
				}
			}
		}
	jd_house2_titlebox[k].onmouseover = function(){
		jd_house2_titlebox[k].style.background = "#ddd";
	}
	jd_house2_titlebox[k].onmouseout = function(){
		jd_house2_titlebox[k].style.background = "#fff";
	}
	}



	for(let i = 0;i<23;i++){
		jd_house2_YC_ul[i].onmouseover = function(){
			for(let j = 0;j<23;j++){
				jd_house2_YC_ul[j].style.background = "#ffff";
			}
			this.style.background = "#ddd";
		}
		jd_house2_YC_ul[i].onmouseout = function(){
			for(let j = 0;j<23;j++){
				jd_house2_YC_ul[j].style.background = "#ffff";
			}
		}
	}
	// 酒店设施箭头
		JD_box_jt.onclick = function(){
			console.log("12");
			if(JD_box_jt.className == "logo icon-icon"){
				JD_box_info_p[0].style.height = "210px";
				JD_box_jt.className = "logo icon-arrow-right-copy";
			}else{
				JD_box_jt.className = "logo icon-icon";
				JD_box_info_p[0].style.height = "26px";
			}
		}

		// 酒店简介箭头
		JD_box_jt1.onclick = function(){
			console.log("12");
			if(JD_box_jt.className == "logo icon-icon"){
				// JD_box_info_p[0].style.height = "60px";
				JD_box_info_p[1].style.height = "60px";
				JD_box_info_p[2].style.height = "60px";
				JD_box_info_p[3].style.height = "60px";
				JD_box_jt.className = "logo icon-arrow-right-copy";
			}else{
				JD_box_jt.className = "logo icon-icon";
				JD_box_info_p[1].style.height = "26px";
				// JD_box_info_p[0].style.height = "26px";
				JD_box_info_p[2].style.height = "26px";
				JD_box_info_p[3].style.height = "26px";
			}
		}



		DianPin_titleyc[0].style.background = "#47f";
	for(let i = 0;i<26;i++){
		zhankai.onclick = function(){
			if(zhankai.innerText=="展开"){
				for(let i = 0;i<15;i++){
					DianPin_titleyc[i].style.display = "inline-block";
					zhankai.innerText="收起";
				}
			}else{
					for(let i = 0;i<15;i++){
					DianPin_titleyc[i].style.display = "none";
					zhankai.innerText="展开";
				}
			}	

		}

		DianPin_title_con_li[i].onclick = function(){
				for(let j = 0;j<27;j++){
					DianPin_title_con_li[j].style.background = "#fff";
				}
				this.style.background = "#49f";
			}
	}

// 全部(2941)li
	for(let i = 0;i<4;i++){
		DianPin_bottom_li[i].onclick = function(){
			// DianPin_bottom_li[i].onmouseover = function(){
			// 	for(let j = 0;j<4;j++){
			// 		DianPin_bottom_li[j].style.color = "#555";
			// 		DianPin_bottom_li[j].style.borderColor = "#fff";
			// 	}
			// 	this.style.color = "#47f";
			// 	this.style.borderColor = "#47f";
			// }
			// DianPin_bottom_li[i].onmouseout = function(){
			// 	for(let j = 0;j<4;j++){
			// 		DianPin_bottom_li[j].style.color = "#555";
			// 		DianPin_bottom_li[j].style.borderColor = "#fff";
			// 	}
			// 	// this.style.color = "#47f";
			// 	// this.style.borderColor = "#47f";
			// }
			for(let j = 0;j<4;j++){
				DianPin_bottom_li[j].style.color = "#555";
				DianPin_bottom_li[j].style.borderColor = "#fff";
			}
			this.style.color = "#47f";
			this.style.borderColor = "#47f";
		}

	}

				
			
		



}