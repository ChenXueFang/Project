/*
* @Author: 27242
* @Date:   2019-01-24 11:53:28
* @Last Modified by:   27242
* @Last Modified time: 2019-01-25 10:20:17
*/
window.onload = function(){
// 收起房型信息
function getId(id) {
    return document.getElementById(id);
}
function getClass(cls){
	//找到所有的标签
	var elem = document.all?document.all:document.getElementsByTagName("*");
	//新建数组 
	var arr = [];
	//遍历找到所有标签数组
	for(var i=0; i<elem.length;i++){
		//判断标签数组所有的元素的类名与传进来的参数cls是否相等 
		if(elem[i].className==cls){
			//把具有这个类的元素放进arr数组 
			arr.push(elem[i]);
		}
	}
	//把找到的数组传出去
	return arr;
}
var pay_left_bt = getClass("pay_left_bt")[0];
var sq_info = pay_left_bt.children[0];
var house_info = getClass("house_info")[0];
var sq_info_span = pay_left_bt.children[1];

var house_nb = getClass("house_nb")[0];
var house_nb_span = house_nb.children;

var stay_info = getClass("stay_info")[0];
var stay_info_dl = stay_info.children;

var wran_1 = getId("wran_1");
var wran_2 = getId("wran_2");

var fapiao_con = getClass("fapiao_con")[0];
var fapiao_con_div = fapiao_con.children;

var fapiao_con_li = fapiao_con_div[1].children;

// 需要发票
var fapiao_top = getClass("fapiao_top")[0];
// 发票备注
var fpbz = getClass("fpbz")[0];
// 需要发票input外盒子
var fapiao_top_em = fapiao_top.getElementsByTagName("em")[0];
// 需要发票input
var fapiao_top_input = fapiao_top.getElementsByTagName("input")[0];
// 发票备注外盒子
var fpbz_em = fpbz.getElementsByTagName("em")[0];
// 发票备注input
var fpbz_input = fpbz.getElementsByTagName("input")[0];
// 酒店名称
var fpbz_span = fpbz.getElementsByTagName("span");

var txt=getId("txt");//输入框
var code=getId("code");//验证码
var submit=getId("submit");//提交按钮
var arr=new Array(0,1,2,3,4,5,6,7,8,9,'A','B','C','D','E',
	'F','G','H','I','J','K','L','M','N','O','P','Q','R','S',
	'T','U','V','W','X','Y','Z','a','b','c','d','e','f','g',
	'h','i','j','k','l','m','n','o','p','q','r','s','t','u',
	'v','w','x','y','z');


console.log(fpbz_span);



	// 收起房型信息
	sq_info.onclick = function(){
		if(sq_info_span.className=="logo icon-jiantouarrow486-copy"){
			sq_info_span.className = "logo icon-jiantou-down";
			house_info.style.display = "none";
		}else{
			sq_info_span.className = "logo icon-jiantouarrow486-copy";
			house_info.style.display = "block";
		}
	}




//1.构造一个方法, 生成验证码 
    // var str ="";
    function shengchengCode(){
    	code.value = ""
    	for (var i = 0; i <4 ; i++) {
    		//随机生成的下标
    		var index = Math.floor(Math.random()*arr.length);
    		code.value += arr[index];
    	}
    }
    shengchengCode();
    //验证验证码正确或错误
    submit.onclick = function(){
    	var transCode = code.value;
    	var userCode = txt.value;
    	console.log(userCode);
    	if(transCode==userCode){
    		// alert("正确")
    	}else if(userCode.length==0){
    		// alert("用户输入为空")
    	}else{
    		// alert("错误");
    	}
    	txt.value = "";
    	shengchengCode();
    }

    // 房间数量减
    var house_mon = 1;
    house_nb_span[0].onclick = function(){
    	house_mon--;
    	if(house_mon>=1){
    		house_nb_span[1].value = house_mon;
    		stay_info_dl[house_mon].style.display = "none";	
    	}else{
    		house_mon=1;
    	} 
        if(house_mon<5){
    		wran_1.style.display = "none";
    	}  
    	if(house_mon<10){
    		wran_2.style.display = "none";
    	}   	
    }
    // 房间数量加
    house_nb_span[2].onclick = function(){
    	house_mon++;
    	if(house_mon<=10){
    		house_nb_span[1].value = house_mon;
    	}else{
    		house_mon=10;
    	}
    	if(house_mon>=5){
    		wran_1.style.display = "block";
    	}
    	if(house_mon==10){
    		wran_2.style.display = "block";
    	}
    	stay_info_dl[house_mon].style.display = "block"	;
    }
    for(let i =0;i<3;i++){
    	fapiao_con_li[i].index = i+2;
    	fapiao_con_li[i].onclick = function(){
    		for(var l = 2;l<5;l++){
    			fapiao_con_div[l].style.display = "none";
    		}
			fapiao_con_div[i+2].style.display = "block";
    	}
    }

    // 需要发票
    fapiao_top_em.onclick = function(){
        is_check();
        console.log("xx");
    }
    function is_check(){       
        if(fapiao_top_input.checked){        
            fapiao_con.style.display = "block";
        }else{
            fapiao_con.style.display = "none";
        }
    }
    // 发票备注
    fpbz_em.onclick = function(){
        beizhu_check();
        console.log("xx");
    }
    function beizhu_check(){       
        if(fpbz_input.checked){        
             for(let i= 0;i<4;i++){
                fpbz_span[i].style.display = "inline-block";
             }
        }else{
             for(let i= 0;i<4;i++){
                fpbz_span[i].style.display = "none";
             }
        }
    }
var osheng=document.getElementById("sheng");
    var oshi=document.getElementById("shi");
    var oxian=document.getElementById("xian");
var osheng1=document.getElementById("sheng1");
    var oshi1=document.getElementById("shi1");
    var oxian1=document.getElementById("xian1");

    var arr_sheng=["北京","天津","上海","重庆"];<!--创建一个一维数组，存入省的值-->

    var arr_shi=[
        <!--创建一个二维数组，最外层每一个元素对应省-->
        ["北京市"],<!--数组中的第一个元素内又定义一个数组存的市的值-->
        ["天津市"],
        ["上海市"],
        ["重庆市"]
    ];

    var arr_xian=[
            [
                ["东城区","西城区", "崇文区","宣武区", "朝阳区","丰台区","石景山区",
                "海淀区", "门头沟区", "房山区", "通州区","顺义区","昌平区","大兴区",
                "怀柔区","平谷区","密云县", "延庆县"]
            ],
            [
                ["和平区","河东区","河西区","南开区","河北区","红桥区","塘沽区",
                "汉沽区","大港区","东丽区","西青区","津南区","北辰区","武清区",
                "宝坻区","宁河县","静海县","蓟　县"]
            ],
            [
               ["黄浦区", "卢湾区","徐汇区","长宁区","静安区","普陀区","闸北区",
                "虹口区","杨浦区","闵行区","宝山区","嘉定区","浦东新区","金山区",
                "松江区", "青浦区","南汇区","奉贤区","崇明县"]
            ],
            [
                [ "万州区","涪陵区","渝中区","大渡口区","江北区","沙坪坝区","九龙坡区",
                 "南岸区","北碚区","万盛区","双桥区","渝北区","巴南区","黔江区","长寿区",
                "綦江县", "潼南县","铜梁县","大足县","荣昌县","璧山县","梁平县","城口县",
                "丰都县","垫江县","武隆县","忠县","开县","云阳县","奉节县","巫山县","巫溪县",
                 "石柱土家族自治县", "秀山土家族苗族自治县", "酉阳土家族苗族自治县","彭水苗族土家族自治县",
                "江津市", "合川市","永川市","南川市"]
            ]
    ];

    var  quanju_arr;//创建一个全局对象，用于存储一个中间数组

    function input_arr(arr,event){//封装一个函数，用于向下拉栏中添加元素
        for(var i=0;i<arr.length;i++){//下拉栏内的元素来源于数组中的元素，遍历数组
            var option=new Option(arr[i],i);//创建Option对象（这个O要大写），存入值
            event.appendChild(option);//把option添加到event对象的末尾
        }
    }

    input_arr(arr_sheng,osheng);//调用,给省下拉栏添元素

    osheng.onchange= function () {//给下拉栏绑定事件（当下拉栏元素改变时执行）
        oshi.options.length=1;//当省下拉栏改变时，清空市的下拉栏内元素
        oxian.options.length=1;//当省下拉栏改变时，清空县的下拉栏内元素
        var index=this.value;//每一个option标签都有一个value值索引，获取索引，用于数组中元素的选择
        var arr_shi_next=arr_shi[index];//获取当前选择省的市元素并赋给一个数组
        quanju_arr=arr_xian[index];//获取当前选择省中市的县元素并赋给定义的中间数组
        input_arr(arr_shi_next,oshi);//调用,给市下拉栏添元素
    }

    oshi.onchange= function () {
        oxian.options.length=1;
        var index=this.value;
        var arr_xian_next=quanju_arr[index];
        input_arr(arr_xian_next,oxian);//调用,给县下拉栏添元素
    }



    var  quanju_arr;//创建一个全局对象，用于存储一个中间数组

    function input_arr(arr,event){//封装一个函数，用于向下拉栏中添加元素
        for(var i=0;i<arr.length;i++){//下拉栏内的元素来源于数组中的元素，遍历数组
            var option=new Option(arr[i],i);//创建Option对象（这个O要大写），存入值
            event.appendChild(option);//把option添加到event对象的末尾
        }
    }

    input_arr(arr_sheng,osheng1);//调用,给省下拉栏添元素

    osheng1.onchange= function () {//给下拉栏绑定事件（当下拉栏元素改变时执行）
        oshi1.options.length=1;//当省下拉栏改变时，清空市的下拉栏内元素
        oxian1.options.length=1;//当省下拉栏改变时，清空县的下拉栏内元素
        var index=this.value;//每一个option标签都有一个value值索引，获取索引，用于数组中元素的选择
        var arr_shi_next=arr_shi[index];//获取当前选择省的市元素并赋给一个数组
        quanju_arr=arr_xian[index];//获取当前选择省中市的县元素并赋给定义的中间数组
        input_arr(arr_shi_next,oshi1);//调用,给市下拉栏添元素
    }

    oshi1.onchange= function () {
        oxian1.options.length=1;
        var index=this.value;
        var arr_xian_next=quanju_arr[index];
        input_arr(arr_xian_next,oxian1);//调用,给县下拉栏添元素
    }





}