window.onload=function(){
	var twoCode = document.getElementById("twoCode");
	var code2 = document.getElementById("code2");
	console.log(twoCode);
	twoCode.onmouseover = function(){
		animate1(twoCode,30);
//		animate(code2,{"opacity:1"});
		code2.style.display = "block";
	}
	twoCode.onmouseout = function(){
		animate1(twoCode,94);
		code2.style.display = "none";
	}
	code2.onmouseover = function(){
		animate1(twoCode,30);
//		animate(code2,{"opacity:1"});
		code2.style.display = "block";
	}
	code2.onmouseout = function(){
		animate1(twoCode,94);
		code2.style.display = "none";
	}
	
	var shouQi = document.getElementById("shouQi");
	var textSQ = shouQi.getElementsByTagName("span")[0];
	var emShou = shouQi.getElementsByTagName("em")[0];
	var shouQi1 = document.getElementById("shouQi1");
	console.log(shouQi);
	console.log(textSQ);
	console.log(shouQi1);
	shouQi.onclick = function(){
//		shouQi1.style.display = "block";
		if(shouQi1.style.display==="none"){
			shouQi1.style.display = "block";
			textSQ.innerText = "收起";
			emShou.className = "iconfont icon-top";
		}
		else{
			shouQi1.style.display= "none";
			textSQ.innerText = "更多";
			emShou.className = "iconfont icon-duduyinleappicon0701";
		}
	}
	
//	账户登录
	addEvent('yongHu',function(){
//		var val = this.value;
//		var len = val.length;
  		if(/^\s*$/.test(this.value)){
  			this.style.border = "1px solid #f64a4a";
			setClassName1(this,"iconfont icon-cuo1 zhzhone");
			setInnerHTML(this,"请输入登录名");
  		}
		else{
			this.style.border = "1px solid #b2b2b2";
			setClassName1(this,"");
			setInnerHTML(this,"");
		}
	});
//	密码
	addEvent('passWord1',function(){
//		var val = this.value;
//		var len = val.length;
  		if(/^\s*$/.test(this.value)){
  			this.style.border = "1px solid #f64a4a";
			setClassName1(this,"iconfont icon-cuo1 zhzhtwo");
			setInnerHTML(this,"请输入密码");
  		}
		else{
			this.style.border = "1px solid #b2b2b2";
			setClassName1(this,"");
			setInnerHTML(this,"");
		}
	});
	
//	进行tab切换
	var enterUl1= document.getElementsByClassName("enterUl1")[0];
	var liArr = enterUl1.getElementsByTagName("li");
	var tabDiv= document.getElementsByClassName("tabDiv");
	console.log(liArr);
	console.log(tabDiv);
	for(var i=0;i<liArr.length;i++){
        //绑定索引值(自定义属性)
        liArr[i].index=i;
        liArr[i].onclick = function () {
         //3.书写事件驱动程序（排他思想）
        //1.点亮盒子。   2.利用索引值显示盒子。(排他思想)
         for(var j=0;j<liArr.length;j++){
            liArr[j].className="";
            tabDiv[j].className="tabDiv";
        }
        this.setAttribute("class","colorLi");
        tabDiv[this.index].setAttribute("class","tabDiv daKai");
        }
    }
	
//	for(var i=0;i<liArr.length;i++){
//		liArr[i].onmouseover = function(){
//			this.style.color="#f10180";
//		}
//		liArr[i].onmouseout = function(){
//			this.style.color="#666";
//		}
//	}
//	
	
	
	function animate1(ele,target) {
        clearInterval(ele.timer);
        ele.timer = setInterval(function () {
            var step = (target-ele.offsetLeft)/10;
            step = step>0?Math.ceil(step):Math.floor(step);
            ele.style.left = ele.offsetLeft + step + "px";
            console.log(1);
            if(Math.abs(target-ele.offsetLeft)<Math.abs(step)){
            ele.style.left = target + "px";
            clearInterval(ele.timer);
            }
        },25);
    }
	
		function addEvent(str,fn){
            document.getElementById(str).onblur = fn;
        }
        //nextElementSibling:返回当前元素在父元素的子节点的后一个节点
        function setClassName(aaa,txt){
            var span = aaa.nextElementSibling || this.nextSibling;
            span.className = txt;
        }
        function setInnerHTML(aaa,txt){
//            console.log(this);
            var span = aaa.nextElementSibling || this.nextSibling;
            span.innerHTML = txt;
        }
        function setClassName1(aaa,txt){
            var em = aaa.previousElementSibling || this.previousSibling;
            em.className = txt;
        }
        
}
