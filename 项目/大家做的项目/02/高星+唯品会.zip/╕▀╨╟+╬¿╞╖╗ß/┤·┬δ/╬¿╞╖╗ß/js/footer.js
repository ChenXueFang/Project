window.onload = function(){
	var dler = document.getElementsByClassName("dler")[0];
	var ddArr= dler.getElementsByTagName("dd");
	var iArr= dler.getElementsByTagName("i");
	var aTextArr= dler.getElementsByTagName("a");
	var divArr= dler.getElementsByTagName("div");
	console.log(iArr);
	console.log(aTextArr);
	for(var i=0; i<ddArr.length; i++){
		ddArr[i].index=i;
		ddArr[i].onmouseover=function(){
			iArr[this.index].style.background = "#f10180";
			animate1(divArr[this.index],3);
			
		}
		ddArr[i].onmouseout=function(){
			iArr[this.index].style.background = "#6a6b6d";
			animate1(divArr[this.index],0);
		}
	}
//	关于我们部分开始
	var aboutBox = document.getElementById("aboutBox");
	var aboutAArr = aboutBox.getElementsByTagName("a");
	console.log(aboutAArr);
	var aboutUsZ = document.getElementsByClassName("aboutUsZ")[0];
	
//	for(var i =0; i<aboutAArr.length; i++){
//		aboutAArr[i].onmouseover=function(){
//			var textTu=this.innerHTML;
//			console.log(textTu);
//			aboutUsZ.innerHTML=textTu;
//		}
//	}
	for(var i =0; i<aboutAArr.length; i++){
	aboutAArr[i].onmouseover=function fn(ev) {
        var event=window.event||ev;
        aboutUsZ.style.left=event.clientX+3+"px";
        aboutUsZ.style.top=event.clientY+20+"px";
        var textTu=this.innerHTML;
		console.log(textTu);
		aboutUsZ.innerHTML=textTu;
		aboutUsZ.style.display="block";
    }
	aboutAArr[i].onmouseout=function(){
		aboutUsZ.style.display="none";
	}
}
	
	function animate1(ele,target) {
                clearInterval(ele.timer);
                ele.timer = setInterval(function () {
                    var step = (target-ele.offsetLeft)/10;
                    step = step>0?Math.ceil(step):Math.floor(step);
                    ele.style.left = ele.offsetLeft + step + "px";
                    console.log(1);
                    if(Math.abs(target-ele.offsetLeft)<Math.abs(step)){
                        ele.style.left = target + "px";
                        clearInterval(ele.timer);
                    }
                },18);
            }
}
