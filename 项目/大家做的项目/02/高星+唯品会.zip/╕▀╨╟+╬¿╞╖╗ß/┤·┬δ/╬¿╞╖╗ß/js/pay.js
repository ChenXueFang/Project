window.onload=function(){
	var vip = document.getElementById("vip");
	var jsVip = document.getElementById("jsVip");
	var ul1 = document.getElementsByClassName("ul1")[0];
	var ul1Li = ul1.getElementsByTagName("li")[2];
	var ul1LiI = ul1.getElementsByClassName("icon-kefu")[0];
	ul1Li.onmouseover=function(){
		this.style.color = "#333";
		ul1LiI.style.color = "#333";
	}
	ul1Li.onmouseout=function(){
		this.style.color = "#808080";
		ul1LiI.style.color = "#808080";
	}
	vip.onmouseover=function(){
		jsVip.style.display = "block";
	}
	vip.onmouseout=function(){
		jsVip.style.display = "none";
	}
//	支付倒计的时间开始
	var pay29 = document.getElementsByClassName("pay29")[0];
	var pay59 = document.getElementsByClassName("pay59")[0];
	var pleasePay = document.getElementsByClassName("pleasePay")[0];
	var minute = 29;
     var second = 59;
     if(minute < 10) minute = "0" + minute;
//   if(second < 10) second = "0" + second;
     setInterval(function() {
     	pay29.innerHTML = minute;
     	pay59.innerHTML = second;
         second--;
         if(second == 00 && minute == 00) {
            // pp.innerHTML="sss";
            pleasePay.style.display = "none";
             return flase;
         }; //当分钟和秒钟都为00时，重新给值
         if(second == 0) {
             second = 59;
             minute--;
             if(minute < 10) minute = "0" + minute;
         }; //当秒钟为00时，秒数重新给值
         if(second < 10) second = "0" + second;
         
     }, 1000);
//	支付倒计的时间结束
//分期数的tab切换开始
	var fenqiXuan = document.getElementsByClassName("fenqiXuan")[0];
	var fenQiLv = document.getElementsByClassName("fenQiLv");
	var liArr = fenqiXuan.getElementsByTagName("li");
	console.log(liArr);
	console.log(fenQiLv);
	for(var i=0;i<liArr.length;i++){
		liArr[i].index = i;
		liArr[i].onclick = function(){
			for(var j=0;j<fenQiLv.length;j++){
				liArr[j].className = "";
				fenQiLv[j].className = "fenQiLv";
			}
			this.className = "borderFQ";
		fenQiLv[this.index].className = "fenQiLv openQi";
		}
		
	}
//分期数的tab切换结束
//选择付款方式的tab切换开始
//	圆点外框
	var selDian = document.getElementsByClassName("selDian");
	console.log(selDian);
//	圆点
	var yuantu = document.getElementsByClassName("yuantu");
	console.log(yuantu);
//	三个li
	var anniuLi = document.getElementsByClassName("anniuLi");
	console.log(anniuLi);
//	出现支付58
	var sanGe58 = document.getElementsByClassName("sanGe58");
	console.log(sanGe58);
	for(var i=0;i<anniuLi.length;i++){
		anniuLi[i].index = i;
		anniuLi[i].onclick = function(){
			for(var j=0;j<yuantu.length;j++){
				yuantu[j].className = "yuantu";
				anniuLi[j].className = "anniuLi";
				sanGe58[j].className = "payTail sanGe58";
			}
			yuantu[this.index].className = "iconfont icon-dian2 yuantu";
			anniuLi[this.index].className = "backg anniuLi";
			sanGe58[this.index].className = "payTail sanGe58 blockSG58";
		}
	}
	
	for(var i=0;i<selDian.length;i++){
		selDian[i].index = i;
		selDian[i].onmouseover = function(){
			this.style.border = "1px solid #333";
			if(yuantu[this.index].className =="iconfont icon-dian2 yuantu"){
				this.style.border = "1px solid #b8b8b8";
			}
		}
		selDian[i].onmouseout = function(){
			this.style.border = "1px solid #b8b8b8";
//			if(yuantu[this.index].className = "iconfont icon-dian2 yuantu"){
//				this.style.border = "1px solid #b8b8b8";
//			}
		}
	}
	
//	选择付款方式的tab切换结束
//	选择使用的银行卡开始
	var weixinPT = document.getElementById("weixinPT");
	var liArr2 = weixinPT.getElementsByTagName("li");
	console.log(liArr2);
	for(var i=0;i<liArr2.length;i++){
//		this.style.border = "2px solid #b8b8b8";
		liArr2[i].onmouseover = function(){
			this.style.width = "175px";
			this.style.height= "48px";
			this.style.border = "2px solid #7cbf13";
		}
		liArr2[i].onmouseout = function(){
			this.style.width = "177px";
			this.style.height= "50px";
			this.style.border = "1px solid #d2d1d1";
		}
	}
//选择哪个银行
	var lotsBank = document.getElementById("lotsBank");
	var liArr3 = lotsBank.getElementsByTagName("li");
	var cxOrXy = lotsBank.getElementsByClassName("cxOrXy");
	for(var i=0;i<liArr3.length;i++){
		liArr3[i].index=i;
		liArr3[i].onmouseover = function(){
			cxOrXy[this.index].style.display = "block";
		}
		liArr3[i].onmouseout = function(){
			cxOrXy[this.index].style.display = "none";
		}
	}
//	***************更多银行***********
	var moreBank = document.getElementById("moreBank");
	moreBank.onmouseover = function(){
		this.style.border = "1px dashed #1D94D1";
		this.style.color = "#1D94D1"
	}
	moreBank.onmouseout = function(){
		this.style.border = "1px dashed #d2d1d1";
		this.style.color = "#666";
	}
//	****************选择付款方式的tab切换******************
	var bankCardTitle = document.getElementsByClassName("bankCardTitle")[0];
	var liArr4 = bankCardTitle.getElementsByTagName("li");
	var bankKuang = document.getElementsByClassName("bankKuang");
	for(var i=0;i<liArr4.length;i++){
		liArr4[i].index=i;
		liArr4[i].onclick = function(){
			for(var j=0;j<bankKuang.length;j++){
				liArr4[j].style.borderBottom = "1px solid #d2d1d1";
				liArr4[j].style.background = "#f6f6f6";
				bankKuang[j].style.display = "none";
			}
			this.style.borderBottom = "1px solid #fff";
			this.style.background = "#fff";
			this.style.zIndex = "200";
			bankKuang[this.index].style.display = "block";
		}
	}

	var footnav = document.getElementsByClassName("footnav")[0];
	var aboutAArr = footnav.getElementsByTagName("a");
	console.log(aboutAArr);
	var aboutUsZ = document.getElementsByClassName("aboutUsZ")[0];
	for(var i =0; i<aboutAArr.length; i++){
	aboutAArr[i].onmouseover=function fn(ev) {
        var event=window.event||ev;
        aboutUsZ.style.left=event.clientX+3+"px";
        aboutUsZ.style.top=event.clientY+20+"px";
        var textTu=this.innerHTML;
		console.log(textTu);
		aboutUsZ.innerHTML=textTu;
		aboutUsZ.style.display="block";
    }
	aboutAArr[i].onmouseout=function(){
		aboutUsZ.style.display="none";
	}
}
}
