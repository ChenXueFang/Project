window.onload = function(){
	var navBox = document.getElementById("nav_box");
	var login = document.getElementById("login");
	var i = document.getElementsByClassName("icon-triangle");
	var navUl = navBox.children[1];
	var navLi = navUl.children;
	var navLiO = navUl.children[0];
	var spanO = navLiO.children[1];
//	console.log(i);
//请登录的动作开始
	navLiO.onmouseover=function(){
		over(this);
		showB(login);
		spanO.style.color="#fff";
	}
	navLiO.onmouseout=function(){
		out(this);
		showN(login);
		spanO.style.color="#d4d4d4";
	}
//	请登录的动作结束
//	签到有礼的动作开始
	var navLiT = navUl.children[2];
	var signUp=document.getElementById("sign_up");
	var spanT=navLiT.children[2];
	
	navLiT.onmouseover=function(){
		this.style.zIndex=15;
		signUp.style.display="block";
	}
	navLiT.onmouseout=function(){
		signUp.style.display="none";
		this.style.zIndex=0;
	}
//	签到有礼的动作结束
//	我的特卖对的动作开始
	var navLiF = navUl.children[4];
	var mySpecial=document.getElementById("my_special");
	var spanF=navLiF.children[2];
	var em1 = navLiF.children[1];
	navLiF.onmouseover=function(){
		over(this);
		showB(mySpecial);
		spanF.style.color="#fff";
		em1.className="iconfont"+" icon-arrUp-fill";
		
	}
//	console.log(em1);
	navLiF.onmouseout=function(){
		out(this);
		showN(mySpecial);
		spanF.style.color="#d4d4d4";
		em1.className="iconfont"+" icon-triangle";
	}
//	我的特卖对的动作结束
//	会员俱乐部
	var navLiS = navUl.children[5];
	var vipClub=document.getElementById("vip_club");
	var spanS=navLiS.children[2];
	var em2 = navLiS.children[1];
	navLiS.onmouseover=function(){
		over(this);
		showB(vipClub);
		spanS.style.color="#fff";
		em2.className="iconfont"+" icon-arrUp-fill";
		
	}
//	console.log(em1);
	navLiS.onmouseout=function(){
		out(this);
		showN(vipClub);
		spanS.style.color="#d4d4d4";
		em2.className="iconfont"+" icon-triangle";
	}
//	会员俱乐部结束
//客服服务开始
	var navLiSe = navUl.children[6];
	var people=document.getElementById("people");
	var spanSe=navLiSe.children[2];
	var em3 = navLiSe.children[1];
	navLiSe.onmouseover=function(){
		over(this);
		showB(people);
		spanSe.style.color="#fff";
		em3.className="iconfont"+" icon-arrUp-fill";
		
	}
//	console.log(em1);
	navLiSe.onmouseout=function(){
		out(this);
		showN(people);
		spanSe.style.color="#d4d4d4";
		em3.className="iconfont"+" icon-triangle";
	}
//客服服务结束
//手机版开始
	var navLiE = navUl.children[7];
	var phone=document.getElementById("phone");
	var spanE=navLiE.children[2];
	navLiE.onmouseover=function(){
		over(this);
		showB(phone);
		spanE.style.color="#fff";		
	}
//	console.log(em1);
	navLiE.onmouseout=function(){
		out(this);
		showN(phone);
		spanE.style.color="#d4d4d4";
	}
//手机版结束
//更多开始
	var navLiL = navUl.children[8];
	var more=document.getElementById("more");
	var em4 = navLiL.children[1];
	navLiL.onmouseover=function(){
		over(this);
		showB(more);
		this.style.borderBottom="1px solid #fff";
		em4.className="iconfont"+" icon-arrUp-fill";
	}
	more.onmouseover=function(){
		over(navLiL);
		showB(this);
		navLiL.style.borderBottom="1px solid #fff";
		em4.className="iconfont"+" icon-arrUp-fill";
	}
	navLiL.onmouseout=function(){
		out(this);
		showN(more);
		em4.className="iconfont"+" icon-triangle";
	}
	more.onmouseout=function(){
		out(navLiL);
		showN(this);
		em4.className="iconfont"+" icon-triangle";
	}
//更多结束

//点击省份或者城市进行切换	
	var topBox=document.getElementById("tap_box");
	var topBoxUl=topBox.children[0];
    var liArr = topBoxUl.children; 
    var spanArr = topBox.getElementsByTagName("span");
//  console.log(spanArr);
    //2.绑定事件（循环绑定）
    for(var i=0;i<liArr.length;i++){
    //绑定索引值(自定义属性)
    liArr[i].setAttribute("index",i);
    liArr[i].onclick= function () {
        //3.书写事件驱动程序（排他思想）
        //1.点亮盒子。   2.利用索引值显示盒子。(排他思想)
        for(var j=0;j<liArr.length;j++){
        liArr[j].removeAttribute("class");
        spanArr[j].removeAttribute("id");
        }
        this.setAttribute("class","city");
        spanArr[this.getAttribute("index")].setAttribute("id","spcity");
        }
    }
//  点击省份或者城市进行切换结束
//选择地区的动作开始
	var navLeft = navBox.children[0];
	var dingWei=document.getElementById("dingwei");
	var iconCuo=dingWei.getElementsByClassName("icon-cuo");
//	console.log(iconCuo);
//	document.onclick = function(){
//		dingWei.style.display = "none";
//	}
//	var em4 = navLiL.children[1];
	navLeft.onclick=function(){
		over(this);
		showB(dingWei);
		this.style.borderBottom="1px solid #fff";
	}
//	dingWei.onclick=function(){
//		over(navLeft);
//		showB(this);
//		navLeft.style.borderBottom="1px solid #fff";
//	}
	iconCuo[0].onclick = function(){
		dingWei.style.display = "none";
		out(navLeft);
	}
//选择地区的动作结束
//logo标志自动轮播开始
var currentIndex = 0;	
	//每个2s切换一次
	var autoTimer = setInterval(function(){
		//计算接下来索引值
		var nextIndex = currentIndex!=1?currentIndex+1:0;		
		//获取图片列表对象
		var logo = document.querySelector('.logo');
		
		//1.使当前显示的逐渐消失
		var current = logo.children[currentIndex];
		var fadeOut = setInterval(function(){
			var opacity = parseFloat(getComputedStyle(current).opacity);
			if(opacity>0){
				opacity = opacity-0.1;
				console.log(opacity);
				current.style.opacity = opacity;
			}else{
				clearInterval(fadeOut);
				fadeOut = null;
			}
		},30);
		
		//2.使接下来那张图逐渐出现		
		var next = logo.children[nextIndex];
		var fadeIn = setInterval(function(){
			var opacity = parseFloat(getComputedStyle(next).opacity);
			if(opacity < 1){
				opacity = opacity+0.1;
				next.style.opacity = opacity;
			}else{
				clearInterval(fadeIn);
				fadeIn = null;
			}
		},20);		
		//激活当前导航按钮
		//更新当前索引值
		currentIndex = nextIndex;
	},2000);
//	logo标志自动轮播结束
//点击购物袋的效果开始
//	var searchBox = document.getElementById("searchBox");
//	console.log(searchBox);
	var shopping= document.getElementsByClassName("shopping")[0];
	var shopDai= document.getElementsByClassName("shopDai")[0];
//	console.log(shopDai);
//	var phone=document.getElementById("phone");
//	var spanE=navLiE.children[2];
	shopping.onmouseover=function(){
		over(this);		
		showB(shopDai);	
		shopDai.style.zIndex=40;
	}
//	console.log(em1);
	shopping.onmouseout=function(){
		out(this);
		this.style.border="1px solid #ccc";
		this.style.height="32px";
		showN(shopDai);
	}
//点击购物袋的效果结束
//点击删除的效果开始
	var shanChu= document.getElementsByClassName("icon-picture-delet")[0];
	var clearHis= document.getElementById("clearHis");
	var searchHis= document.getElementsByClassName("searchHis")[0];
	var search=document.getElementsByClassName("search")[0];
//	var inputS=search.children[0];
//	console.log(inputS);
//	shanChu.onmouseover=function(){
//			shanChu.style.color="#fa2a83"
//			clearHis.style.display="block";
//	}
//	shanChu.onmouseout=function(){
//			shanChu.style.color="#999"
//			clearHis.style.display="none";
//	}
//	inputS.onfocus=function(){
//		searchHis.style.display="block";
//		searchHis.style.zIndex=40;
//	}
//	inputS.onblur=function(){
//		searchHis.style.display="none";
//	}
//点击删除的效果结束
//商品分类开始
	var goodsClass=document.getElementsByClassName("goodsClass")[0];
	var goodsUl=document.getElementById("goodsUl");
	goodsClass.onmouseover=function(){
			goodsUl.style.display="block";
//			animate(goodsUl,{"display":block});
			goodsUl.style.zIndex=30;
	}
	goodsUl.onmouseover=function(){
			this.style.display="block";
			
			this.style.zIndex=30;
	}
	goodsClass.onmouseout=function(){
			goodsUl.style.display="none";
	}
	goodsUl.onmouseout=function(){
			this.style.display="none";
	}
//商品分类结束
	var moreClass=document.getElementsByClassName("moreClass")[0];
	var moreClassA=moreClass.children[0];
	var moreClassUl=moreClass.children[1];
//	console.log(moreClassA);
//	console.log(moreClassUl);
	moreClassA.onmouseover=function(){
			moreClassUl.style.display="block";
			this.style.boxShadow="0px -2px  1px  1px #ddd";
			this.style.background="#fff";
			moreClassUl.style.zIndex=30;
	}
	moreClassUl.onmouseover=function(){
			this.style.display="block";
			moreClassA.style.boxShadow="0px -2px  1px  1px #ddd";
			moreClassA.style.background="#fff";
			this.style.zIndex=30;
	}
	moreClassA.onmouseout=function(){
			moreClassUl.style.display="none";
			this.style.boxShadow="none";
			this.style.background="#fff";
	}
	moreClassUl.onmouseout=function(){
			this.style.display="none";
			moreClassA.style.boxShadow="none";
			moreClassA.style.background="#fff";
	}
//	*******************商品分类效果选择框的动态效果*****************
	var spanBox = document.getElementById("spanBox");
   	var liArr1 = goodsUl.children;
    var spanArr1 = spanBox.getElementsByTagName("span");
    console.log(spanArr1);
    console.log(liArr1);
    //2.绑定事件（循环绑定）
     for(var i=0;i<liArr1.length;i++){
     	liArr1[i].setAttribute("index",i);
    	liArr1[i].onmouseover = function(){
    		for(var j=0;j<liArr1.length;j++){
    			spanArr1[j].setAttribute("index1",j);
    			liArr1[j].className='';
    			spanArr1[j].className='';
    		}
    	this.setAttribute("class","goodsLi");
    	spanArr1[this.getAttribute("index")].setAttribute("class","goodSpan");   	
    } 
    
    liArr1[i].onmouseout = function(){
    	spanArr1[this.getAttribute("index")].onmouseover=function(){
    		this.setAttribute("class","goodSpan");
    		goodsUl.style.display="block";
    		liArr1[this.getAttribute("index1")].setAttribute("class","goodsLi");
    	}
    	spanArr1[this.getAttribute("index")].onmouseout=function(){
    		this.className=''; 
    		goodsUl.style.display="none";
    		liArr1[this.getAttribute("index1")].className='';
    	}
    	spanArr1[this.getAttribute("index")].className='';
    	this.className='';
    }
   }
   
   
   
   
   
   
   
// 商品的主要部分开始
	var mainNav=document.getElementsByClassName("mainNav")[0];
	var aTag = mainNav.getElementsByTagName("a");
	console.log(aTag);
	for(var i = 0;i<aTag.length; i++){
		aTag[i].onmouseover = function(){
			this.style.color = "#f10180";
		}
		aTag[i].onmouseout = function(){
			this.style.color = "#333";
		}
	}
	
	
//	放大镜
			var span = document.createElement("span");
             var box = document.getElementsByClassName("topGlass")[0];
             var img = document.createElement("img");
             var boxWidth = box.clientWidth;
             var boxHeight = box.clientHeight;
             var scale = 2; 
             span.style.position = "absolute";
             span.style.width = boxWidth/2+"px";
             span.style.height = boxHeight/2+"px";
             span.style.display = 'none';
             span.style.overflow = 'hidden';
             span.style.backgroundColor = "rgba(255, 255, 255, 0.5)";
             span.style.cursor = 'crosshair';
             box.appendChild(span);
            img.setAttribute("src", "../img/xuangou/big.png");
             img.style.width = scale*boxWidth + "px";
             img.style.height = scale*boxHeight + "px";
             box.onmouseover = function(e){
                 span.style.display = "block";
             }
             box.onmousemove = function(e){
                 e = e || window.event;
                 var x = e.clientX - span.clientWidth / scale - this.offsetLeft;
                 var y = e.clientY - span.clientHeight / scale -this.offsetLeft;
                 if (x <= 0){
                     x = 0
                 }
                 if (x >= box.clientWidth - span.clientWidth){
                     x = box.clientWidth - span.clientWidth
                 }
                 if (y <= 0){
                     y = 0
                 }
                 if (y >= box.clientHeight - span.clientHeight){
                     y = box.clientHeight - span.clientHeight
                 }
                 span.style.left = x+ "px";
                 span.style.top = y + "px";
                 
                 img.style.marginLeft = -1 * span.offsetLeft * scale - x + "px";
                 img.style.marginTop = -1 * span.offsetTop * scale - y + "px";
                 span.appendChild(img);
             }
 
             box.onmouseout = function(e){
                 span.style.display = "none";
             }
             
//  放大镜下的分享开始
	var share = document.getElementsByClassName("share")[0];
	var haha = document.getElementsByClassName("haha")[0];
	var kqwx = document.getElementsByClassName("kqwx")[0];
	share.onmouseover = function(){
		this.style.background = "#fff";
		haha.style.display = "block";
		kqwx.style.display = "block";
		
	}
	share.onmouseout = function(){
		this.style.background = "#fafafa";
		haha.style.display = "none";
		kqwx.style.display = "none";
	}
//  放大镜下的分享结束
//	选择收货地址
	var tltleAddregs = document.getElementsByClassName("tltleAddregs")[0];
	var liArr8 = tltleAddregs.getElementsByTagName("li");
	var moreAddrage = document.getElementsByClassName("moreAddrage");
	console.log(liArr8);
	console.log(moreAddrage);
	for(var i=0;i<liArr8.length;i++){
		liArr8[i].index=i;
		liArr8[i].onclick = function(){
			for(var j=0;j<moreAddrage.length;j++){
				moreAddrage[j].className = "moreAddrage";
				liArr8[j].className = "";
			}
			this.className = "topAddBottom";
			moreAddrage[this.index].className = "moreAddrage blocked";
		}
	}
//	关闭的按钮
	var scqjCuo = document.getElementById("scqjCuo");
	console.log(scqjCuo);
	var shenChengQuJie = document.getElementsByClassName("shenChengQuJie")[0];
	scqjCuo.onclick = function(){
		shenChengQuJie.style.display = "none";
		this.style.display = "none";
		shang.className = "iconfont icon-arrow-down";
	}
//	打开地址的tab切换
	var peiSongAggre = document.getElementsByClassName("peiSongAggre")[0];
	var shang = document.getElementById("shang");
	console.log(peiSongAggre);
	peiSongAggre.onclick = function(){
			shenChengQuJie.style.display = "block";
			shang.className = "iconfont icon-top";
			shenChengQuJie.style.zIndex = "400";
			scqjCuo.style.display = "block";
	}
	
//	加入购物车的数量
	var liLi3 = document.getElementsByClassName("liLi3")[0];
	var liLi2 = document.getElementsByClassName("liLi2")[0];
	var liLi1 = document.getElementsByClassName("liLi1")[0];
	liLi2.onclick =function(){
		liLi1.innerText = Number(liLi1.innerText)+1;
		liLi3.style.color = "#7c7c7c";
		liLi3.style.cursor="pointer";
	}
	liLi3.onclick =function(){
		liLi1.innerText = Number(liLi1.innerText)-1;
		if(liLi1.innerText<=1){
			liLi1.innerText=1;
			liLi3.style.color = "#dad8d8";
			liLi3.style.cursor="no-drop";
		}
		
	}
	
//	-商品详情,商品咨询,关于我们开始
	var navDeRefer = document.getElementById("navDeRefer");
	var navUl1 = navDeRefer.getElementsByTagName("ul")[0];
	var liArrNav = navUl1.getElementsByTagName("li");
	console.log(liArrNav);
	for(var i=0;i<liArrNav.length;i++){
		liArrNav[i].onclick = function(){
			for(var j=0;j<liArrNav.length;j++){
				liArrNav[j].className = "";
			}
			this.className = "gaiBian";
		}
	}
	
//	足迹
	var zujiBox = document.getElementById("zujiBox");
	var imgszuJi = document.getElementById("imgszuJi");
	var lis = imgszuJi.getElementsByTagName("li");
	var arranniu = document.getElementById("arranniu");
 	var arrLeft = arranniu.children[0];
 	var arrRight = arranniu.children[1];	
	console.log(lis);
	//需求：1.鼠标放到图片上显示切换按钮，移开图片，隐藏按钮
	zujiBox.onmouseover = function () {
		arranniu.style.display = "block";
	}
	zujiBox.onmouseout = function () {
		arranniu.style.display = "none";
	}

	var target = 0;
	//需求1：点击按钮，让图片显示下一张。
	arrLeft.onclick = function () {
//		imgszuJi.style.left + = 1002;
		target += 1002;
		if(target>=0){
			target =0;
			this.style.cursor = "no-drop";
		}
		arrRight.style.cursor = "pointer";
		animate3(imgszuJi,target);
	}
	arrRight.onclick = function () {
		target -= 1002;
		if(target<= - (lis.length-1)*1002){
			target = -(lis.length-1)*1002;
			this.style.cursor = "no-drop";
		}
		arrLeft.style.cursor = "pointer";
		animate3(imgszuJi,target);
		
	}
//	商品的主要部分结束
//关于我们
	var grey = document.getElementsByClassName("grey")[0];
	var imgGrey = grey.getElementsByTagName("img");
	var imgMain = document.getElementById("imgMain");
	for(var i=0;i<imgGrey.length;i++){
		imgGrey[i].index=i;
		imgGrey[i].onmouseover = function(){
			this.src = "../img/xuangou/pink ("+this.index+").png"
		}
		imgGrey[i].onmouseout = function(){
			this.src = "../img/xuangou/grey ("+this.index+").png";
			if(this.src === "../img/xuangou/pink ("+this.index+").png"){
				this.src = "../img/xuangou/pink ("+this.index+").png"
			}
		}
	}
//	点击
//	for(var i=0;i<imgGrey.length;i++){
//		imgGrey[i].index=i;
//		imgGrey[i].onclick = function(){
//			for(var j=0;j<imgGrey.length;j++){
//				imgGrey[j].src = "../img/xuangou/grey ("+this.index+").png";
//			}
//			this.src = "../img/xuangou/pink ("+this.index+").png";
//		}
//	}
	
	var weBox = document.getElementById("weBox");
	var imgsWe = document.getElementById("imgsWe");
	var lismain = imgsWe.getElementsByTagName("li");
	var arrWe = document.getElementById("arrWe");
 	var arrLeft1 = arrWe.children[0];
 	var arrRight1 = arrWe.children[1];	
	console.log(lis);
	//需求：1.鼠标放到图片上显示切换按钮，移开图片，隐藏按钮
//	weBox.onmouseover = function () {
//		arrWe.style.display = "block";
//	}
//	weBox.onmouseout = function () {
//		arrWe.style.display = "none";
//	}

	var target = 0;
	//需求1：点击按钮，让图片显示下一张。
	arrLeft1.onclick = function () {
//		imgszuJi.style.left + = 1002;
		target += 1002;
		if(target>=0){
			target =0;
//			this.style.cursor = "no-drop";
		}
//		arrRight1.style.cursor = "pointer";
		animate3(imgsWe,target);
	}
	arrRight1.onclick = function () {
		target -= 1002;
		if(target<= - (lismain.length-1)*1002){
			target = -(lismain.length-1)*1002;
//			this.style.cursor = "no-drop";
		}
//		arrLeft1.style.cursor = "pointer";
		animate3(imgsWe,target);
		
	}

	var detailsBox = document.getElementsByClassName("detailsBox")[0];
	var askedBox = document.getElementsByClassName("askedBox")[0];
	var mainAbout = document.getElementsByClassName("mainAbout")[0];
	var oldTime = document.getElementsByClassName("oldTime")[2];
//	************************************************************
	var kk1 = document.getElementById("kk1");
	var kk2 = document.getElementById("kk2");
	var noBorder = document.getElementById("noBorder");
	kk1.onclick = function(){
		detailsBox.style.display = "block";
		askedBox.style.display = "block";
		mainAbout.style.display = "block";
		this.style.borderBottom = "3px solid #f10180";
		this.style.color = "#f10180";
		kk2.style.borderBottom = "3px solid #000";
		kk2.style.color = "#333";
		noBorder.style.borderBottom = "3px solid #000";
		noBorder.style.color = "#333";
		
	}
	kk2.onclick = function(){
		detailsBox.style.display = "none";
		askedBox.style.display = "block";
		mainAbout.style.display = "none";
		this.style.borderBottom = "3px solid #f10180";
		this.style.color = "#f10180";
		kk1.style.borderBottom = "3px solid #000";
		kk1.style.color = "#333";
		noBorder.style.borderBottom = "3px solid #000";
		noBorder.style.color = "#333";
	}
	noBorder.onclick = function(){
		detailsBox.style.display = "none";
		askedBox.style.display = "none";
		mainAbout.style.display = "block";
		oldTime.style.display = "none";
		this.style.borderBottom = "3px solid #f10180";
		this.style.color = "#f10180";
		kk2.style.borderBottom = "3px solid #000";
		kk2.style.color = "#333";
		kk1.style.borderBottom = "3px solid #000";
		kk1.style.color = "#333";
	}
	

var rightBrand = document.getElementsByClassName("rightBrand");
	var riBrTe = document.getElementsByClassName("riBrTe");
	console.log(rightBrand);
	console.log(riBrTe);
	for(var i=0;i<rightBrand.length;i++){
//		我的优惠卷
		rightBrand[0].onmouseover=function(){
			this.style.background="#df147f";
			animate(riBrTe[0], {"width":117},
			riBrTe[0].innerHTML="我的优惠卷");		
		}
		rightBrand[0].onmouseout=function(){
			this.style.background="";
			animate(riBrTe[0], {"width":0});
			riBrTe[0].innerHTML="";
		}
//		品牌收藏
		rightBrand[1].onmouseover=function(){
			this.style.background="#df147f";
			animate(riBrTe[1], {"width":117},
			riBrTe[1].innerHTML="品牌收藏");		
		}
		rightBrand[1].onmouseout=function(){
			this.style.background="";
			animate(riBrTe[1], {"width":0});
			riBrTe[1].innerHTML="";
		}
//      商品收藏
		rightBrand[2].onmouseover=function(){
			this.style.background="#df147f";
			animate(riBrTe[2], {"width":117},
			riBrTe[2].innerHTML="商品收藏");		
		}
		rightBrand[2].onmouseout=function(){
			this.style.background="";
			animate(riBrTe[2], {"width":0});
			riBrTe[2].innerHTML="";
		}
//		我的足迹
		rightBrand[3].onmouseover=function(){
			this.style.background="#df147f";
			animate(riBrTe[3], {"width":117},
			riBrTe[3].innerHTML="我的足迹");		
		}
		rightBrand[3].onmouseout=function(){
			this.style.background="";
			animate(riBrTe[3], {"width":0});
			riBrTe[3].innerHTML="";
		}
//		会员反馈
		rightBrand[4].onmouseover=function(){
			this.style.background="#df147f";
			animate(riBrTe[4], {"width":117},
			riBrTe[4].innerHTML="会员反馈");		
		}
		rightBrand[4].onmouseout=function(){
			this.style.background="";
			animate(riBrTe[4], {"width":0});
			riBrTe[4].innerHTML="";
		}
//		返回顶部
		rightBrand[5].onmouseover=function(){
			this.style.background="#df147f";
			animate(riBrTe[5], {"width":117},
			riBrTe[5].innerHTML="返回顶部");		
		}
		rightBrand[5].onmouseout=function(){
			this.style.background="";
			animate(riBrTe[5], {"width":0});
			riBrTe[5].innerHTML="";
		}		
	}
//	账户
	var middle = document.getElementsByClassName("middle")[0];
	var middleI = middle.getElementsByTagName("i");
	var middleA = middle.getElementsByTagName("a");
	console.log(middleI);
	console.log(middleA);
	for(var i=0; i<middleI.length; i++){
		middleI[i].index=i;
		middleI[i].onmouseover=function(){
			this.style.color="#f78ec5";
			middleA[this.index].style.color="#f10180";
		}
		middleI[i].onmouseout=function(){
			this.style.color="#c4c4c4";
			middleA[this.index].style.color="#333";
		}
	}
	for(var i=0; i<middleA.length; i++){
		middleA[i].index=i;
		middleA[i].onmouseover=function(){
			this.style.color="#f10180";
			middleI[this.index].style.color="#f78ec5";
		}
		middleA[i].onmouseout=function(){
			this.style.color="#333";
			middleI[this.index].style.color="#c4c4c4";
		}
	}
//	账号部分的效果
	var zhangHao = document.getElementsByClassName("zhangHao")[0];
	var zTop = zhangHao.getElementsByClassName("top")[0];
	var zSpan = zhangHao.getElementsByTagName("span")[0];
	var zhangHaoJs=zhangHao.getElementsByClassName("zhangHaoJs")[0];
	console.log(zSpan);
	zhangHao.onmouseover=function(){
		this.style.background="#df147f";
		zhangHaoJs.style.display="block";		
	}
	zhangHao.onmouseout=function(){
		this.style.background="";
		zhangHaoJs.style.display="none";		
	}
	zSpan.onclick=function(){
		zhangHao.style.background="";
		zhangHaoJs.style.display="none";
	}


//	商品加入购物车
	var jiesuanhaha = document.getElementById("jiesuanhaha");
	var aGouwu = jiesuanhaha.getElementsByTagName("a")[0];
	var joinGoyWu = document.getElementsByClassName("joinGoyWu")[0];
	console.log(joinGoyWu);
	joinGoyWu.onclick = function(){
		aGouwu.innerText = "1";
	}



function animate3(obj,target) {
	clearInterval(obj.timer)

	var speed = obj.offsetLeft < target ? 15 : -15;

	obj.timer = setInterval(function () {
		var result = target - obj.offsetLeft;

		obj.style.left = obj.offsetLeft + speed + "px";
		console.log(speed);
		if(Math.abs(result) <= 10 ){
			clearInterval(obj.timer);
			obj.style.left = target + "px";
		}

	},3);
  }   
     
     
     
     
     
     
     
     
     
	
}
