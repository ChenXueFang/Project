window.onload=function(){
	var navBox = document.getElementById("nav_box");
	var login = document.getElementById("login");
	var i = document.getElementsByClassName("icon-triangle");
	var navUl = navBox.children[1];
	var navLi = navUl.children;
	var navLiO = navUl.children[0];
	var spanO = navLiO.children[1];
//	console.log(i);
//请登录的动作开始
	navLiO.onmouseover=function(){
		over(this);
		showB(login);
		spanO.style.color="#fff";
	}
	navLiO.onmouseout=function(){
		out(this);
		showN(login);
		spanO.style.color="#d4d4d4";
	}
//	请登录的动作结束
//	签到有礼的动作开始
	var navLiT = navUl.children[2];
	var signUp=document.getElementById("sign_up");
	var spanT=navLiT.children[2];
	
	navLiT.onmouseover=function(){
		this.style.zIndex=15;
		signUp.style.display="block";
	}
	navLiT.onmouseout=function(){
		signUp.style.display="none";
		this.style.zIndex=0;
	}
//	签到有礼的动作结束
//	我的特卖对的动作开始
	var navLiF = navUl.children[4];
	var mySpecial=document.getElementById("my_special");
	var spanF=navLiF.children[2];
	var em1 = navLiF.children[1];
	navLiF.onmouseover=function(){
		over(this);
		showB(mySpecial);
		spanF.style.color="#fff";
		em1.className="iconfont"+" icon-arrUp-fill";
		
	}
//	console.log(em1);
	navLiF.onmouseout=function(){
		out(this);
		showN(mySpecial);
		spanF.style.color="#d4d4d4";
		em1.className="iconfont"+" icon-triangle";
	}
//	我的特卖对的动作结束
//	会员俱乐部
	var navLiS = navUl.children[5];
	var vipClub=document.getElementById("vip_club");
	var spanS=navLiS.children[2];
	var em2 = navLiS.children[1];
	navLiS.onmouseover=function(){
		over(this);
		showB(vipClub);
		spanS.style.color="#fff";
		em2.className="iconfont"+" icon-arrUp-fill";
		
	}
//	console.log(em1);
	navLiS.onmouseout=function(){
		out(this);
		showN(vipClub);
		spanS.style.color="#d4d4d4";
		em2.className="iconfont"+" icon-triangle";
	}
//	会员俱乐部结束
//客服服务开始
	var navLiSe = navUl.children[6];
	var people=document.getElementById("people");
	var spanSe=navLiSe.children[2];
	var em3 = navLiSe.children[1];
	navLiSe.onmouseover=function(){
		over(this);
		showB(people);
		spanSe.style.color="#fff";
		em3.className="iconfont"+" icon-arrUp-fill";
		
	}
//	console.log(em1);
	navLiSe.onmouseout=function(){
		out(this);
		showN(people);
		spanSe.style.color="#d4d4d4";
		em3.className="iconfont"+" icon-triangle";
	}
//客服服务结束
//手机版开始
	var navLiE = navUl.children[7];
	var phone=document.getElementById("phone");
	var spanE=navLiE.children[2];
	navLiE.onmouseover=function(){
		over(this);
		showB(phone);
		spanE.style.color="#fff";		
	}
//	console.log(em1);
	navLiE.onmouseout=function(){
		out(this);
		showN(phone);
		spanE.style.color="#d4d4d4";
	}
//手机版结束
//更多开始
	var navLiL = navUl.children[8];
	var more=document.getElementById("more");
	var em4 = navLiL.children[1];
	navLiL.onmouseover=function(){
		over(this);
		showB(more);
		this.style.borderBottom="1px solid #fff";
		em4.className="iconfont"+" icon-arrUp-fill";
	}
	more.onmouseover=function(){
		over(navLiL);
		showB(this);
		navLiL.style.borderBottom="1px solid #fff";
		em4.className="iconfont"+" icon-arrUp-fill";
	}
	navLiL.onmouseout=function(){
		out(this);
		showN(more);
		em4.className="iconfont"+" icon-triangle";
	}
	more.onmouseout=function(){
		out(navLiL);
		showN(this);
		em4.className="iconfont"+" icon-triangle";
	}
//更多结束

//点击省份或者城市进行切换	
	var topBox=document.getElementById("tap_box");
	var topBoxUl=topBox.children[0];
    var liArr = topBoxUl.children; 
    var spanArr = topBox.getElementsByTagName("span");
//  console.log(spanArr);
    //2.绑定事件（循环绑定）
    for(var i=0;i<liArr.length;i++){
    //绑定索引值(自定义属性)
    liArr[i].setAttribute("index",i);
    liArr[i].onclick= function () {
        //3.书写事件驱动程序（排他思想）
        //1.点亮盒子。   2.利用索引值显示盒子。(排他思想)
        for(var j=0;j<liArr.length;j++){
        liArr[j].removeAttribute("class");
        spanArr[j].removeAttribute("id");
        }
        this.setAttribute("class","city");
        spanArr[this.getAttribute("index")].setAttribute("id","spcity");
        }
    }
//  点击省份或者城市进行切换结束
//选择地区的动作开始
	var navLeft = navBox.children[0];
	var dingWei=document.getElementById("dingwei");
	var iconCuo=dingWei.getElementsByClassName("icon-cuo");
//	console.log(iconCuo);
//	document.onclick = function(){
//		dingWei.style.display = "none";
//	}
//	var em4 = navLiL.children[1];
	navLeft.onclick=function(){
		over(this);
		showB(dingWei);
		this.style.borderBottom="1px solid #fff";
	}
//	dingWei.onclick=function(){
//		over(navLeft);
//		showB(this);
//		navLeft.style.borderBottom="1px solid #fff";
//	}
	iconCuo[0].onclick = function(){
		dingWei.style.display = "none";
		out(navLeft);
	}
//选择地区的动作结束
//logo标志自动轮播开始
var currentIndex = 0;	
	//每个2s切换一次
	var autoTimer = setInterval(function(){
		//计算接下来索引值
		var nextIndex = currentIndex!=1?currentIndex+1:0;		
		//获取图片列表对象
		var logo = document.querySelector('.logo');
		
		//1.使当前显示的逐渐消失
		var current = logo.children[currentIndex];
		var fadeOut = setInterval(function(){
			var opacity = parseFloat(getComputedStyle(current).opacity);
			if(opacity>0){
				opacity = opacity-0.1;
				console.log(opacity);
				current.style.opacity = opacity;
			}else{
				clearInterval(fadeOut);
				fadeOut = null;
			}
		},30);
		
		//2.使接下来那张图逐渐出现		
		var next = logo.children[nextIndex];
		var fadeIn = setInterval(function(){
			var opacity = parseFloat(getComputedStyle(next).opacity);
			if(opacity < 1){
				opacity = opacity+0.1;
				next.style.opacity = opacity;
			}else{
				clearInterval(fadeIn);
				fadeIn = null;
			}
		},20);		
		//激活当前导航按钮
		//更新当前索引值
		currentIndex = nextIndex;
	},2000);
//	logo标志自动轮播结束
//点击购物袋的效果开始
//	var searchBox = document.getElementById("searchBox");
//	console.log(searchBox);
	var shopping= document.getElementsByClassName("shopping")[0];
	var shopDai= document.getElementsByClassName("shopDai")[0];
//	console.log(shopDai);
//	var phone=document.getElementById("phone");
//	var spanE=navLiE.children[2];
	shopping.onmouseover=function(){
		over(this);		
		showB(shopDai);	
		shopDai.style.zIndex=40;
	}
//	console.log(em1);
	shopping.onmouseout=function(){
		out(this);
		this.style.border="1px solid #ccc";
		this.style.height="32px";
		showN(shopDai);
	}
//点击购物袋的效果结束
//点击删除的效果开始
	var shanChu= document.getElementsByClassName("icon-picture-delet")[0];
	var clearHis= document.getElementById("clearHis");
	var searchHis= document.getElementsByClassName("searchHis")[0];
	var search=document.getElementsByClassName("search")[0];
	var inputS=search.children[0];
//	console.log(inputS);
	shanChu.onmouseover=function(){
			shanChu.style.color="#fa2a83"
			clearHis.style.display="block";
	}
	shanChu.onmouseout=function(){
			shanChu.style.color="#999"
			clearHis.style.display="none";
	}
	inputS.onfocus=function(){
		searchHis.style.display="block";
		searchHis.style.zIndex=40;
	}
	inputS.onblur=function(){
		searchHis.style.display="none";
	}
//点击删除的效果结束
//商品分类开始
	var goodsClass=document.getElementsByClassName("goodsClass")[0];
	var goodsUl=document.getElementById("goodsUl");
	goodsClass.onmouseover=function(){
			goodsUl.style.display="block";
//			animate(goodsUl,{"display":block});
			goodsUl.style.zIndex=30;
	}
	goodsUl.onmouseover=function(){
			this.style.display="block";
			
			this.style.zIndex=30;
	}
	goodsClass.onmouseout=function(){
			goodsUl.style.display="none";
	}
	goodsUl.onmouseout=function(){
			this.style.display="none";
	}
//商品分类结束
	var moreClass=document.getElementsByClassName("moreClass")[0];
	var moreClassA=moreClass.children[0];
	var moreClassUl=moreClass.children[1];
//	console.log(moreClassA);
//	console.log(moreClassUl);
	moreClassA.onmouseover=function(){
			moreClassUl.style.display="block";
			this.style.boxShadow="0px -2px  1px  1px #ddd";
			this.style.background="#fff";
			moreClassUl.style.zIndex=30;
	}
	moreClassUl.onmouseover=function(){
			this.style.display="block";
			moreClassA.style.boxShadow="0px -2px  1px  1px #ddd";
			moreClassA.style.background="#fff";
			this.style.zIndex=30;
	}
	moreClassA.onmouseout=function(){
			moreClassUl.style.display="none";
			this.style.boxShadow="none";
			this.style.background="#fff";
	}
	moreClassUl.onmouseout=function(){
			this.style.display="none";
			moreClassA.style.boxShadow="none";
			moreClassA.style.background="#fff";
	}
//	*******************商品分类效果选择框的动态效果*****************
	var spanBox = document.getElementById("spanBox");
 	var liArr1 = goodsUl.children;
    var spanArr1 = spanBox.getElementsByTagName("span");
    console.log(spanArr1);
    console.log(liArr1);
    //2.绑定事件（循环绑定）
     for(var i=0;i<liArr1.length;i++){
     	liArr1[i].setAttribute("index",i);
    	liArr1[i].onmouseover = function(){
    		for(var j=0;j<liArr1.length;j++){
    			spanArr1[j].setAttribute("index1",j);
    			liArr1[j].className='';
    			spanArr1[j].className='';
    		}
    	this.setAttribute("class","goodsLi");
    	spanArr1[this.getAttribute("index")].setAttribute("class","goodSpan");   	
    } 
    
    liArr1[i].onmouseout = function(){
    	spanArr1[this.getAttribute("index")].onmouseover=function(){
    		this.setAttribute("class","goodSpan");
    		goodsUl.style.display="block";
    		liArr1[this.getAttribute("index1")].setAttribute("class","goodsLi");
    	}
    	spanArr1[this.getAttribute("index")].onmouseout=function(){
    		this.className=''; 
    		goodsUl.style.display="none";
    		liArr1[this.getAttribute("index1")].className='';
    	}
    	spanArr1[this.getAttribute("index")].className='';
    	this.className='';
    }
   }
// *******************商品分类效果选择框的动态效果*****************























//选购曼秀雷敦的中间部分开始
	var pinpaiImg = document.getElementById("pinpaiImg");
	var img = pinpaiImg.getElementsByTagName("img")[0];
	var dongMan = document.getElementsByClassName("dongMan")[0];
	pinpaiImg.onmouseover = function(){
		this.style.border = "1px solid #f10180";
		this.innerHTML = "曼秀雷敦";
		this.style.color = "#f10180";
		
	}
	pinpaiImg.onmouseout = function(){
		this.style.border = "1px solid #f0f0f0";
		this.innerHTML = '<img src="../img/xuangou/mx.png"/>';
	}
	
//	更多选的的收起与展开开始
	var moreXuanXiang = document.getElementsByClassName("moreXuanXiang")[0];
	var i = moreXuanXiang.getElementsByTagName("i")[0];
	console.log(i);
	var duoXuan = document.getElementById("duoXuan");
	var shouQi = document.getElementsByClassName("shouQi")[0];
	moreXuanXiang.onclick = function(){
		if(shouQi.style.display == "none"){
			shouQi.style.display = "block";			
			duoXuan.innerText = "点击收起";
			i.className = "iconfont icon-top";
		}
		else{
			shouQi.style.display = "none";
			i.className = "iconfont icon-arrow-down";
			duoXuan.innerText = "更多选项";
		}
	}
//更多选的的收起与展开开始
//价格区间开始
	var priceRange = document.getElementsByClassName("priceRange")[0];
	var sure = document.getElementById("sure");
	var ranges = document.getElementsByClassName("ranges");
	console.log(ranges);
	for(var i=0;i<ranges.length;i++){
		ranges[i].onfocus = function(){
			this.style.border = "1px solid #afafaf";
			this.style.boxShadow = "0px 0px 3px 1px #afafaf";
			sure.style.display = "block";
			priceRange.style.background = "#fff";
			priceRange.style.boxShadow = "0px 0px 3px 1px #afafaf";
		}
		ranges[i].onblur = function(){
			this.style.border = "1px solid #ddd";
			this.style.boxShadow = "none";
			sure.style.display = "none";
			priceRange.style.background = "#f5f5f5";
			priceRange.style.boxShadow = "none";
		}
	}
	
//价格区间结束
//鼠标移动在商品上的效果开始
	var goodsBox = document.getElementsByClassName("goodsBox");
	for(var i=0;i<goodsBox.length;i++){
		goodsBox[i].onmouseover = function(){
			this.style.boxShadow = "0px 0px 3px 1px #afafaf";
		}
		goodsBox[i].onmouseout = function(){
			this.style.boxShadow = "none";
		}
	}
//鼠标移动在商品上的效果结束

//选购曼秀雷敦的中间部分结束

























//脚部中的js效果开始
	var dler = document.getElementsByClassName("dler")[0];
	var ddArr= dler.getElementsByTagName("dd");
	var iArr= dler.getElementsByTagName("i");
	var aTextArr= dler.getElementsByTagName("a");
	var divArr= dler.getElementsByTagName("div");
	console.log(iArr);
	console.log(aTextArr);
	for(var i=0; i<ddArr.length; i++){
		ddArr[i].index=i;
		ddArr[i].onmouseover=function(){
			iArr[this.index].style.background = "#f10180";
			animate1(divArr[this.index],3);
			
		}
		ddArr[i].onmouseout=function(){
			iArr[this.index].style.background = "#6a6b6d";
			animate1(divArr[this.index],0);
		}
	}
//	关于我们部分开始
	var aboutBox = document.getElementById("aboutBox");
	var aboutAArr = aboutBox.getElementsByTagName("a");
	console.log(aboutAArr);
	var aboutUsZ = document.getElementsByClassName("aboutUsZ")[0];
	
//	for(var i =0; i<aboutAArr.length; i++){
//		aboutAArr[i].onmouseover=function(){
//			var textTu=this.innerHTML;
//			console.log(textTu);
//			aboutUsZ.innerHTML=textTu;
//		}
//	}
	for(var i =0; i<aboutAArr.length; i++){
	aboutAArr[i].onmouseover=function fn(ev) {
        var event=window.event||ev;
        aboutUsZ.style.left=event.clientX+3+"px";
        aboutUsZ.style.top=event.clientY+20+"px";
        var textTu=this.innerHTML;
		console.log(textTu);
		aboutUsZ.innerHTML=textTu;
		aboutUsZ.style.display="block";
    }
	aboutAArr[i].onmouseout=function(){
		aboutUsZ.style.display="none";
	}
}
	
		
	
	
//关于我们部分结束
//脚部中的js效果结束
	var rightBrand = document.getElementsByClassName("rightBrand");
	var riBrTe = document.getElementsByClassName("riBrTe");
	console.log(rightBrand);
	console.log(riBrTe);
	for(var i=0;i<rightBrand.length;i++){
//		我的优惠卷
		rightBrand[0].onmouseover=function(){
			this.style.background="#df147f";
			animate(riBrTe[0], {"width":117},
			riBrTe[0].innerHTML="我的优惠卷");		
		}
		rightBrand[0].onmouseout=function(){
			this.style.background="";
			animate(riBrTe[0], {"width":0});
			riBrTe[0].innerHTML="";
		}
//		品牌收藏
		rightBrand[1].onmouseover=function(){
			this.style.background="#df147f";
			animate(riBrTe[1], {"width":117},
			riBrTe[1].innerHTML="品牌收藏");		
		}
		rightBrand[1].onmouseout=function(){
			this.style.background="";
			animate(riBrTe[1], {"width":0});
			riBrTe[1].innerHTML="";
		}
//      商品收藏
		rightBrand[2].onmouseover=function(){
			this.style.background="#df147f";
			animate(riBrTe[2], {"width":117},
			riBrTe[2].innerHTML="商品收藏");		
		}
		rightBrand[2].onmouseout=function(){
			this.style.background="";
			animate(riBrTe[2], {"width":0});
			riBrTe[2].innerHTML="";
		}
//		我的足迹
		rightBrand[3].onmouseover=function(){
			this.style.background="#df147f";
			animate(riBrTe[3], {"width":117},
			riBrTe[3].innerHTML="我的足迹");		
		}
		rightBrand[3].onmouseout=function(){
			this.style.background="";
			animate(riBrTe[3], {"width":0});
			riBrTe[3].innerHTML="";
		}
//		会员反馈
		rightBrand[4].onmouseover=function(){
			this.style.background="#df147f";
			animate(riBrTe[4], {"width":117},
			riBrTe[4].innerHTML="会员反馈");		
		}
		rightBrand[4].onmouseout=function(){
			this.style.background="";
			animate(riBrTe[4], {"width":0});
			riBrTe[4].innerHTML="";
		}
//		返回顶部
		rightBrand[5].onmouseover=function(){
			this.style.background="#df147f";
			animate(riBrTe[5], {"width":117},
			riBrTe[5].innerHTML="返回顶部");		
		}
		rightBrand[5].onmouseout=function(){
			this.style.background="";
			animate(riBrTe[5], {"width":0});
			riBrTe[5].innerHTML="";
		}		
	}
//	账户
	var middle = document.getElementsByClassName("middle")[0];
	var middleI = middle.getElementsByTagName("i");
	var middleA = middle.getElementsByTagName("a");
	console.log(middleI);
	console.log(middleA);
	for(var i=0; i<middleI.length; i++){
		middleI[i].index=i;
		middleI[i].onmouseover=function(){
			this.style.color="#f78ec5";
			middleA[this.index].style.color="#f10180";
		}
		middleI[i].onmouseout=function(){
			this.style.color="#c4c4c4";
			middleA[this.index].style.color="#333";
		}
	}
	for(var i=0; i<middleA.length; i++){
		middleA[i].index=i;
		middleA[i].onmouseover=function(){
			this.style.color="#f10180";
			middleI[this.index].style.color="#f78ec5";
		}
		middleA[i].onmouseout=function(){
			this.style.color="#333";
			middleI[this.index].style.color="#c4c4c4";
		}
	}
//	账号部分的效果
	var zhangHao = document.getElementsByClassName("zhangHao")[0];
	var zTop = zhangHao.getElementsByClassName("top")[0];
	var zSpan = zhangHao.getElementsByTagName("span")[0];
	var zhangHaoJs=zhangHao.getElementsByClassName("zhangHaoJs")[0];
	console.log(zSpan);
	zhangHao.onmouseover=function(){
		this.style.background="#df147f";
		zhangHaoJs.style.display="block";		
	}
	zhangHao.onmouseout=function(){
		this.style.background="";
		zhangHaoJs.style.display="none";		
	}
	zSpan.onclick=function(){
		zhangHao.style.background="";
		zhangHaoJs.style.display="none";
	}
	
	function animate1(ele,target) {
                clearInterval(ele.timer);
                ele.timer = setInterval(function () {
                    var step = (target-ele.offsetLeft)/10;
                    step = step>0?Math.ceil(step):Math.floor(step);
                    ele.style.left = ele.offsetLeft + step + "px";
                    console.log(1);
                    if(Math.abs(target-ele.offsetLeft)<Math.abs(step)){
                        ele.style.left = target + "px";
                        clearInterval(ele.timer);
                    }
                },18);
            }
//	让商品分类的导条一直在可适区域
//	var goodsBoxWai = document.getElementById("goodsBoxWai");
//	var goods = document.getElementById("goods");
//	window.onscroll = function () {
//              //2.判断 ，被卷曲的头部的大小
//              if(scroll().top > 180){
//                  //3.满足条件添加类，否则删除类
//                  goodsBoxWai.className = " fixed";
//                  goods.style.marginTop = "0px";
//                  //第二个盒子不占位置了，所以我们给第三个盒子一个上padding占位置，不出现盒子抖动问题
////                  main.style.paddingTop = middle.offsetHeight+"px";
//              }else{
//                  goodsBoxWai.className = "";
//                  goods.style.marginTop = "10px";
//                  //清零
////                  main.style.paddingTop = 0;
//              }
//          }
//	


}