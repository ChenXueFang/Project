window.onload=function(){   
     //	************毛衣选购部分的 效果开始*****************
     var hao = document.getElementsByClassName("hao");
     for(var i=0;i<hao.length;i++){
     	hao.onmouseover=function(){
     		this.style.color="red";
     	}
     	hao.onmouseout=function(){
     		this.style.color="yellow";
     	}
     }
     console.log(hao);
//	var countDown = document.getElementById("countDown");
//	console.log(countDown);
//	daojishi();
//function daojishi(){
//	var now = new Date();//开始时间 
//	var end = new Date("2019/01/29 00:00:00");//结束时间
//	var nowTime = now.getTime();//开始时间戳 
//	var endTime = end.getTime();//结束时间戳 
//	var cha = endTime-nowTime;//毫秒数 
//	console.log(cha);//毫秒数 
//
//	//秒数
//	var scha = parseInt(cha/1000);
//	console.log(scha);
//
//	// var m = parseInt(scha/60);
//	// console.log(m);
//
//	// var h = parseInt(m/60);
//	// console.log(h);
//
//	// var d = parseInt(h/24);
//	// console.log(d);
//	var d = parseInt(scha/60/60/24);
//	console.log(d);//14;
//
//	var s = scha%86400;
//	console.log(s);//23437
//
//	var h = parseInt(s/60/60);
//	s=s%3600;
//	console.log(s);
//	var m = parseInt(s/60);
//	console.log(m);
//	s = s%60;
//	console.log(s);
////	var ms=(s*1000)%100;
//	// 距离元旦还有14天9小时30分20秒""
//	// document.write("距离元旦还有"+d+"天"+h+"小时"+m+"分"+s+"秒");
//	countDown.innerHTML = "剩余"+d+"天"+h+"小时"+m+"分"+s+"秒";
//}
//setInterval(daojishi,1000);
////	************毛衣选购部分的 效果结束*****************
//
////名字中的收藏部分开始
//	var nameSouC = document.getElementsByClassName("nameSouC")[0];
//	var spanName = nameSouC.children[0];
//	var IName = spanName.children[0];
//	console.log(nameSouC);
//	console.log(spanName);
//	console.log(IName);
//	nameSouC.onmouseover=function(){
//		this.style.background= '#f10180';
//		this.style.border = "1px solid #f10180";
//		IName.style.color = "#fff";
//		spanName.style.color="#fff";
//		this.style.color = "#fff";
//	}
//	nameSouC.onmouseout=function(){
//		this.style.background= '#fff';
//		this.style.border = "1px solid #dfdfdf";
//		IName.style.color = "#f10180";
//		this.style.color = "#b5b5b5";
//		spanName.style.color="#f10180";
//	}
}