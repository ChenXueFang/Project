 window.onload =function(){
	var vip = document.getElementById("vip");
	var jsVip = document.getElementById("jsVip");
	var ul1 = document.getElementsByClassName("ul1")[0];
	var ul1Li = ul1.getElementsByTagName("li")[2];
	var ul1LiI = ul1.getElementsByClassName("icon-kefu")[0];
	console.log(vip);
	ul1Li.onmouseover=function(){
		this.style.color = "#333";
		ul1LiI.style.color = "#333";
	}
	ul1Li.onmouseout=function(){
		this.style.color = "#808080";
		ul1LiI.style.color = "#808080";
	}
	vip.onmouseover=function(){
		jsVip.style.display = "block";
	}
	vip.onmouseout=function(){
		jsVip.style.display = "none";
	}
//	20分钟内提交订单
	var upOn = document.getElementById("upOn");
	var minute = 19;
     var second = 59;
     if(minute < 10) minute = "0" + minute;
//   if(second < 10) second = "0" + second;
     setInterval(function() {
     	upOn.innerHTML = "<span>"+minute+"</span>分<span>"+second+"</span>秒";
         second--;
         if(second == 00 && minute == 00) {
            // pp.innerHTML="sss";
            upOn.style.display = "none";
             return flase;
         }; //当分钟和秒钟都为00时，重新给值
         if(second == 0) {
             second = 59;
             minute--;
             if(minute < 10) minute = "0" + minute;
         }; //当秒钟为00时，秒数重新给值
         if(second < 10) second = "0" + second;
         
     }, 1000);
     
//  地址管理及默认地址的效果开始
	var moRenAddre = document.getElementById("moRenAddre");
	var liArr = moRenAddre.getElementsByClassName("dizhiLi");
	var imgArr = moRenAddre.getElementsByTagName("img");
//	*************修改,删除,默认***********************
	var xiuGai = moRenAddre.getElementsByClassName("xiuGai");
	var clean = moRenAddre.getElementsByClassName("clean");
	var resetMoRen = moRenAddre.getElementsByClassName("resetMoRen");
//*************修改,删除,默认***********************
	console.log(imgArr);
	console.log(liArr);
	console.log(xiuGai);
	for(var i=0;i<liArr.length;i++){
		liArr[i].index=i;
		liArr[i].onmouseover = function(){			
//			console.log(this.index);
		this.className = "dizhiLi opaci";
		xiuGai[this.index].style.display = "block";
		clean[this.index].style.display = "block";
		resetMoRen[this.index].style.display = "block";
//			if(imgArr[this.index].className==="dui"){
//				this.style.className = "dizhiLi opaci";				
//			}
		}
		liArr[i].onmouseout = function(){
			xiuGai[this.index].style.display = "none";
			clean[this.index].style.display = "none";
			resetMoRen[this.index].style.display = "none";
			if(imgArr[this.index].className==="dui"){
				this.style.className = "dizhiLi opaci";				
			}
			else{
				this.className = "dizhiLi";
			}
			console.log(imgArr[this.index].className);
		}
		
		liArr[i].onclick = function(){
			for(var j=0;j<imgArr.length;j++){
				imgArr[j].className = "";
				liArr[j].className = "dizhiLi";
			}
			imgArr[this.index].className = "dui";
			this.className = "dizhiLi opaci";
		}
	}	
//	地址管理及默认地址的效果结束
	var label1= document.getElementById("label1");
	var formInp= document.getElementsByClassName("formInp")[0];
	console.log(label1);
	console.log(formInp);
	function dianjihanshu(){
//		var label1=document.getElementById("check3");
		if(label1 == after){
			formInp.style.display = "block";
		}else{
			formInp.style.display = "none";
		}
	}
        
//	付款方式的选择
	var site = document.getElementsByClassName("site");
	var scene = document.getElementsByClassName("scene");
	console.log(site);
	console.log(scene);
	for(var i=0;i<site.length;i++){
		site[i].index = i;
		site[i].onclick = function(){
			for(var j=0;j<scene.length;j++){
				scene[j].className = "scene";
			}
			scene[this.index].className = "iconfont icon-dian scene";
		}
	}
	var spanYuan = document.getElementsByClassName("spanYuan");
	for(var i=0;i<spanYuan.length;i++){
		spanYuan[i].index= i;
		spanYuan[i].onmouseover = function(){
			this.style.border = "1px solid #333";
			if(scene[this.index].className == "iconfont icon-dian scene"){
				this.style.border = "1px solid #b8b8b8";
			}
		}
		spanYuan[i].onmouseout = function(){
			this.style.border = "1px solid #b8b8b8";
		}
	}
	
//	****************************
//在线付款的li
	var way1 = document.getElementsByClassName("way1")[0];
//	货到付款的li
	var way = document.getElementsByClassName("way")[0];
//	送货上门后再付款的p标签
	var way2 = document.getElementsByClassName("way2")[0];
//	货到付款的圆点
	var ridio2 = document.getElementsByClassName("ridio2")[0];
//	在线付款的圆点
	var ridio1 = document.getElementsByClassName("ridio1")[0];
//	货到付款后面的两种选择
	var fuKuanWay = document.getElementsByClassName("fuKuanWay")[0];
	way1.onclick = function(){
		ridio1.className = "iconfont icon-dian ridio1";
		ridio2.className = "ridio1";
		way2.style.display = "block";
		this.style.border = "1px solid #7cbf13";
		this.style.background = "#fcfef9";
		way.style.border = "1px solid #d0d0d0";
		way.style.background = "#fff";
		fuKuanWay.style.display = "none";
	}
	way.onclick = function(){
		ridio2.className = "iconfont icon-dian ridio2";
		ridio1.className = "ridio1";
		way2.style.display = "none";
		this.style.border = "1px solid #7cbf13";
		this.style.background = "#fcfef9";
		way1.style.border = "1px solid #d0d0d0";
		way1.style.background = "#fff";
		fuKuanWay.style.display = "inline-block";
	}
	var payLi = document.getElementsByClassName("payLi");
	var rio = document.getElementsByClassName("rio");
	console.log(payLi);
		payLi[0].onmouseover = function(){
			this.style.border = "1px solid #7cbf13";
		}
		payLi[0].onmouseout = function(){
			this.style.border = "1px solid #d0d0d0";
			if(ridio1.className == "iconfont icon-dian ridio1"){
				this.style.border = "1px solid #7cbf13";
			}
		}
		
		payLi[1].onmouseover = function(){
			this.style.border = "1px solid #7cbf13";
		}
		payLi[1].onmouseout = function(){
			this.style.border = "1px solid #d0d0d0";
			if(ridio2.className == "iconfont icon-dian ridio2"){
				this.style.border = "1px solid #7cbf13";
			}
		}
//	装点的span的盒子	
	var ridioSpan1 = document.getElementsByClassName("ridioSpan1")[0];
	var ridioSpan2 = document.getElementsByClassName("ridioSpan2")[0];
		ridioSpan1.onmouseover = function(){
			this.style.border = "1px solid #333";
			if(ridio1.className == "iconfont icon-dian ridio1"){
				this.style.border = "1px solid #b8b8b8";
			}
		}
		ridioSpan1.onmouseout = function(){
			this.style.border = "1px solid #b8b8b8";
		}
		ridioSpan2.onmouseover = function(){
			this.style.border = "1px solid #333";
			if(ridio2.className == "iconfont icon-dian ridio2"){
				this.style.border = "1px solid #b8b8b8";
			}
		}
		ridioSpan2.onmouseout = function(){
			this.style.border = "1px solid #b8b8b8";
		}
		
//		发票信息部分
	var billWen = document.getElementsByClassName("billWen")[0];
	var em = billWen.getElementsByTagName("em")[0];
	var p = em.getElementsByTagName("p")[0];
	var img = em.getElementsByTagName("img")[0];
	em.onmouseover = function(){
		p.style.display = "block";
		img.style.display = "block";
	}
	em.onmouseout = function(){
		p.style.display = "none";
		img.style.display = "none";
	}
//	勾选发票信息
	var billWayBox = document.getElementsByClassName("billWayBox")[0];
	var openBill = document.getElementsByClassName("openBill")[0];
	var billgou = document.getElementsByClassName("billgou")[0];
	var iBiao = openBill.getElementsByTagName("i")[0];
	console.log(openBill);
	console.log(iBiao);
	console.log(billWayBox);
	openBill.onclick = function(){
		if(iBiao.className == "iconfont icon-gou1"){
			iBiao.className = "";
			billWayBox.style.display= "none";
		}
		else{
			iBiao.className = "iconfont icon-gou1";
			billWayBox.style.display= "block";
		}
	}
	billgou.onmouseover = function(){
		this.style.border = "1px solid #333";
		if(iBiao.className == "iconfont icon-gou1"){
			this.style.border = "1px solid #b8b8b8";
		}
	}
	billgou.onmouseout = function(){
		this.style.border = "1px solid #b8b8b8";
	}
	
//	选择 电子发票开始
	var billWay= document.getElementsByClassName("billWay")[0];
	var yB= billWay.getElementsByClassName("yuanBiao")[0];
	var yBI= yB.getElementsByTagName("i")[0];
	var dianZiBill= billWay.getElementsByClassName("dianZiBill")[0];
	var billTaiHead= document.getElementsByClassName("billTaiHead")[0];
	var resve = document.getElementById("resve");
	yB.onclick=dianZiBill.onclick = function(){
		if(yBI.className == "iconfont icon-dian"){
			yBI.className = "";
			billTaiHead.style.display= "none";
			resve.style.color = "#999";
			resve.style.background = "#d0d0d0";
			resve.style.cursor = "no-drop";
		}
		else{
			yBI.className = "iconfont icon-dian";
			billTaiHead.style.display= "block";
			resve.style.color = "#fff";
			resve.style.background = "#f10180";
			resve.style.cursor = "pointer";
		}
	}
	yB.onmouseover = function(){
		this.style.border = "1px solid #333";
		if(yBI.className == "iconfont icon-dian"){
			this.style.border = "1px solid #b8b8b8";
		}
	}
	yB.onmouseout = function(){
		this.style.border = "1px solid #b8b8b8";
	}
//勾选公司和个人开始
	var teShuBiao = document.getElementsByClassName("teShuBiao");
	var oo = document.getElementsByClassName("oo");
	var teInput = document.getElementsByClassName("teInput");
	var companyTitle = document.getElementsByClassName("companyTitle");
	var phoneTanK = document.getElementsByClassName("phoneTanK");
	console.log(companyTitle);
	for(var i=0;i<teShuBiao.length;i++){
		teShuBiao[i].index= i;
		 teShuBiao[i].onclick = function(){
			for(var j=0;j<oo.length;j++){
				oo[j].className = "oo";
				teInput[j].style.display = "none";
				phoneTanK[j].style.display = "none";
			}
			this.style.border = "1px solid #b8b8b8";
			oo[this.index].className = "iconfont icon-dian oo";
			teInput[this.index].style.display = "inline-block";
			// phoneTanK[this.index].style.display = "inline-block";

		}
	}
	for(var i=0;i<companyTitle.length;i++){
		companyTitle[i].index= i;
		 companyTitle[i].onclick = function(){
			for(var j=0;j<oo.length;j++){
				oo[j].className = "oo";
				teInput[j].style.display = "none";
				phoneTanK[j].style.display = "none";
			}
			teShuBiao[this.index].style.border = "1px solid #b8b8b8";
			oo[this.index].className = "iconfont icon-dian oo";
			teInput[this.index].style.display = "inline-block";
			// phoneTanK[this.index].style.display = "inline-block";
		}
	}
	
	for(var i=0;i<teShuBiao.length;i++){
		teShuBiao[i].index= i;
		teShuBiao[i].onmouseover = function(){
			this.style.border = "1px solid #333";
			if(oo[this.index].className == "iconfont icon-dian oo"){
				this.style.border = "1px solid #b8b8b8";
			}
		}
		teShuBiao[i].onmouseout = function(){
			this.style.border = "1px solid #b8b8b8";
		}
	}
//	其他服务部分的勾选
	var qiTa = document.getElementsByClassName("qiTa")[0];
	var qiTa1 = document.getElementsByClassName("qiTa1")[0];
	var qiTa2 = document.getElementsByClassName("qiTa2")[0];
	 qiTa2.onclick =qiTa.onclick = function(){
		if(qiTa1.className == "iconfont icon-gou1 qiTa1"){
			qiTa1.className = "";
		}
		else{
			qiTa1.className = "iconfont icon-gou1 qiTa1"
		}
	}
	qiTa.onmouseover = function(){
		this.style.border = "1px solid #333";
		if(qiTa1.className == "iconfont icon-gou1 qiTa1"){
			this.style.border = "1px solid #b8b8b8";
		}
	}
	qiTa.onmouseout = function(){
		this.style.border = "1px solid #b8b8b8";
	}
//勾选公司和个人结束
//	电子表格中验证信息
	var phoneTanK1= document.getElementsByClassName("phoneTanK");
	var neiRong= document.getElementsByClassName("neiRong");
	var phone1 = document.getElementById("phone1");
	console.log(phone1.style.background);
//手机号
	addEvent("phone1", function () {
            if(/^((13[0-9])|(15[^4,\D])|(18[0-9]))\d{8}$/.test(this.value)){
                this.style.border = "1px solid #b2b2b2";
                this.style.background = "#fff";
                this.style.color = "#333";
            }
            else if(/^\s*$/.test(this.value)){
            	this.style.background = "#ffe6e7";
                this.style.border = "1px solid #fca1a5";
                phoneTanK1[0].style.display = "block";
                
            }
            else{
                this.style.background = "#ffe6e7";
                this.style.border = "1px solid #fca1a5";
                phoneTanK1[0].style.display = "block";
                neiRong[0].innerText = "请输入11位手机号";
            }
        });
    addEvent1("phone1", function () {
        phoneTanK1[0].style.display = "none";
        
    });
    over("phone1", function () {
        this.style.border = "1px solid #666";
        if(phoneTanK1[0].style.display == "block"){
        		this.style.border = "1px solid #fca1a5";
        	}
    });
    out("phone1", function () {
//      console.log(phone1.style.border);
        if(this == document.activeElement){
        	this.style.border = "1px solid #666";
        	if(phoneTanK1[0].style.display =="block"){
        		this.style.border = "1px solid #fca1a5";
        	}
        }
        else if(phoneTanK1[0].style.display =="block"){
        		this.style.border = "1px solid #fca1a5";
        	}
        else{
        	this.style.border = "1px solid #b2b2b2";
        }      
    });
    //公司名
    addEvent("company1", function () {
            if(/^\s*$/.test(this.value)){
            	this.style.background = "#ffe6e7";
                this.style.border = "1px solid #fca1a5";
                phoneTanK1[1].style.display = "block";
                
            }
            else{
               this.style.border = "1px solid #b2b2b2";
                this.style.background = "#fff";
                this.style.color = "#333";
            }
        });
    addEvent1("company1", function () {
        phoneTanK1[1].style.display = "none";
        
    });
    over("company1", function () {
        this.style.border = "1px solid #666";
        if(phoneTanK1[1].style.display == "block"){
        		this.style.border = "1px solid #fca1a5";
        	}
    });
    out("company1", function () {
//      console.log(phone1.style.border);
        if(this == document.activeElement){
        	this.style.border = "1px solid #666";
        	if(phoneTanK1[1].style.display =="block"){
        		this.style.border = "1px solid #fca1a5";
        	}
        }
        else if(phoneTanK1[1].style.display =="block"){
        		this.style.border = "1px solid #fca1a5";
        	}
        else{
        	this.style.border = "1px solid #b2b2b2";
        }      
    });
    //选填
    addEvent("naShui", function () {
    	if(/(^[a-zA-Z0-9]{15}$)|(^[a-zA-Z0-9]{18}$)|(^[a-zA-Z0-9]{20}$)/.test(this.value)){
    		this.style.border = "1px solid #b2b2b2";
            this.style.background = "#fff";
            this.style.color = "#333";
    	}
    	else if(/^\s*$/.test(this.value)){
    		this.style.border = "1px solid #b2b2b2";
            this.style.background = "#fff";
            this.style.color = "#333";
    	}
    	else{
    		this.style.background = "#ffe6e7";
            this.style.border = "1px solid #fca1a5";
            phoneTanK1[2].style.display = "block";
    	}      
        });
    addEvent1("naShui", function () {
        phoneTanK1[2].style.display = "none";
        
    });
    over("naShui", function () {
        this.style.border = "1px solid #666";
        if(phoneTanK1[2].style.display == "block"){
        		this.style.border = "1px solid #fca1a5";
        	}
    });
    out("naShui", function () {
//      console.log(phone1.style.border);
        if(this == document.activeElement){
        	this.style.border = "1px solid #666";
        	if(phoneTanK1[2].style.display =="block"){
        		this.style.border = "1px solid #fca1a5";
        	}
        }
        else if(phoneTanK1[2].style.display =="block"){
        		this.style.border = "1px solid #fca1a5";
        	}
        else{
        	this.style.border = "1px solid #b2b2b2";
        }      
    });
    //手机号
	addEvent("phone2", function () {
            if(/^((13[0-9])|(15[^4,\D])|(18[0-9]))\d{8}$/.test(this.value)){
                this.style.border = "1px solid #b2b2b2";
                this.style.background = "#fff";
                this.style.color = "#333";
            }
            else if(/^\s*$/.test(this.value)){
            	this.style.background = "#ffe6e7";
                this.style.border = "1px solid #fca1a5";
                phoneTanK1[3].style.display = "block";
                
            }
            else{
                this.style.background = "#ffe6e7";
                this.style.border = "1px solid #fca1a5";
                phoneTanK1[3].style.display = "block";
                neiRong[3].innerText = "请输入11位手机号";
            }
        });
    addEvent1("phone2", function () {
        phoneTanK1[3].style.display = "none";
        
    });
    over("phone2", function () {
        this.style.border = "1px solid #666";
        if(phoneTanK1[3].style.display == "block"){
        		this.style.border = "1px solid #fca1a5";
        	}
    });
    out("phone2", function () {
//      console.log(phone1.style.border);
        if(this == document.activeElement){
        	this.style.border = "1px solid #666";
        	if(phoneTanK1[3].style.display =="block"){
        		this.style.border = "1px solid #fca1a5";
        	}
        }
        else if(phoneTanK1[3].style.display =="block"){
        		this.style.border = "1px solid #fca1a5";
        	}
        else{
        	this.style.border = "1px solid #b2b2b2";
        }      
    });	
//	选择电子发票结束
//	提交订单的时间
	var pp = document.getElementById("pp");
     var minute1 = 19;
     var second1 = 59;
     if(minute1 < 10) minute1 = "0" + minute1;
     if(second1 < 10) second1 = "0" + second1;
//   if(second < 10) second = "0" + second;
     var timer= setInterval(function() {
     	pp.innerHTML = "<span>"+minute1+"</span> ：<span>"+second1+"</span>";
         second1--;
         if(second1 == 00 && minute1 == 00) {
            // pp.innerHTML="sss";
            clearInterval(timer);
            minute1 = 00;
            second1 = 00;
//          return flase;
         }; //当分钟和秒钟都为00时，重新给值
         if(second1 == 00) {
             second1 = 59;
             minute1--;
             if(minute1 < 10) minute1 = "0" + minute1;
         }; //当秒钟为00时，秒数重新给值
         if(second1 < 10) second1 = "0" + second1;
         
     }, 1000);
//   clearInterval();

 //因为每次都要这样调用，所以很繁琐，我们通过封装实现代码
        function addEvent(str,fn){
            document.getElementById(str).onblur = fn;
        }
        function addEvent1(str,fn){
            document.getElementById(str).onkeyup = fn;
        }
        function over(str,fn){
            document.getElementById(str).onmouseover = fn;
        }
        function out(str,fn){
            document.getElementById(str).onmouseout = fn;
        }
        //nextElementSibling:返回当前元素在父元素的子节点的后一个节点
        function setClassName(aaa,txt){
            var span = aaa.nextElementSibling || this.nextSibling;
            span.className = txt;
        }
        function setInnerHTML(aaa,txt){
//            console.log(this);
            var span = aaa.nextElementSibling || this.nextSibling;
            span.innerHTML = txt;
        }
}
