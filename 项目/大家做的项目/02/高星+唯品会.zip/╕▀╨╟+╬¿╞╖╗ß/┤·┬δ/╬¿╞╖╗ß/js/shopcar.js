window.onload=function(){
	var vip = document.getElementById("vip");
	var jsVip = document.getElementById("jsVip");
	var ul1 = document.getElementsByClassName("ul1")[0];
	var ul1Li = ul1.getElementsByTagName("li")[2];
	var ul1LiI = ul1.getElementsByClassName("icon-kefu")[0];
	ul1Li.onmouseover=function(){
		this.style.color = "#333";
		ul1LiI.style.color = "#333";
	}
	ul1Li.onmouseout=function(){
		this.style.color = "#808080";
		ul1LiI.style.color = "#808080";
	}
	vip.onmouseover=function(){
		jsVip.style.display = "block";
	}
	vip.onmouseout=function(){
		jsVip.style.display = "none";
	}
	
//	结算倒计时开始
	var gouWucarKong = document.getElementById("gouWucarKong");
	var address=document.getElementsByClassName("address")[0];
	var jiesuanBox=document.getElementsByClassName("jiesuanBox")[0];	
	var title1 = document.getElementById("title1");
	var teMaiBox = document.getElementsByClassName("teMaiBox")[0];
//	*****************当倒计时结束后,精选特卖的效果开始**********
	
//*****************当倒计时结束后,精选特卖的效果结束**********
     var minute = 19;
     var second = 59;
     if(minute < 10) minute = "0" + minute;
//   if(second < 10) second = "0" + second;
     setInterval(function() {
     	title1.innerHTML = "<span>"+minute+"</span> ：<span>"+second+"</span>";
         second--;
         if(second == 00 && minute == 00) {
            // pp.innerHTML="sss";
            address.style.display = "none";
            jiesuanBox.style.display = "none";
            gouWucarKong.style.display = "block";
            title1.style.display = "none";
            jia.style.display = "none";
            jian.style.display = "none";
            num1.style.width = "77px";
            num1.style.borderRight = "1px solid #fff";
            num.style.border = "1px solid #fff";
            teMaiBox.style.marginTop = "30px";
            chaozuo.style.display = "none";
             return flase;
         }; //当分钟和秒钟都为00时，重新给值
         if(second == 0) {
             second = 59;
             minute--;
             if(minute < 10) minute = "0" + minute;
         }; //当秒钟为00时，秒数重新给值
         if(second < 10) second = "0" + second;
         
     }, 1000);
     
//结算时间	
	var pp = document.getElementById("pp");
     var minute1 = 19;
     var second1 = 59;
     if(minute < 10) minute = "0" + minute;
//   if(second < 10) second = "0" + second;
     setInterval(function() {
     	pp.innerHTML = "<span>"+minute1+"</span> ：<span>"+second1+"</span>";
         second1--;
         if(second1 == 00 && minute1 == 00) {
            // pp.innerHTML="sss";
            
            pp.style.display = "none";
             return flase;
         }; //当分钟和秒钟都为00时，重新给值
         if(second1 == 00) {
             second1 = 59;
             minute1--;
             if(minute1 < 10) minute1 = "0" + minute1;
         }; //当秒钟为00时，秒数重新给值
         if(second1 < 10) second1 = "0" + second1;
         
     }, 1000);
     
//   删除按钮开始
	var chaozuo = document.getElementsByClassName("chaozuo")[0];
	console.log(chaozuo);
	var sanchu = chaozuo.getElementsByTagName("p")[0];
	console.log(sanchu);
	var buySong= document.getElementsByClassName("buySong")[0];
	console.log(buySong);
	var daikong = document.getElementsByClassName("daiKong")[0];
	var zhongjian = document.getElementById("zhongjian");
	sanchu.onclick=function(){
		
			daikong.style.display="block";
			zhongjian.style.display="none";
			title1.style.display = "none";
	}
//	删除按钮结束
//加/减数量的效果开始
	var numBox = document.getElementById("numBox");
	var numSong = document.getElementById("numSong");
	var yes = numSong.getElementsByClassName("yes")[0];
	var no = numSong.getElementsByClassName("no")[0];
	var num = numBox.getElementsByClassName("num")[0];
	var jian = num.getElementsByClassName("jian")[0];
	var num1 = num.getElementsByClassName("num1")[0];
	var jia = num.getElementsByClassName("jia")[0];
	var w=Number(num1.innerText);
	console.log(typeof w);
//************增加数量,价钱改变的效果开始*************
	var danjia = document.getElementById("danjia");
	var xiaojiMoney = document.getElementById("xiaojiMoney");
	var gong1jian = document.getElementById("gong1jian");
	var gongMoney = document.getElementById("gongMoney");
	var noYunfei = document.getElementById("noYunfei");
	var yen1 = document.getElementById("yen1");
	var yen4= document.getElementById("yen4");
	var yen2= document.getElementById("yen2");
	var jianshu =document.getElementsByClassName("jianshu")[0];
//************增加数量,价钱改变的效果结束*************
	num.onmouseover=function(){
		this.style.boxShadow = "0px 0px 2px 0px #ebebeb";
	}
	num.onmouseout=function(){
		this.style.boxShadow = "none";
	}
	jian.onmouseover=function(){
		if(num1.innerText==="1"){
			this.style.cursor="no-drop";
		}
		else{
			this.style.cursor="pointer";
		}
	}
	jia.onmouseover=function(){
		if(num1.innerText==="1"){
			this.style.cursor="pointer";
		}
		else{
			this.style.cursor="no-drop";
		}
	}
//	加**********************
	jia.onclick=function(){
		if(Number(num1.innerText)==2){
			num1.innerText= Number(num1.innerText);
			
			
		}
		else{
			num1.innerText = Number(num1.innerText)+1;
			xiaojiMoney.innerText = Number(num1.innerText)*Number(danjia.innerText);
			gongMoney.innerText= Number(xiaojiMoney.innerText);
			noYunfei.innerText= Number(xiaojiMoney.innerText);
			gong1jian.innerText=Number(num1.innerText);
			yen2.innerText=Number(num1.innerText);
			yen1.innerText= Number(xiaojiMoney.innerText);
			yen4.innerText= Number(xiaojiMoney.innerText);
			jianshu.style.display = "block";
//			this.style.cursor="pointer";
			this.style.color = "#e7e6e6";
			this.style.cursor="no-drop";
		}
		
		jian.style.color = "#aaa";
		buySong.style.display = "block";
	}
//	减*********************
	jian.onclick=function(){
//		jian.style.color = "#e7e6e6";
		numSong.style.display = "block";
		if(Number(num1.innerText)==1){
			numSong.style.display = "none";
//			this.style.color = "#e7e6e6";
//			jia.style.color = "#aaa";
			
			
		}
		no.onclick = function(){
			num1.innerText= Number(num1.innerText);
			numSong.style.display = "none";
		}
		yes.onclick = function(){
			buySong.style.display = "none";
			jia.style.color = "#aaa";
			jian.style.color = "#e7e6e6";
			if(Number(num1.innerText)==1){						
				buySong.style.display = "none";
				numSong.style.display = "none";
			
			}
			else{			
				num1.innerText = Number(num1.innerText)-1;
				xiaojiMoney.innerText = Number(num1.innerText)*Number(danjia.innerText);
				gongMoney.innerText= Number(xiaojiMoney.innerText);
				noYunfei.innerText= Number(xiaojiMoney.innerText);
				gong1jian.innerText=Number(num1.innerText);
				yen2.innerText=	Number(num1.innerText);
				yen1.innerText= Number(xiaojiMoney.innerText);
				yen4.innerText= Number(xiaojiMoney.innerText);
				jianshu.style.display = "none";
				
			}
			numSong.style.display = "none";			
		}		
	}
//加/减数量的效果结束

	var yunfeiCha= document.getElementsByClassName("yunfeiCha")[0];
	var yunfeiCha1= document.getElementsByClassName("yunfeiCha")[1];
	console.log(yunfeiCha1);
	var chaKan= document.getElementsByClassName("chaKan")[0];
	var chaKan1= document.getElementsByClassName("chaKan1")[0];
	var yunfeiChaxx= document.getElementById("yunfeiChaxx");
	var biaoI= yunfeiCha.getElementsByTagName("i")[0];
	var biaoI1= yunfeiCha1.getElementsByTagName("i")[0];
	console.log(biaoI);
	console.log(biaoI1);
	yunfeiCha.onclick = function(){
		if(chaKan.style.display ==="none"){
			chaKan.style.display ="block";
			yunfeiChaxx.innerText="收起";
			biaoI.className = "iconfont icon-jiantou-copy";
		}
		else{
			chaKan.style.display ="none";
			yunfeiChaxx.innerText="查看";
			biaoI.className = "iconfont icon-jiantou-copy-copy";
		}		
	}
	
	yunfeiCha1.onclick = function(){
		if(chaKan1.style.display ==="none"){
			chaKan1.style.display ="block";
//			yunfeiChaxx.innerText="收起";
			biaoI1.className = "iconfont icon-jiantou-copy";
		}
		else{
			chaKan1.style.display ="none";
//			yunfeiChaxx.innerText="查看";
			biaoI1.className = "iconfont icon-jiantou-copy-copy";
		}		
	}

	var arrLeft = document.getElementById("left");
	var arrRight = document.getElementById("right");
	var innerImg= document.getElementsByClassName("innerImg")[0];
	console.log(arrLeft);
	var lis = innerImg.children;
//需求1：点击按钮，让图片显示下一张。
var target = 0;
//	arrLeft.onclick = function () {
//		target += 882;
//		arrRight.style.color = "#666";
//		if(target>=0){
//			target =0;
//			this.style.color = "#DBDADA";
////			this.style.background = "#fff";
//		}
//		animate(innerImg,target);
//	}
	var key = 0 ;//控制图片
	var square = 0;//控制指示器
	arrLeft.onclick = function(){
		// 6.4图片往右,图片索引减小,指示器索引减小
		arrRight.style.color = "#666";
		key--;
		square--;
		if(key<=0){
			key=0;
			innerImg.style.left = 0+"px";
		}
		//6.5让图片动起来
		animate(innerImg,-key*882);
		//6.6指示器范围
		square = square<0? 0 : square;
		//6.7指示器运动
		for(var j=0; j<lis2.length;j++){
				lis2[j].className="";
			}
			//4.9指示器下标 0--4
			lis2[square].className = "pink";
	}
	arrRight.onclick = function(){
		// 6.4图片往右,图片索引减小,指示器索引减小
		arrLeft.style.color = "#666";
		key++;
		square++;
		if(key>=2){
			key=2;
			innerImg.style.left = -2*882+"px";
			arrRight.style.color = "#DBDADA";
//			arrRight.style.color = "#DBDADA";
		}
		//6.5让图片动起来
		animate(innerImg,-key*882);
		//6.6指示器范围
		square = square>lis2.length-1? 2 : square;
		//6.7指示器运动
		for(var j=0; j<lis2.length;j++){
				lis2[j].className="";
			}
			//4.9指示器下标 0--4
			lis2[square].className = "pink";
	}
//	arrRight.onclick = function () {
////		target -= 882;
//		arrLeft.style.color = "#666";
////		arrLeft.style.background = "#a0a0a0";
////		if(target<= - (lis.length-1)*882){
////			target = -(lis.length-1)*882;
////			this.style.color = "#DBDADA";
////		}
//		for(var i=0;i<lis2.length;i++){
//			lis2.index=i;
//			target = -Number(this.index)*882;
//			animate(innerImg,target);
//			for(var j= 0;j<lis2.length;j++){
//				lis2[j].className = "";
//			}
//			lis[i].className = "pink";
//		}
//		
//	}

	arrLeft.onmouseover = function(){
		this.style.color = "#fff";
		this.style.background = "#a0a0a0";
		if(innerImg.style.left ==0+"px"){
			key=0;
//			innerImg.style.left = -2*882+"px";
			this.style.color = "#DBDADA";
			this.style.background = "#fff";			
		}
	}
	arrLeft.onmouseout = function(){
		this.style.color = "#666";
		this.style.background = "#fff";
		if(innerImg.style.left ==0+"px"){
			key=0;
			this.style.color = "#DBDADA";
			this.style.background = "#fff";
		}
	}
	arrRight.onmouseover = function(){
		this.style.color = "#fff";
		this.style.background = "#a0a0a0";
		if(innerImg.style.left ==-2*882+"px"){
			key=2;
			this.style.color = "#DBDADA";
			this.style.background = "#fff";
		}
	}
	arrRight.onmouseout = function(){
		this.style.color = "#666";
		this.style.background = "#fff";
		if(innerImg.style.left ==-2*882+"px"){
//			target = -(lis.length-1)*882;
			this.style.color = "#DBDADA";
			this.style.background = "#fff";
		}
	}
//需求2：指示器
	var zhishiqi= document.getElementsByClassName("zhishiqi")[0];
	var lis2 = zhishiqi.children;
	console.log(lis2);
	for(var i = 0;i<lis2.length;i++){
//		lis2[i].index=i;		
//		lis2[i].onclick=function(){
//			target = -Number(this.index)*882;
//			console.log(Number(this.index));
//			animate(innerImg,target);
//			for(var j= 0;j<lis2.length;j++){
//				lis2[j].className = "";
//			}
//			this.className = "pink";
//		}
	lis2[0].onclick=function(){
		arrLeft.style.color = "#DBDADA";
		arrLeft.style.background = "#fff";
		arrRight.style.color = "#666";
		arrRight.style.background = "#fff";
		this.className = "pink";
		lis2[1].className = "";
		lis2[2].className = "";
		target = 0;
		animate(innerImg,target);
	}
	lis2[1].onclick=function(){
		arrLeft.style.color = "#666";
		arrLeft.style.background = "#fff";
		arrRight.style.color = "#666";
		arrRight.style.background = "#fff";
		this.className = "pink";
		lis2[0].className = "";
		lis2[2].className = "";
		target = -1*882;
		animate(innerImg,target);
	}
	lis2[2].onclick=function(){
		arrLeft.style.color = "#666";
		arrLeft.style.background = "#fff";
		arrRight.style.color = "#DBDADA";
		arrRight.style.background = "#fff";
		this.className = "pink";
		lis2[1].className = "";
		lis2[0].className = "";
		target = -2*882;
		animate(innerImg,target);
	}
}
	
//	点击指示器的时候,箭头的变化
	for(var i = 0;i<lis2.length;i++){
	
	}
	
	function animate(obj,target) {
	clearInterval(obj.timer)

	var speed = obj.offsetLeft < target ? 15 : -15;

	obj.timer = setInterval(function () {
		var result = target - obj.offsetLeft;

		obj.style.left = obj.offsetLeft + speed + "px";
		console.log(speed);
		if(Math.abs(result) <= 10 ){
			clearInterval(obj.timer);
			obj.style.left = target + "px";
		}

	},4);
}

//点击找相似
	var likeds = document.getElementById("likeds");
	var liked = document.getElementById("liked");
	console.log(likeds);
	likeds.onclick = function(){
		
		if(liked.style.display==="none"){
			liked.style.display="block";
			this.value = "找相似 ∧";
		}
		else{
			liked.style.display="none";
			this.value = "找相似 ∨";
		}
	}

}
