//鼠标移上
function over(ele){
	ele.style.background='#fff';
	ele.style.height="30px";
	ele.style.border='1px solid #cdcdcd';
	ele.style.zIndex=40;
}
//鼠标移出
function out(yikai){
	yikai.style.background='#f5f5f5';		
	yikai.style.border='1px solid #f5f5f5';
	yikai.style.zIndex=0;
}

function showB(disB){
    disB.style.display = "block";
}
function showN(disN){
    disN.style.display = "none";
}
//缓动动画封装

function getOpacity(obj){
    if(getComputedStyle(obj,null)['opacity'])
    { 
        return getComputedStyle(obj,null)['opacity']; 
    }
    else
    {
        return obj.currentStyle['fileter'];
    }
}

function scroll() {  // 开始封装自己的scrollTop
    if(window.pageYOffset !== undefined) {  // ie9+ 高版本浏览器
        // 因为 window.pageYOffset 默认的是  0  所以这里需要判断
        return {
            left: window.pageXOffset,
            top: window.pageYOffset
        }
    }
    else if(document.compatMode === "CSS1Compat") {    // 标准浏览器   来判断有没有声明DTD
        return {
            left: document.documentElement.scrollLeft,
            top: document.documentElement.scrollTop
        }
    }
    return {   // 未声明 DTD
        left: document.body.scrollLeft,
        top: document.body.scrollTop
    }
}
