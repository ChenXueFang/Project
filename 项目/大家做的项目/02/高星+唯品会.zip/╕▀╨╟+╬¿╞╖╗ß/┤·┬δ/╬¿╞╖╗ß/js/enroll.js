window.onload=function(){
//	鼠标移动在input上border变色
	var inp5 = document.getElementsByClassName("inp5");
//	console.log(inp5);
//	for(var i=0;i<inp5.length;i++){
//		inp5[i].onmouseover=function(){
//			this.style.border="1px solid #666";
//		}
//		inp5[i].onmouseout=function(){
//			
//			this.style.border="1px solid #b2b2b2";
//	}
//		}
//	聚焦时的效果
	var inputBox = document.getElementById("inputBox");
	var p = inputBox.getElementsByTagName("p");
	var inp6 = document.getElementById("inp6");
	for(var i=0;i<inp5.length;i++){
		inp5[i].index=i;
		inp5[i].onfocus=function(){
			var val = this.value;
  			var len = val.length;
  			if(len==0){
  				this.style.border="1px solid #666";
				p[this.index].style.display="block";
				setClassName1(this,"");
  			}
  			else{
  				this.style.border="1px solid #666";
				p[this.index].style.display="none";
				setClassName1(this,"");
  			}
			
		}
//		inp5[i].onmouseout=function(){
//			this.style.border="1px solid #b2b2b2";
//		}
	}
	
	addEvent("inp1", function () {
            if(/^((13[0-9])|(15[^4,\D])|(18[0-9]))\d{8}$/.test(this.value)){            	
                setClassName1(this,"iconfont icon-gou2");
                setInnerHTML(this,"");
                this.style.border="1px solid #d2c2d2";
                inp6.style.border="1px solid #ffbee0";
                inp6.style.background="#fcedf2";
                inp6.style.color="#e0008c";
                inp6.style.cursor="pointer";
            }
            else if(/^\s*$/.test(this.value)){
                this.style.border="1px solid #f64a4a";
                p[this.index].style.display="block";
                setInnerHTML(this,"手机号不能为空");
                setClassName(this,"wrong");
                setClassName1(this,"iconfont icon-cuo1");
            }
            else{
            	this.style.border="1px solid #f64a4a";
                setInnerHTML(this,"请输入正确的手机号");
                p[this.index].style.display="block";
                setClassName(this,"wrong");
                setClassName1(this,"iconfont icon-cuo1");
            }
        });
	
//		输入验证码
		addEvent("inp2", function () {
            if(/^\d{6}$/.test(this.value)){            	
                setClassName1(this,"iconfont icon-gou2");
                setInnerHTML(this,"");
                this.style.border="1px solid #d2c2d2";
            }
            else{
            	this.style.border="1px solid #f64a4a";
                setInnerHTML(this,"请输入6位数字手机验证码");
                p[this.index].style.display="block";
                setClassName(this,"wrong");
                setClassName1(this,"iconfont icon-cuo1");
            }
        });
        
//      设置密码
		var inp3 = document.getElementById("inp3");
		var pMima = document.getElementById("pMima");
		var spanP = document.getElementById("spanP");
		var em3 = document.getElementById("em3");
		var divInp = document.getElementById("divInp");
		var csImg = spanP.getElementsByTagName("img")[0];
		var word=document.getElementById("word");
		console.log(csImg);
		inp3.onblur = function(){
			var val = this.value;
  			var len = val.length;
            if(/^\s*$/.test(this.value)){
                this.style.border="1px solid #f64a4a";
                pMima.innerText = "密码不能为空";
                spanP.style.display = "none";
                pMima.className = "wrong";
                em3.className = "iconfont icon-cuo1";
                em3.style.display = "block";
                pMima.style.color = "#f64a4a";               
       		}
            else{
            	if(/(^\d+$)|(^[a-zA-Z]+$)|(^[_]+$)/g.test(this.value)){
            	this.style.border="1px solid #f64a4a";
                pMima.className = "wrong";
                em3.className = "iconfont icon-cuo1";
                em3.style.display = "block";
                pMima.style.color = "#f64a4a";
            	}
            	else if(/(^(?!\d+$)(?![a-zA-Z]+$)[a-zA-Z\d]+$)|(^(?![a-zA-Z]+$)(?![_]+$)[a-zA-Z_]+$)|(^(?!\d+)(?![_]+$)[\d_]+$)/.test(this.value)){
            		this.style.border="1px solid #d2c2d2";
                	pMima.className = "wrong dakai";
                	em3.className = "iconfont icon-gou2";
                	em3.style.display = "block";
                	pMima.style.display="none";
            	}
            	else if(/^(?!\d+$)(?![a-zA-Z]+$)(?![_]+$)[\da-zA-Z_]+$/){
            		this.style.border="1px solid #d2c2d2";
                	pMima.className = "wrong dakai";
                	em3.className = "iconfont icon-gou2";
                	em3.style.display = "block";
                	pMima.style.display="none";
            	}
//          	else{
//          		this.style.border="1px solid #f64a4a";
//              	pMima.className = "wrong";
//              	em3.className = "iconfont icon-cuo1";
//              	em3.style.display = "block";
////              	pMima.style.color = "#f64a4a";
//          	}
            }
            
        }
//		dakai = document.getElementsByClassName("dakai")[0];
//      console.log(dakai);
        inp3.onfocus = function(){
        	var val = this.value;
  			var len = val.length;
  			if(len==0){
  				pMima.style.display="inline-block";
        		spanP.style.display = "none";
        		this.style.border="1px solid #666";
        		em3.style.display = "none";
        		pMima.style.color = "#666";
  			}
        	else{
        		this.style.border="1px solid #666";
        		em3.style.display = "none";
        		pMima.style.display="none";
        	}
//      	pMima.innerText = "";
        }
        
        inp3.onkeyup = function(){
        	var val = this.value;
  			var len = val.length;
  			if(len<6){
  			pMima.innerText = "请输入6-20位密码";
  			pMima.style.width = "232px";
        	spanP.style.width = "62px";
        	pMima.style.height = "25px";
			divInp.style.height = "75px";
			spanP.style.height = "25px";
        	pMima.style.color = "#666"; 
        	word.style.color = "#f64a4a";
        	word.innerText = "弱";
        	pMima.style.display="block";
        	csImg.src="../img/注册及登录/qiang (1).png";
  			}
			else{
				if(/(^\d+$)|(^[a-zA-Z]+$)|(^[_]+$)/g.test(this.value)){
					pMima.innerText = "密码过于简单，有被盗风险，建议您更改为复杂密码";
					pMima.style.width = "232px";
					pMima.style.height = "40px";
					divInp.style.height = "88px";
					pMima.style.lineHeight ="17px";
					pMima.style.color = "#666";
					spanP.style.height = "40px";
					spanP.style.float = "left";
					pMima.style.float = "left";
					word.style.color = "#f64a4a";
					pMima.style.display="block";
					word.innerText = "弱";
					csImg.src="../img/注册及登录/qiang (1).png";
					
				}
				else if(/(^(?!\d+$)(?![a-zA-Z]+$)[a-zA-Z\d]+$)|(^(?![a-zA-Z]+$)(?![_]+$)[a-zA-Z_]+$)|(^(?!\d+)(?![_]+$)[\d_]+$)/.test(this.value)){
					if(len>=12){
						pMima.innerText = "你的密码很安全";
						pMima.style.height = "25px";
						divInp.style.height = "75px";
						pMima.style.color = "#666";
						spanP.style.height = "25px";
						pMima.style.display="block";
						csImg.src="../img/注册及登录/qiang (3).png";
						word.innerText = "强";
						word.style.color = "#00c500";
					}
					else{
						pMima.innerText = "密码安全强度适中";
						pMima.style.height = "25px";
						divInp.style.height = "75px";
						pMima.style.color = "#666";
						spanP.style.height = "25px";
						pMima.style.display="block";
						csImg.src="../img/注册及登录/qiang (2).png";
						word.innerText = "中";
						word.style.color = "#ffa200";
					}					
				}
				else if(/^(?!\d+$)(?![a-zA-Z]+$)(?![_]+$)[\da-zA-Z_]+$/){
					if(len>=10){
						pMima.innerText = "你的密码很安全";
						pMima.style.height = "25px";
						divInp.style.height = "75px";
						spanP.style.height = "25px";
						pMima.style.color = "#666";
						pMima.style.display="block";
						csImg.src="../img/注册及登录/qiang (3).png";
						word.innerText = "强";
						word.style.color = "#00c500";
					}
					else{
						pMima.innerText = "密码安全强度适中";
						pMima.style.height = "25px";
						divInp.style.height = "75px";
						spanP.style.height = "25px";
						pMima.style.color = "#666";
						pMima.style.display="block";
						csImg.src="../img/注册及登录/qiang (2).png";
						word.innerText = "中";
						word.style.color = "#ffa200";
					}					
				}
				else{
					pMima.innerText = "密码中包含非法字符";
				}
				
			}
        	spanP.style.display="inline-block";	       	
        }
        
//	确认密码
		var inp4 = document.getElementById("inp4");
//		var inp3Text = inp3.value;
//		console.log(inp3Text);
		addEvent('inp4',function(){
			if(/^\s*$/.test(this.value)){
				this.style.border="1px solid #f64a4a";
                p[this.index].style.display="block";
                setInnerHTML(this,"请输入确认密码");
                setClassName(this,"wrong");
                setClassName1(this,"iconfont icon-cuo1");
		}
		else if(this.value==inp3.value){
			setClassName1(this,"iconfont icon-gou2");
//          setInnerHTML(this,"");
            this.style.border="1px solid #d2c2d2";
			setInnerHTML(this,"");
		}
		else{
			this.style.border="1px solid #f64a4a";
                p[this.index].style.display="block";
                setInnerHTML(this,"两次输入的密码不一致，请重试");
                setClassName(this,"wrong");
                setClassName1(this,"iconfont icon-cuo1");
		}
		});
		
	
		function addEvent(str,fn){
            document.getElementById(str).onblur = fn;
        }
        //nextElementSibling:返回当前元素在父元素的子节点的后一个节点
        function setClassName(aaa,txt){
            var span = aaa.nextElementSibling || this.nextSibling;
            span.className = txt;
        }
        function setInnerHTML(aaa,txt){
//            console.log(this);
            var span = aaa.nextElementSibling || this.nextSibling;
            span.innerHTML = txt;
        }
        function setClassName1(aaa,txt){
            var em = aaa.previousElementSibling || this.previousSibling;
            em.className = txt;
        }
       
}
