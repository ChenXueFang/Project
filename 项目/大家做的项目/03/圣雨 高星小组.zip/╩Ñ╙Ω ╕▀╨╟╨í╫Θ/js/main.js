$(function () {

    'use strict';


    var gcitypicker1 = $('#city-picker1');

    gcitypicker1.citypicker();

    var gcitypicker2 = $('#city-picker2');

    gcitypicker2.citypicker({
        province: '江苏省',
        city: '常州市',
        district: '溧阳市'
    });

    var gcitypicker3 = $('#city-picker3');

    $('#reset').click(function () {
        gcitypicker3.citypicker('reset');
    });

    $('#destroy').click(function () {
        gcitypicker3.citypicker('destroy');
    });
    //
    //$('#distpicker1').distpicker();
    //
    //$('#distpicker2').distpicker({
    //  province: '---- 所在省 ----',
    //  city: '---- 所在市 ----',
    //  district: '---- 所在区 ----'
    //});
    //
    //$('#distpicker3').distpicker({
    //  province: '浙江省',
    //  city: '杭州市',
    //  district: '西湖区'
    //});
    //
    //$('#distpicker4').distpicker({
    //  placeholder: false
    //});
    //
    //$('#distpicker5').distpicker({
    //  autoSelect: false
    //});

});
