$(function(){
	
	var jQLi=$(".cemian li");
	for(var i=0; i<jQLi.length;i++){
	 		if(i%2==0){
	 			//偶数行
	 			jQLi[i].style.backgroundColor = "#333";
	 		}else{
	 			//奇数行
	 			jQLi.get(i).style.backgroundColor = "#ccc";
	 		}
	 	}
	$(".cemian li").mouseenter(function(){
		$(this).children("p").show()
	})
	$(".cemian li").mouseleave(function(){
		$(this).children("p").hide()
	})
	$("ul").children("li").eq(1).click(function(){
		$(".offical").show()
	})
	$(".offical_l").children("b").click(function(){
		$(".offical").hide()
	})
	
	
	
	$(".banners_b li").click(function(){
		$(this).addClass("lei").siblings("li").removeClass("lei");
	})
	$(".banners_b .down,.two").click(function(){
	    $(".min").show()
	    $(".max").hide()
	    $(".up").css({"opacity":1})
	    $(".down").css({"opacity":0})
	})
	$(".banners_b .up,.one").click(function(){
	    $(".max").show()
	    $(".min").hide()
	    $(".down").css({"opacity":1})
	    $(".up").css({"opacity":0})
	})
	
//	鼠标移入字上升
	$(".uls>li").mouseenter(function(){
		$(this).children(".zi").children(".yi").slideDown()
		var jieguo = {
         		"top":100
         	}
		$(this).children(".zi").animate(jieguo,1000)
	})
	
	
	$(".uls>li").mouseleave(function(){
		$(this).children(".zi").children(".yi").hide()
		var jieguo = {
         		"top":180
         	}
		$(this).children(".zi").animate(jieguo,500)
	})
})

$(function(){
	$(".qs_left").mouseenter(function(){
		$(this).animate({"background-size":"700px"},1000);
		$(this).children(".mengqs").animate({"opacity":0.5});
		//	白色框线
		$(".kuang>p:nth-child(1)").animate({"width":600});		
		$(".kuang>p:nth-child(2)").delay(300).animate({"height":200});
		$(".kuang>p:nth-child(3)").delay(600).animate({"width":600});
		$(".kuang>p:nth-child(4)").delay(900).animate({"height":200});
		
	});
	$(".qs_left").mouseleave(function(){
		$(this).delay(1200).animate({"background-size":"680px"},1000);
		$(this).children(".mengqs").delay(1200).animate({"opacity":0});
		//	白色框线
		$(".kuang>p:nth-child(1)").delay(900).animate({"width":0});		
		$(".kuang>p:nth-child(2)").delay(600).animate({"height":0});
		$(".kuang>p:nth-child(3)").delay(300).animate({"width":0});
		$(".kuang>p:nth-child(4)").animate({"height":0});
	})
	
})