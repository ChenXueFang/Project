﻿$(function () {
    //拖动验证
    $(".inner").mousedown(function (e) {
        var dx, os = $(".inner").offset(), _differ = $(".outer").width() - $(".inner").width();
        $(document).mousemove(function (e) {
            dx = e.pageX - os.left;
            if (dx < 0) {
                dx = 0;
            } else if (dx > _differ) {
                dx = _differ;
            }
            $(".filter-box").css('width', dx);
            $(".inner").css("left", dx);
        });
        $(document).mouseup(function (e) {
            $(document).off('mousemove');
            $(document).off('mouseup');
            dx = e.pageX - os.left;
            if (dx < _differ) {
                 
                SlideCheckFail();
            } else if (dx >= _differ) { 
                SlideCheckSuccess(_differ); 
            }

        })
    })
    
    $("input[type=button]").click(function () {
        SlideCheckFail();
    });
    
});
//初始验证
function SlideCheckFail() {
    $(".outer").removeClass("act");
    $(".inner").css("left", 0);
    $(".inner").html("&gt;&gt;");
    $(".filter-box").css('width', 0);
    $(".outer>span").html("按住滑块，拖拽到最右边");

    $("#CaptchaID").val("0");
    $(".outer span").addClass("txtRoll");
}
//验证成功
function SlideCheckSuccess(dx) {
    $(".outer").addClass("act");
    $(".outer>span").html("验证通过！");
    $(".inner").html('&radic;');
    $(".inner").css("left", dx);
    $(".filter-box").css('width', dx);

    $("#CaptchaID").val("1");
    $(".outer span").removeClass("txtRoll");
}

// 登录及注册的切换
$(function(){
	$(".gDlStartUl>li").click(function(){
		$(this).css({"color":"#fff","border-bottom":"2px solid #1161ee"});
		$(this).siblings().css({"color":"#6a6f8c","border-bottom":"2px solid transparent"});
	});
//	注册验证
	
$("#commentForm").validate({
    rules: {
      firstname: "required",
      lastname: "required",
      username: {
        required: true,
        minlength: 2
      },
      password: {
        required: true,
        minlength: 5
      },
      confirm_password: {
        required: true,
        minlength: 5,
        equalTo: "#password"
      },
      email: {
        required: true,
        email: true
      },
      topic: {
        required: "#newsletter:checked",
        minlength: 2
      },
      agree: "required"
    },
    messages: {
      firstname: "请输入您的名字",
      lastname: "请输入您的姓氏",
      username: {
        required: "请输入用户名",
        minlength: "用户名必需由两个字母组成"
      },
      password: {
        required: "请输入密码",
        minlength: "密码长度不能小于 5 个字母"
      },
      confirm_password: {
        required: "请输入密码",
        minlength: "密码长度不能小于 5 个字母",
        equalTo: "两次密码输入不一致"
      },
      email: "请输入一个正确的邮箱",
      agree: "请接受我们的声明",
      topic: "请选择两个主题"
     }
    });
    
//翻转切换登录和注册  
$(".gDlStartUl>li:nth-child(1)").click(function(){  
        $(".gDlNow").attr("id","");  
        $(".gZhuche").attr("id","gDlNow");  
}); 
$(".gDlStartUl>li:nth-child(2)").click(function(){ 
        $(".gDlNow").attr("id","gDlNow");  
        $(".gZhuche").attr("id","gZhuche");  
});  
//入口函数的尾部	
});
