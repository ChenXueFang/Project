

$(document).ready(function(){
//		获取提交按钮
//console.log($("#firstname")[0].value.length);
	$('.submit').click(function(en){
//		console.log(222);
	
		if ($("#firstname")[0].value.length==0) {
			$('.firNameSon').show();
			$(this).attr("type","button");
			
		} 
		else if($("#firstname")[0].value.length>0){
			$('.firNameSon').hide();
			if($("#phone")[0].value.length==0){
			$('.phoneSon').show();
			$(this).attr("type","button");
			}
			else if($("#phone")[0].value.length>0){
				$('.phoneSon').hide();
				 if($("#email")[0].value.length==0){
					$('.EmailSon').show();
				}
				 else if($("#phone")[0].value.length>0){
				 	$('.EmailSon').hide();
				 	 if($(".textArea")[0].value.length==0){
					$('.concenTSon').show();
					}
				 	 else if($(".textArea")[0].value.length>0){
				 	 	$('.concenTSon').hide();
				 	 	$('.submiTson').fadeIn();
				 	 	$(this).attr("type","button");
				 	 	$('.submit').click(function(){
				 	 		$('.submiTson').hide();
				 	 		$('.pContent').fadeIn();
				 	 		console.log(211);
				 	 	  setInterval(function(){
				 	 			$('.pContent').hide();				 	 
				 	 			console.log("10s");
				 	 		},10000)				 	 		
				 	 	})
				 	 }
				 }
			}
			
		}	
	})	
})
  
  
	



