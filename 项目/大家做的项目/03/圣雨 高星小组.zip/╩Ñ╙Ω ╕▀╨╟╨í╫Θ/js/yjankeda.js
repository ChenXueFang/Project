$(function() {
	$(".gengduo>a>b").mouseenter(function() {
		$("ul.yjtan").show();
	})
	$("ul.yjtan").mouseleave(function() {
			$(this).hide();
		})
//	安可达点击切换
$("yjsearchBbox>ul li:eq(1)").click(function(){
	$(this).addClass("yjAgoda");
})
		//	日历插件
	$("#li1").click(function() {
		WdatePicker({
			dateFmt: 'yyyy年MM月dd日',
			//			doubleCalendar: true,
			//			isShowWeek: true
		})
	})
	$("#li2").click(function() {
			WdatePicker({
				dateFmt: 'yyyy年MM月dd日',

			})
		})
		//	点击弹出框
	$("li.yjKefang").click(function() {
		$("#yjSelectBox").show();
	})
	$("body").click(function(e) {
			if($(e.target).attr('class') != 'yjKefang') {
				$('#yjSelectBox').css('display', 'none');
			}
		})
		//	$('body').click(function(e) {
		//			if ($(e.target).attr('class') != 'yjgda') {
		//				$('.gdacon').css('display', 'none');
		//			}
		//		})
	$("#yjSelectBox>ul").click(function() {
			$(this).css("background-color", "#fff").siblings("ul").css("background-color", "#F2F2F2");
			$("#yjSelectBox").fadeOut();
		})
		//	滑动轮播
	var num = 1;
	$(".yjtuPianKuang .yjLL").click(function() {
		if(num > 4) {
			num = 1;
		}
		$(".yjtuPianKuang ul").css({
			'margin-left': -265 * num + 'px'
		})
		num++;
	})
	$(".yjtuPianKuang .yjRR").click(function() {
		if(num < 4) {
			num = 1;
		}
		$(".yjtuPianKuang ul").css({
			'margin-left': -265 * num + 'px'
		})
		num--;
	})
	$(".yjsearchBoxright>p").click(function() {
		$(this).addClass("active").siblings().removeClass("active");
		//			$(".yjsearchBoxright>div.nav").eq(0).addClass("tab1");
		//			$(".yjsearchBoxright>div.nav").eq(1).addClass("tab1");
		$(".yjsearchBoxright>div.nav").eq($(this).index()).addClass("tab1").siblings("div").removeClass("tab1");
	})

	//	$(".yjsearchBoxright p:eq(0)").click(function(){
	//		$('.yjlunBoBox:eq(0)').show();
	//		$('.yjlunBoBox:eq(1)').hide();
	////		console.log('111')
	//	})
	//	$(".yjsearchBoxright p:eq(1)").click(function(){
	//		$('.yjlunBoBox:eq(0)').hide();
	//		$('.yjlunBoBox:eq(1)').show();
	//		
	//	})
	
	$("#yjSelectBox>ul:nth-child(2)").click(function(){
		$("#numPeople").html(1);
	})
	$("#yjSelectBox>ul:nth-child(3)").click(function(){
		$("#numPeople").html(2);
	})
	
})