$(function(){
//banner轮播开始
	var count = 0;
	var $li = $("#slider>ul>li");
	$(".next").click(function(){
		count++;				
		if(count == $li.length){
			count =0;
		}
		$li.eq(count).fadeIn().siblings().fadeOut();
		$(".slider_icon i").eq(count).addClass("btn_act").siblings().removeClass('btn_act');
		console.log(count);
	});
	$(".prve").click(function(){
		count--;
		if(count == -1){
			count = $li.length-1;
		}
		console.log(count);
		$li.eq(count).fadeIn().siblings().fadeOut();
		$(".slider_icon i").eq(count).addClass("btn_act").siblings().removeClass('btn_act');
	});
	$(".slider_icon i").click(function(){
		$(this).addClass('btn_act').siblings().removeClass("btn_act");
		$li.eq($(this).index()).fadeIn().siblings().fadeOut();
		count = $(this).index();
	});
//banner轮播结束	
	
//展厅图片滑出		
$(".h_zt_pics>ul>li").mouseenter(function(){
	$(this).children("p").addClass("h_zt_bottom").siblings().children("p").removeClass("h_zt_bottom");
	$(this).children("#h_slide").slideDown().siblings().children("#h_slide").slideUp();
	$(this).children(".h_ztimg_box").animate({"background-size":"358px"})
})	
$(".h_zt_pics>ul>li").mouseleave(function(){
	$(this).children("p").removeClass("h_zt_bottom").siblings().children("p").removeClass("h_zt_bottom");
    $(this).children("#h_slide").slideUp().siblings().children("#h_slide").slideUp();
    $(this).children(".h_ztimg_box").animate({"background-size":"338px"})
})

$('.h_zt_ltlt>ul>li').mouseenter(function()  {
            var i = $(this).index();//控制下标
            $(this).children("i").addClass('h_zt_circle').siblings().children("i").removeClass('h_zt_circle');
});
$('.h_zt_ltlt>ul>li').mouseleave(function()  {
            var i = $(this).index();//控制下标
            $(this).children("i").removeClass('h_zt_circle').siblings().children("i").removeClass('h_zt_circle');
});



//数字图片
$(".h_num_picBox>.h_number1").mouseenter(function(){
	$(this).find(".h_numword").fadeIn()
	$(this).siblings().find(".h_numword").fadeOut();
	$(this).animate({"background-size":"280px"})
})	
$(".h_num_picBox>li.h_number1").mouseleave(function(){
	$(this).find(".h_numword").fadeOut().siblings().find(".h_numword").fadeOut();
	$(this).animate({"background-size":"270px"})
})


$(".h_num_picBox>.h_number2").mouseenter(function(){
	$(this).find(".h_numword2").fadeIn()
	$(this).siblings().find(".h_numword2").fadeOut();
	$(this).animate({"background-size":"550px"})
})	
$(".h_num_picBox>li.h_number2").mouseleave(function(){
	$(this).find(".h_numword2").fadeOut().siblings().find(".h_numword2").fadeOut();
	$(this).animate({"background-size":"540px"})
})
//服务客户
 $('.hf_kehu li').mouseenter(function()  {
            var i = $(this).index();//控制下标
            $(this).addClass('h_kh_on').siblings().removeClass('h_kh_on');
            $(this).children("img").addClass('h_kh_small').siblings().removeClass('h_kh_small');
        });

});