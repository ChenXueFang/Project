$(function() {
				$('#scrollpage').multiscroll({
					verticalCentered: false
				});
				var $btn3l = $('.btn3l');
				$btn3l.on('click', function() {
					$('.ms-right').find('.ms-section3').toggleClass('turnOn');
					
					return false;
				});

				$('.btn42').on('click', function() {
					$('.ms-left').find('.ms-section4').toggleClass('down');
					
					return false;
				});			//页面加载时的 Loading 效果
			
			});
$(window).load(function() {
				window.setTimeout(function() {
					$('body').removeClass('loading');
				}, 2000);
			});

