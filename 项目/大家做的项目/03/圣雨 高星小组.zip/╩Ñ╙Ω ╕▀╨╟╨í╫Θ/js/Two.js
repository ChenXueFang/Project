
//var jq11  = jQuery.noConflict(true);
//  jq11(function(){
//  	console.log(jq11.fn.jquery);
	$(document).ready(function(){

		$(".sidebarBox ul li").eq(0).click(function(){
//			console.log(111);
			
			$(this).children('p').toggle();
			
		})

		$(".sidebarBox ul li").eq(2).click(function(){		
			$(".iconImg").show();
			
		})

		$(".iconImgSpan").click(function(){
			
//			$(".iconImg").css({"display":"none"});
			$(this).parent().parent('.iconImg').fadeOut(function(){
				console.log(1222);
			});
			
		});

})