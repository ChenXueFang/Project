$(function(){
	//黑色圆圈背景图变化
	var move_xia={
			"top":90,
			"left":90,
	}
	var move_zhong={
			"top":18,
			"left":23,
		}
	var move_shang={
			"top":-50,
			"left":-50,
		}
	$(".hei_tu").mouseenter(function(){
		$(this).children(".hei_move").children("b").animate(move_zhong,1000);
		$(this).children(".hei_move").children("a").animate(move_shang,1000);
		
	})
	$(".hei_tu").mouseleave(function(){		
		$(this).children(".hei_move").children("a").animate(move_zhong,1000);
		$(this).children(".hei_move").children("b").animate(move_xia,1000);
		
	})
	//	花瓣效果
	$(".hei_tu>.lz_hua").mouseenter(function(){
		$(this).snowfall('clear');
     	$(this).snowfall({
            image: "../img/huaban.png",
            flakeCount:30,
            minSize: 5,//花瓣大小
            maxSize: 22
        });
	})
	$(".hei_tu>.lz_hua").mouseleave(function(){
		$(this).snowfall('clear');
	    $(this).snowfall({
	        image: "",
	        flakeCount:0,
	        minSize: 0,//花瓣大小
	        maxSize: 0
	    });
	})
		//固定条
		$("#lz_phone").mouseenter(function(){
			$("#lz_dianhua").show();
		})
		$("#lz_phone").mouseleave(function(){
			$("#lz_dianhua").hide();
		})
				
    	//nav弹出
		$("#lz_nav>ul>li").mouseenter(function(){
			$(this).children(".lz_navHide").show();
		})
		$("#lz_nav>ul>li").mouseleave(function(){
			$(this).children(".lz_navHide").hide();
		})
//		文字跳动
  		$('.autoText').beatText({isAuth:true,beatHeight:"3em",isRotate:false});
  		$('.rotateText').beatText({isAuth:false,isRotate:true});
  		$('.autoRotateText').beatText({isAuth:true,upTime:700,downTime:700,beatHeight:"3em",isRotate:true});
	
})
