$(document).ready(function() {
//	banner轮播图
    var length, currentIndex = 0,
        interval, hasStarted = false,
        t = 3000;
    length = $('.c_slider-panel').length;
    $('.c_slider-panel:not(:first)').hide();
    $('.c_slider-item:first').addClass('c_slider-item-selected');
//  $('.c_slider-page').hide();
    $('.c_slider-panel, .c_slider-pre, .c_slider-next').hover(function() {
        stop();
        $('.c_slider-page').show()
    }, function() {
//      $('.c_slider-page').hide();
        start()
    });
    $('.c_slider-item').hover(function(e) {
        stop();
        var preIndex = $(".c_slider-item").filter(".c_slider-item-selected").index();
        currentIndex = $(this).index();
        play(preIndex, currentIndex)
    }, function() {
        start()
    });
    $('.c_slider-pre').unbind('click');
    $('.c_slider-pre').bind('click', function() {
        pre()
    });
    $('.c_slider-next').unbind('click');
    $('.c_slider-next').bind('click', function() {
        next()
    });

    function pre() {
        var preIndex = currentIndex;
        currentIndex = (--currentIndex + length) % length;
        play(preIndex, currentIndex)
    }

    function next() {
        var preIndex = currentIndex;
        currentIndex = ++currentIndex % length;
        play(preIndex, currentIndex)
    }

    function play(preIndex, currentIndex) {
        $('.c_slider-panel').eq(preIndex).fadeOut(962).parent().children().eq(currentIndex).fadeIn(1000);
        $('.c_slider-item').removeClass('c_slider-item-selected');
        $('.c_slider-item').eq(currentIndex).addClass('c_slider-item-selected')
    }

    function start() {
        if (!hasStarted) {
            hasStarted = true;
            interval = setInterval(next, t)
        }
    }

    function stop() {
        clearInterval(interval);
        hasStarted = false
    }
    start()
    
    //产品展示轮播图
    
//  $(".conc_Box").()
 			var nowimg=0;
            var timer=null;
            // 克隆第一张图片，并且放到最后
//          $("#c_BoxUl>ul>li:first").clone().appendTo('#c_BoxUl')
            // 右按钮业务
            $("#btnr").click(rightFunc);
                function rightFunc(){
                if(nowimg<4){
                    nowimg++
                    $("#c_BoxUl").animate({"left":nowimg*-270},1000)
                }else{
                    nowimg=0
                    $("#c_BoxUl").animate({"left":5*-270},1000,function(){
                        $("#c_BoxUl").css("left",0)

                    })
                }
//              $(".circle span").eq(nowimg).addClass('current').siblings().removeClass('current')

            }
            // 左按钮业务
            $("#btnl").click(function(){
                if(nowimg>0){
                    nowimg--
                    $("#c_BoxUl").animate({"left":nowimg*-270},1000)
                }else{
                    nowimg=4
                    $("#c_BoxUl").css({"left":5*-270},1000)
                    $("#c_BoxUl").animate({"left":nowimg*-270},1000)
                }
//              $(".circle span").eq(nowimg).addClass('current').siblings().removeClass('current')
            })
            // 小圆点业务
//          $(".circle span").click(function(){
//               nowimg=$(this).index()
//         $(".circle span").eq(nowimg).addClass('current').siblings().removeClass('current')
//               $("#c_BoxUl").animate({"left":nowimg*-270}, 1000)
//          });

            // 自动轮播

            timer=setInterval(rightFunc,3000)

            $("#c_BoxUl").mouseenter(function(){
                clearInterval(timer)
            })
            $("#c_BoxUl").mouseout(function(){
                clearInterval(timer)
                timer=setInterval(rightFunc,3000)
            });
            $("#btnl").mouseenter(function(){
                clearInterval(timer);
                console.log("222222")
            })
            $("#btnr").mouseenter(function(){
                clearInterval(timer);
                console.log("3333")
            })
            
//  产品摩索部分        
	$(".gMosoUl>li").mouseenter(function(){
		$(this).css({"background":"#300"})
		$(this).children("p").animate({"opacity":0.5});
	})
	$(".gMosoUl>li").mouseleave(function(){
		$(this).css({"background":"#fff"});
		$(this).children("p").animate({"opacity":0});
	})
            
//  更多案列参考
	$(".gCase").mouseenter(function(){
		$(this).animate({"width":245})
	})
	$(".gCase").mouseleave(function(){
		$(this).animate({"width":205})
	});

	   
});
//轮播
$(function(){
	$('.gbotImg ul li').click(function(){
        var int=$(this).index();
        $('.gactiveSmallimg').animate({left:(int-3)*-962-2886},"slow");
    });
    var list=$('.gbotImg ul li').length-3;
    $('#gright').click(function(){
//      next(list)
        console.log(next(list));
    })
    $('#gleft').click(function(){
//      prev(list)
        console.log(prev(list));
    });

    //�Զ����� 2�벥��һ�� ����ѭ��
    var timer='';
    var num=0;
    function gBo(){
    	num++;
        if(num>parseFloat(list)-1){
            num=0;
            $('.gactiveSmallimg').animate({left:num*-962-2886},"slow");
            $('#gbotUl').animate({left:num*-212},"slow");
        }else{
            $('.gactiveSmallimg').animate({left:num*-962-2886},"slow");
            $('#gbotUl').animate({left:num*-212},"slow");
        }
    }
    timer=setInterval(gBo,2000);
    
    $(".gCaseLunBoall").mouseenter(function(){
                clearInterval(timer)
                console.log("45");
    });
    $(".gCaseLunBoall").mouseleave(function(){
                timer=setInterval(gBo,2000);
                console.log("5");
    });
//轮播封装的两个函数
   var index=0;
// var index2 = index-1;
function next(list){
    if(index<list-1){
        index++;
        $('.gactiveSmallimg').animate({left:index*-962-2886},"slow");
        $('#gbotUl').animate({left:index*-212},"slow");
    }else{
        index=0;
        $('.gactiveSmallimg').animate({left:index*-962-2886},"slow");
        $('#gbotUl').animate({left:index*-212},"slow");
    }
}
function prev(list){
    index--;
    if(index<0){
        index=list-1;
        $('.gactiveSmallimg').animate({left:index*-962-2886},"slow");
        $('#gbotUl').animate({left:index*-212},"slow");
    }else{
        $('.gactiveSmallimg').animate({left:index*-962-2886},"slow");
        $('#gbotUl').animate({left:index*-212},"slow");
    }
} 



//品牌翻转
var turn = function(target,time,opts){
	target.find('a').hover(function(){
		$(this).find('.gZminfo').stop().animate(opts[0],time,function(){
			$(this).hide().next().show();
			$(this).next().animate(opts[1],time);
		});
	},function(){
		$(this).find('.ginfo').animate(opts[0],time,function(){
			$(this).hide().prev().show();
			$(this).prev().animate(opts[1],time);
		});
	});
}
//var verticalOpts = [{'width':0},{'width':'180px'}];
//turn($('#vertical'),100,verticalOpts);
var horizontalOpts = [{'height':0,'top':'143px'},{'height':'287px','top':0}];
turn($('#horizontal'),200,horizontalOpts);
//入口函数    
});  
//====================================================================
	//产品展示hover块
	$(function(){
		$("#c_BoxUl>ul>li").mouseenter(function(){
			$(this).children().children(".c_pro_hover").show();
		})
		$("#c_BoxUl>ul>li").mouseleave(function(){
			$(this).children().children(".c_pro_hover").hide();
		})
	})
