$(document).ready(function(){
    //购物详情走边的js效果开始
    //鼠标放到li上
    $(".detailLeft_b>ul>li").mouseenter(function(){
    	$(this).addClass("case").siblings("li").removeClass("case");
    	$(".detailLeft_t>.small_box>div").eq($(this).index()).addClass("seled").siblings("div").removeClass("seled");		
    });
    $(".detailLeft_b>ul>li").mouseenter(function(){
    	console.log($(".big_box>li").eq($(this).index())[0]);
    	$(".big_box>li").eq($(this).index()).css({"display":"block"})
    	$(".big_box>li").eq($(this).index()).siblings("li").css({"display":"none"})

    })
	//  购物详情走边的js效果结束
	//******************************************************
	
	
//	天猫js开始
    $(".tiamao").mouseenter(function(){
    	$(".tiamao>div").addClass("anchor");
    });
    $(".tiamao").mouseleave(function(){
    	$(".tiamao>div").removeClass("anchor");
    });
       $(".taobao").mouseenter(function(){
    	$(".taobao>div").addClass("anchor1");
    });
    $(".taobao").mouseleave(function(){
    	$(".taobao>div").removeClass("anchor1");
    });
//	天猫js结束

//*************************************************************
	
//	运费js开始
	$(".yunfei").click(function(){
		$(".yunfei>div").css({"display":"block"});
	});
	$(".yunfei").mouseleave(function(){
		$(".yunfei>div").css({"display":"none"});
	});
//	运费js结束

//**************************************************************
	
//	放大镜图片关联js开始
//	$(".detailLeft_b>ul>li").mouseenter(function(){
//		$(".big_box>li").eq($(this).index()).addClass("smoll").siblings("li").removeClass("smoll");
//		console.log($(".big_box>li"));
//	});
//	放大镜图片关联js结束
	
	//*****************************************************************
	
	//放大镜js开始
	$(".mask").mouseover(function() {
	    $(".float_layer").show()
	    $(".big_box").show()
	})
	$(".mask").mouseout(function() {
	    $(".float_layer").hide()
	    $(".big_box").hide()
	})
	
	
	$(".mask").mousemove(function(e) {
	    var l = e.pageX - $(".small_box").offset().left - ($(".float_layer").width() / 2)
	    var t = e.pageY - $(".small_box").offset().top - ($(".float_layer").height() / 2)
	    if (l < 0) {
	        l = 0
	    }
	    if (l > $(this).width() - $(".float_layer").width()) {
	        l = $(this).width() - $(".float_layer").width()
	    }
	    if (t < 0) {
	        t = 0
	    }
	    if (t > $(this).height() - $(".float_layer").height()) {
	        t = $(this).height() - $(".float_layer").height()
	    }
	
	    $(".float_layer").css({
	        "left": l,
	        "top": t
	    })
	    var pX = l / ($(".mask").width() - $(".float_layer").width())
	    var pY = t / ($(".mask").height() - $(".float_layer").height())
	    $(".big_box img").css({
	        "left": -pX * ($(".big_box img").width() - $(".big_box").width()),
	        "top": -pY * ($(".big_box img").height() - $(".big_box").height())
	    })
	
	
	});
	//放大镜js结束
//	*****************************************************




//  颜色js开始
    $(".oncikl>li").mouseenter(function(){
    	$(this).addClass("yanse").siblings("li").removeClass("yanse");
    	$(".oncikl>li>div").eq($(this).index()).addClass("ke");
    	$(".oncikl>li>div").eq($(this).index()).parent("li").siblings("li").children("div").removeClass("ke");
    });
     $(".oncikl>li").click(function(){
     	$(this).addClass("yan").siblings("li").removeClass("yan");
     	$(".detailLeft_t>.small_box>div").eq($(this).index()+5).addClass("seled").siblings("div").removeClass("seled");

     });
     $(".oncikl>li").mouseleave(function(){
     	$(this).removeClass("yanse");
     	$(".oncikl>li>div").removeClass("ke");
     })
//  颜色js结束
//************************************************************
 
 
 
// 商品加减js开始
// 商品点击增加
    $("#jia").click(function(){
    	var t=$(this).parent().find(".inp");
    	t.val(parseInt(t.val())+1);
    });
//  商品减
    $("#jian").click(function(){
    	var t=$(this).parent().find(".inp");
    	t.val(parseInt(t.val())-1);
    	if(t.val()<=1){
    		t.val(1);
    	}
    });
//  商品加减js结束
//*************************************************



//鼠标移入图片跳动js
    $(".sb").mouseenter(function(){
    	$(".sb").slideDown(1000).slideUp(200).fadeIn(1000);
    });
    $(".sb1").mouseenter(function(){
    	$(".sb1").slideDown(1000).slideUp(200).fadeIn(1000);
    });
    
    
    
//留言评论图片放大    
    function commentMove(parentcontent, boxcontent) {
    this.obj = {
        activeClass: 'tm-current',
        nextButton: '.tm-m-photo-viewer-navright',
        prevButton: '.tm-m-photo-viewer-navleft',
    }
    this.parentcontent = parentcontent;
    this.boxcontent = boxcontent;

    }
    commentMove.prototype = {
    init: function () {
        var that = this;
        that.start();
        this.lefthover();
        this.righthover();
        this.leftclick();
        this.rightclick();
    },
    start: function () {
        var that = this;
        $(that.parentcontent + ' li').click(function () {

            $(this).toggleClass(that.obj.activeClass).siblings().removeClass(that.obj.activeClass);
            var src = $('.' + that.obj.activeClass).attr('data-src');

            var img = new Image();
            img.src = src;
            img.onload = function () {
                var imageWidth = img.width;
                var imageHeight = img.height;
                $(that.boxcontent).css({ "width": imageWidth, "height": imageHeight })
                $(that.obj.prevButton).css({ "width": imageWidth / 3, "height": imageHeight })
                $(that.obj.prevButton).children().css({ "top": imageHeight / 2 - 10 + 'px' })
                $(that.obj.nextButton).children().css({ "top": imageHeight / 2 - 10 + 'px' })

            }
            if (!src) {
                $(that.boxcontent).css({ "width": 0, "height": 0 });
            } else {
                $(that.boxcontent + " img").attr('src', src);
            }
        })
    },
    lefthover: function () {
        var that = this;
        $(that.obj.prevButton).hover(function () {
            var index = $(that.parentcontent + ' li').index($(that.parentcontent + ' li.' + that.obj.activeClass));
            if (index < 1) {
                $(this).children().css("display", "none");
            } else {
                $(this).children().css({ "display": "inline" });
            }
        }, function () {
            $(this).children().css({ "display": "none" });
        })
    },
    righthover: function () {
        var that = this;

        $(that.obj.nextButton).hover(function () {
            var index = $(that.parentcontent + ' li').index($(that.parentcontent + ' li.' + that.obj.activeClass));
            if (index >= $(that.parentcontent + ' li').length - 1) {
                $(this).children().css("display", "none");
            } else {
                $(this).children().css({ "display": "inline" });
            }
        }, function () {
            $(this).children().css({ "display": "none" });
        })
    },
    leftclick: function () {
        var that = this;
        $(that.obj.prevButton).click(function () {
            var index = $(that.parentcontent + ' li').index($(that.parentcontent + ' li.' + that.obj.activeClass));

            index--;
            if (index >= 0) {
                $(that.parentcontent + ' li').eq(index).toggleClass(that.obj.activeClass).siblings().removeClass(that.obj.activeClass)
                $(that.boxcontent + " img").attr("src", $(that.arentcontent + ' li').eq(index).attr('data-src'))
            }
            if (index < 1) {
                index = 0;
                $(this).children().css({ "display": "none" });
                return;
            }
        })
    },
    rightclick: function () {
        var that = this;
        $(that.obj.nextButton).click(function () {
            var index = $(that.parentcontent + ' li').index($(that.parentcontent + ' li.' + that.obj.activeClass));
            index++;
            $(that.boxcontent + " img").attr("src", $(that.parentcontent + ' li').eq(index).attr('data-src'))

            $(that.parentcontent + ' li').eq(index).toggleClass(that.obj.activeClass).siblings().removeClass(that.obj.activeClass);
            if (index >= $(that.parentcontent + ' li').length - 1) {
                $(this).children().css({ "display": "none" });
            }
        })
    }
}
 
 var obj = new commentMove('.tm-m-photos', '.tm-m-photo-viewer');
    obj.init()
    
    
    
    //留言评论图片放大    
    function commentMove(parentcontent, boxcontent) {
    this.obj = {
        activeClass: 't-current',
        nextButton: '.tm-photo-viewer-navright',
        prevButton: '.tm-photo-viewer-navleft',
    }
    this.parentcontent = parentcontent;
    this.boxcontent = boxcontent;

    }
    commentMove.prototype = {
    init: function () {
        var that = this;
        that.start();
        this.lefthover();
        this.righthover();
        this.leftclick();
        this.rightclick();
    },
    start: function () {
        var that = this;
        $(that.parentcontent + ' li').click(function () {

            $(this).toggleClass(that.obj.activeClass).siblings().removeClass(that.obj.activeClass);
            var src = $('.' + that.obj.activeClass).attr('data-src');

            var img = new Image();
            img.src = src;
            img.onload = function () {
                var imageWidth = img.width;
                var imageHeight = img.height;
                $(that.boxcontent).css({ "width": imageWidth, "height": imageHeight })
                $(that.obj.prevButton).css({ "width": imageWidth / 3, "height": imageHeight })
                $(that.obj.prevButton).children().css({ "top": imageHeight / 2 - 10 + 'px' })
                $(that.obj.nextButton).children().css({ "top": imageHeight / 2 - 10 + 'px' })

            }
            if (!src) {
                $(that.boxcontent).css({ "width": 0, "height": 0 });
            } else {
                $(that.boxcontent + " img").attr('src', src);
            }
        })
    },
    lefthover: function () {
        var that = this;
        $(that.obj.prevButton).hover(function () {
            var index = $(that.parentcontent + ' li').index($(that.parentcontent + ' li.' + that.obj.activeClass));
            if (index < 1) {
                $(this).children().css("display", "none");
            } else {
                $(this).children().css({ "display": "inline" });
            }
        }, function () {
            $(this).children().css({ "display": "none" });
        })
    },
    righthover: function () {
        var that = this;

        $(that.obj.nextButton).hover(function () {
            var index = $(that.parentcontent + ' li').index($(that.parentcontent + ' li.' + that.obj.activeClass));
            if (index >= $(that.parentcontent + ' li').length - 1) {
                $(this).children().css("display", "none");
            } else {
                $(this).children().css({ "display": "inline" });
            }
        }, function () {
            $(this).children().css({ "display": "none" });
        })
    },
    leftclick: function () {
        var that = this;
        $(that.obj.prevButton).click(function () {
            var index = $(that.parentcontent + ' li').index($(that.parentcontent + ' li.' + that.obj.activeClass));

            index--;
            if (index >= 0) {
                $(that.parentcontent + ' li').eq(index).toggleClass(that.obj.activeClass).siblings().removeClass(that.obj.activeClass)
                $(that.boxcontent + " img").attr("src", $(that.arentcontent + ' li').eq(index).attr('data-src'))
            }
            if (index < 1) {
                index = 0;
                $(this).children().css({ "display": "none" });
                return;
            }
        })
    },
    rightclick: function () {
        var that = this;
        $(that.obj.nextButton).click(function () {
            var index = $(that.parentcontent + ' li').index($(that.parentcontent + ' li.' + that.obj.activeClass));
            index++;
            $(that.boxcontent + " img").attr("src", $(that.parentcontent + ' li').eq(index).attr('data-src'))

            $(that.parentcontent + ' li').eq(index).toggleClass(that.obj.activeClass).siblings().removeClass(that.obj.activeClass);
            if (index >= $(that.parentcontent + ' li').length - 1) {
                $(this).children().css({ "display": "none" });
            }
        })
    }
}
 
 var obj = new commentMove('.tm-photos', '.tm-photo-viewer');
    obj.init()
    
//评论放大图片结束    
 
// 留言评论切换
  $('.h_tal_tlt li').click(function()  {
            var i = $(this).index();//控制下标
             $(this).addClass('h_tal_curr').siblings().removeClass('h_tal_curr');
            $('.h_tal_cont>li').eq(i).show().siblings().hide();
   });
 
 $(".h_tal_tlt li:nth-child(1)").click(function(){
 	$(".gh_cont_1_img").css({"display":"block"});
// 	$(".h_tal_cont>li:nth-child(1)").css({"height":"9681px"});
 })
 
// 选择地方开始




//选择地方结束
 

});