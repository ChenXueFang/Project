$(function(){
//	鼠标滚动到一定的程度导航固定
	$(window).scroll(function(){
	if ($(window).scrollTop()>630) {
		$('#klingxing').css({'position':'fixed','top':0})
			}else{
				$('#klingxing').css({'position':'','top':''})
		};
	});

//	 最新 鼠标 点击时字体为黑色 改变背景颜色  
	$(".klingxing li").click(function(){
		$(this).css({'background':'#debe74',"color":"#000"}).siblings("li").css({'background':'#414956',"color":"#fff"});
	})
	
	// 楼层跳跃
	$(".klingxing li").eq(0).click(function(){
		$("html,body").animate({"scrollTop":630});
	})
	$(".klingxing li").eq(1).click(function(){
		$("html,body").animate({"scrollTop":1200});
	})
	$(".klingxing li").eq(2).click(function(){
		$("html,body").animate({"scrollTop":1840});
	})
	$(".klingxing li").eq(3).click(function(){
		alert("密切筹备中,即将上线");
	})
	
	// 鼠标滚动
// 	$(document).scroll(function(){
// 		if($(this).scrollTop()>=630){
// 			$("html,body").animate({"scrollTop":0});
// 		}else{
// 			// $("html,body").animate({"scrollTop":0});
// 		}
// 		
// 	})

windowAddMouseWheel();
function windowAddMouseWheel() {
    var scrollFunc = function (e) {
        e = e || window.event;
        if (e.wheelDelta) {  //判断浏览器IE，谷歌滑轮事件
            if (e.wheelDelta > 0) { //当滑轮向上滚动时
                if($(document).scrollTop()<=630){
                	$("html,body").animate({"scrollTop":0});
                }
            }
            if (e.wheelDelta < 0) { //当滑轮向下滚动时
			console.log("aaa");
                if($(document).scrollTop()==0){
                	$("html,body").animate({"scrollTop":630});
					// console.log("aaa");
					// return false;
                }
            }
        } else if (e.detail) {  //Firefox滑轮事件
            if (e.detail> 0) { //当滑轮向上滚动时
                alert("滑轮向上滚动");
            }
            if (e.detail< 0) { //当滑轮向下滚动时
                alert("滑轮向下滚动");
            }
        }
    };
	//给页面绑定滑轮滚动事件
    if (document.addEventListener) {
        document.addEventListener('DOMMouseScroll', scrollFunc, false);
    }
//滚动滑轮触发scrollFunc方法
    window.onmousewheel = document.onmousewheel = scrollFunc;
}
    
	
	
	
	
//	四张图片滑入效果
	$(".khero li").eq(0).mouseenter(function(){
		$(".khuaru").slideDown();
	})
	$(".khero li").eq(0).mouseleave(function(){
		$(".khuaru").slideUp();
	})
		$(".khero li").eq(1).mouseenter(function(){
		$(".kjialuo").slideDown();
	})
	$(".khero li").eq(1).mouseleave(function(){
		$(".kjialuo").slideUp();
	})
		$(".khero li").eq(2).mouseenter(function(){
		$(".kjialuo2").slideDown();
	})
	$(".khero li").eq(2).mouseleave(function(){
		$(".kjialuo2").slideUp();
	})
	
	
//	手风琴
	$(".kaccordion>li").click(function(){
		$(this).animate({width:'396'},100).siblings("li").animate({width:'145'},100);
		$(this).find(".ksmall_tu").hide();
		$(this).find(".kbig_tu").show();
		$(this).siblings("li").find(".ksmall_tu").show();
		$(this).siblings("li").find(".kbig_tu").hide();
	})
	
//	左右箭头
var num =1;
	$("#right").click(function(){
		num++;//2
		if(num>3){
			num=3;
		}
		if(num==2){
			$(".kaccordion>li").eq(2).animate({width:'396'},100).siblings("li").animate({width:'145'},100);
       		 $(".kaccordion>li").eq(2).find(".ksmall_tu").hide();
			$(".kaccordion>li").eq(2).find(".kbig_tu").show();
			$(".kaccordion>li").eq(2).siblings("li").find(".ksmall_tu").show();
			$(".kaccordion>li").eq(2).siblings("li").find(".kbig_tu").hide();
		}else{
			$(".kaccordion>li:eq(2)").next('li').animate({width:'396'},100).siblings("li").animate({width:'145'},100);
        	$(".kaccordion>li:eq(2)").next('li').find(".ksmall_tu").hide();
			$(".kaccordion>li:eq(2)").next('li').find(".kbig_tu").show();
			$(".kaccordion>li:eq(2)").next('li').siblings("li").find(".ksmall_tu").show();
			$(".kaccordion>li:eq(2)").next('li').siblings("li").find(".kbig_tu").hide();
		}
     $('.kaccordion').css({'margin-left':-145*num+'px'});
	})
	$("#left").click(function(){
		num--;
		if(num<0){
			num=0;
		}
     $('.kaccordion').css({'margin-left':-141*num+'px'});
	})
	
	
	
	
	
	
	
})
