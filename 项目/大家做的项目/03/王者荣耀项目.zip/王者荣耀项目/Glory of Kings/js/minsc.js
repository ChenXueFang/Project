$(function(){
	$(".cenner_main ul li").mouseover(function(){
		$(this).children("img:eq(1)").addClass("dong");
		$(this).children("img:eq(1)").animate({left:40});
	})
	$(".cenner_main ul li").mouseout(function(){
		$(this).children("img:eq(1)").removeClass("dong");
		$(this).children("img:eq(1)").animate({left:30});
	})
	/*左右箭头*/
	$("ol .lo_left").click(function(){

      $('.cenner_main ul').append($('.cenner_main ul li:eq(0)'));
	})
	$("ol .lo_right").click(function(){
	  $('.cenner_main ul').prepend($('.cenner_main ul li:eq(5)'));
	})
	 /*点击后大图片变化*/
	$(".cenner_main ul li").click(function(){
		var a=$(this).children("img:eq(0)").attr('src');
		/*获取大图的src并改变*/
		$(".box_img>:eq(0)").attr('src',a);
		/*圆盘动起来*/
		for(var i=0;i<190;i++){
		}
		$(".box_img>:eq(1)").css({left:100});
		$(".box_img>:eq(1)").animate({left:i});
		$(".box_img>:eq(1)").removeClass("dong");
	})
})
