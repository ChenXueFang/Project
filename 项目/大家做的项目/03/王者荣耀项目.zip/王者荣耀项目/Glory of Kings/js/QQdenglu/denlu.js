$(function(){
	var timer=null;
	var i=0;
    timer=setInterval(function(){
    	i++;
        $(".prcBox img").attr("src","../img/qq_imgs/qq"+i+".jpg");
       if(i>2)
        i=0;
    },3000);
    /*右边的下滑菜单*/
  $(".qq_top_nav ul li:eq(0)").mouseover(function(){
  	  $(this).children("ul").show();
  })
   $(".qq_top_nav ul li:eq(0)").mouseout(function(){
  	  $(this).children("ul").hide();
  });
    $(".qq_top_nav ul li:eq(2)").mouseover(function(){
    $(this).children("img").attr("src","../img/qq_imgs/up2.png");
  	  $(this).children("ul").show();
  })
   $(".qq_top_nav ul li:eq(2)").mouseout(function(){
   	$(this).children("img").attr("src","../img/qq_imgs/up1.png");
  	  $(this).children("ul").hide();
  })
   /*登录昵称和密码*/
$('.input_nicheng input').focus(function(){
	 $(this).next().css("display","none");
})
$('.input_nicheng input').blur(function(){
	var Long = $(this).val().length;
	if(Long>0){
     $(this).next().css("display","none");
    }
    else{
     $(this).next().css("display","block");
    }
})
$('.input_nicheng input').focus(function(){
	 $(this).next().css("display","none");
})
/*密码*/
$('.input_mima input').blur(function(){
	var Long = $(this).val().length;
	  $(".input_mima>span:eq(1)").css("display","none");
	 $(".input_mima>span:eq(2)").css("display","none");
	 $(".input_mima>span:eq(3)").css("display","none");
	if(Long>0){
     $(".input_mima>span:eq(0)").css("display","none");
    }
    else{
     $(".input_mima>span:eq(0)").css("display","block");
    }
})
$('.input_mima input').focus(function(){
	 $(".input_mima>span:eq(0)").css("display","none");
	  $(".input_mima>span:eq(1)").css("display","block");
	 $(".input_mima>span:eq(2)").css("display","block");
	 $(".input_mima>span:eq(3)").css("display","block");
})
/*电话区域，下拉按钮*/
$(".cell_phone>input:eq(0)").focus(function(){
	$(".cell_phone>ul").css("display","block");
	$(".cell_phone>img").attr("src","../img/qq_imgs/up2.png");

})
$(".cell_phone>input:eq(0)").blur(function(){
	$(".cell_phone>ul").css("display","none");
	$(".cell_phone>img").attr("src","../img/qq_imgs/up1.png");
})
/*发送手机短信*/
$(".cell_phone>input:eq(1)").focus(function(){
	$(".send_text").css("display","block");
});
$(".cell_phone>input:eq(1)").blur(function(){
	$(".send_text").css("display","none");
});
/*QQ隐私政策*/
var key=0;
$(".statement span>:first-child").click(function(){
	key++;
	 $(this).attr("src","../img/qq_imgs/checkbox"+key+".png");
	 if(key>1)
	 key=0;
})
var t=1;
$(".statement span>img:eq(1)").click(function(){
	t++;
	 $(this).attr("src","../img/qq_imgs/up"+t+".png");
	 if(t%2==0)
	 {
	  $(this).next().css("display","block");
	 }
	 else{
	 	$(this).next().css("display","none");
	 }
	 if(t>=2){
	 	t=0
	 }
})



 
 
   
   
   
   
   
   
})


