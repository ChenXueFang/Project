$(document).ready(function(){
	$(".qs_wslp").mouseenter(function(){
		$(".qs_wslp>.qs_wsx").hide();
		$(".qs_wslp>.qs_wsd").show()
	})
	$(".qs_wslp").mouseleave(function(){
		$(".qs_wslp>.qs_wsx").show();
		$(".qs_wslp>.qs_wsd").hide()
	})
//	游戏排行榜的下拉
	
	$(".qs_paihang").mouseenter(function(){
		$(".qs_phkuang").show();
		$(".qs_ssjx").show();
		$(".qs_blackxl").hide();
		$("qs_redxl").show();
	})
	$(".qs_paihang").mouseleave(function(){
		$(".qs_phkuang").hide();
		$(".qs_ssjx").hide();
		$(".qs_blackxl").show();
		$("qs_redxl").hide();
	})
//	里面出现的手风琴效果
$(".qs_phkuang>ul>li>span").mouseenter(function(){
				$(this).next().show().parent("li").siblings("li").children("div").hide();
			})
//导航条部分
$(".qs_guanwangsy>li").mouseenter(function(){
	$(this).addClass("qs_beijing").siblings("li").removeClass("qs_beijing");
})
$(".qs_guanwangsy>li").mouseleave(function(){
	$(this).removeClass("qs_beijing");
})
$(".qs_nav_con").mouseenter(function(){
	$(".qs_navxiala").show();
})
$(".qs_nav_con").mouseleave(function(){
	$(".qs_navxiala").hide();
})
	
	
//手风琴——hero
$(".shoufeng>li").mouseenter(function(){
	$(this).animate({width:'224'},100).siblings("li").animate({width:'69'},100);
	$(this).find(".g_small").hide();
	$(this).find(".g_big").show();
	$(this).siblings("li").find(".g_small").show();
	$(this).siblings("li").find(".g_big").hide();
})
//放大镜显示效果
$(".jingtuo").mouseenter(function(){
	$(this).find("span").show().parent("a").parent(".item").siblings(".item").find("a").find("span").hide();
//	$(this).find("span").css("opacity","0.3").parent("a").parent(".item").siblings(".item").find("a").find("span").hide();
	
})
$(".jingtuo").mouseleave(function(){
	$(this).find("span").hide().parent("a").parent(".item").siblings(".item").find("a").find("span").hide();
})
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
})
