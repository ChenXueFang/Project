$(function(){
	//星光活动轮播
	(function() {
			Slider.init({
				target: $('.slider'),
				time: 3000
			});
		})();
	//tab切换
	$(".lz_first>li").click(function(){
    	//li
    	$(this).children("a").css({"background-position-x":-825,"background-position-y":-178});
    	$(this).siblings("li").children("a").css({"background-position-x":-825,"background-position-y":-314});
    	$("#lz_xingGuang>div").eq($(this).index()).addClass("lz_show").siblings("div").removeClass("lz_show");
    	console.log($(this).index());
	})
	
	
	
	
	
	
	
	
	
	
})
