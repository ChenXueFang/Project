/*
* @Author: win
* @Date:   2016-09-09 12:21:34
* @Last Modified by:   win
* @Last Modified time: 2016-09-09 16:00:11
*/

'use strict';
//右侧导航条
var $key=0;//记录滚动到哪一个
var canscroll = true;//用来限制滚动频率
jQuery(document).ready(function($) {
	change_size();
	$(window).on('resize', function(event) {
		event.preventDefault();
		change_size();
	});
	
	//在第一页的时候,没有右侧的菜单栏	
	$(document).scroll(function(){
		if($(document).scrollTop()<=80){
			$(".gNaveZ").css({"display":"none"});
		}else{
			$(".gNaveZ").css({"display":"block"});
		}
	});

	/***滚动鼠标**/
	$(document).mousewheel(function(event,delta){
		if (canscroll) {
			//限制滚动
			canscroll = false;
			 $key-=delta;
			 if($key<0)   
			 {
			 	$key=0
			 }else if($key > 4)
			 {
			 	$key=5;
			 	canscroll = true;
			 	return;
			 }
			 console.log($key);
			 //滚动页面
			 $("body,html").stop().animate({
		 		"scrollTop":$(".gMainBoxZ>div").eq($key).offset().top-42
		 	},700,function(){
		 		//释放滚动条
		 		canscroll = true;
		 	});
	 		//添加菜单当前色
	 		$(".gNaveZ ul li").eq($key).addClass('gCurrentZ').siblings().removeClass('gCurrentZ');
	 		$(".gNaveZ ul li").eq($key).children("span").animate({"opacity":1});
	 		$(".gNaveZ ul li").eq($key).siblings().children("span").animate({"opacity":0});
	 		$(".gMainBoxZ>div").eq($key).children("img:nth-child(2)").addClass("gHuaRu");
	 		$(".gMainBoxZ>div").eq($key).siblings("div").children("img:nth-child(2)").removeClass("gHuaRu");
	 		$(".gMainBoxZ>div").eq($key).children("img:nth-child(1)").addClass("gHuaTitle");
	 		$(".gMainBoxZ>div").eq($key).siblings("div").children("img:nth-child(1)").removeClass("gHuaTitle");
	 		$(".gMainBoxZ>div").eq($key).children("img:nth-child(3)").addClass("gHuaLeft");
	 		$(".gMainBoxZ>div").eq($key).siblings("div").children("img:nth-child(3)").removeClass("gHuaLeft");
		};	
		//四张头像
		if($key==3|$key==4){
			//console.log("1");
			$(".ktouxiang span").eq(0).fadeIn(4000);
			$(".ktouxiang span").eq(1).fadeIn(8000);
			$(".ktouxiang span").eq(2).fadeIn(12000);
			$(".ktouxiang span").eq(3).fadeIn(16000);
			$(".ktouxiang2 span").eq(0).fadeIn(4000);
			$(".ktouxiang2 span").eq(1).fadeIn(8000);
			$(".ktouxiang2 span").eq(2).fadeIn(12000);
			$(".ktouxiang2 span").eq(3).fadeIn(16000);
		}
//		if($key==4){
////			console.log("1");
//			$(".ktouxiang2 span").eq(0).fadeIn(4000);
//			$(".ktouxiang2 span").eq(1).fadeIn(8000);
//			$(".ktouxiang2 span").eq(2).fadeIn(12000);
//			$(".ktouxiang2 span").eq(3).fadeIn(16000);		
//		}
	})
	/*****点击侧边菜单***/
	$(".gNaveZ ul li").click(function(event) {
		$key = $(this).index();
		$(".gNaveZ ul li").eq($(this).index()).addClass('gCurrentZ').siblings().removeClass('gCurrentZ');
		 $("body,html").stop().animate({
		 		"scrollTop":$(".gMainBoxZ>div").eq($(this).index()).offset().top-42
		 	},700);
	});
	
//	鼠标移动在菜单上时出现的效果
	var gcolor = "";
	var gWeight = "";
	var gSpan = "";
	$(".gNaveZ>ul>li").mouseenter(function(){
		gcolor = $(this).css("color");
		gWeight = $(this).css("font-weight");
		gSpan = $(this).css("color");
		$(this).css({"color":"#fff","font-weight":700});
		$(this).children("span").css({"opacity":1});
//		console.log($(this).css("color"));
	})
	$(".gNaveZ>ul>li").mouseleave(function(){
		$(this).css({"color":gcolor,"font-weight":gWeight});
		$(this).children("span").css({"opacity":0})
	})
	
//滚动到哪个页面，就出现滑进图片
//	$(".gMainBoxZ>div").mouseenter(function(){
//		$(this).children("img").addClass("gHuaRu");
//	});
//	$(".gMainBoxZ>div").mouseleave(function(){
//		$(this).children("img").removeClass("gHuaRu");
//	});
});
//动态设置大小
function change_size(){
	var window_height = $(window).height();
//	$(".gNaveZ").height(window_height);
	var size = Number($(".gNaveZ ul li").size());
//	$(".gNaveZ ul li").css({'line-height':$(".gNaveZ").height()/size+"px",'height':$(".gNaveZ").height()/size+"px"});
	$(".gMainBoxZ>div").height(window_height-42);
	$("body,html").stop().animate({
 		"scrollTop":$(".gMainBoxZ>div").eq($key).offset().top-42},700,function(){
 		//释放滚动条
 		canscroll = true;
 	});
	//添加菜单当前色
	$(".gNaveZ ul li").eq($key).addClass('gCurrentZ').siblings().removeClass('gCurrentZ');
	$(".gNaveZ ul li").eq($key).children("span").animate({"opacity":1});
	$(".gNaveZ ul li").eq($key).siblings().children("span").animate({"opacity":0});
	$(".gMainBoxZ>div").eq($key).children("img:nth-child(2)").addClass("gHuaRu");
	$(".gMainBoxZ>div").eq($key).siblings("div").children("img:nth-child(2)").removeClass("gHuaRu");
	$(".gMainBoxZ>div").eq($key).children("img:nth-child(1)").addClass("gHuaTitle");
	$(".gMainBoxZ>div").eq($key).siblings("div").children("img:nth-child(1)").removeClass("gHuaTitle");
	$(".gMainBoxZ>div").eq($key).children("img:nth-child(3)").addClass("gHuaLeft");
	$(".gMainBoxZ>div").eq($key).siblings("div").children("img:nth-child(3)").removeClass("gHuaLeft");
}
//	扫码下载
	$(function(){
		$("#kdownload").mouseenter(function(){
			$("#saoma").show();
		})
		$("#kdownload").mouseleave(function(){
			$("#saoma").hide();
		})
		
//		营地社区中的头像 点击事件
		$("#kshequ").click(function(){
			$(".ktouxiang span").eq(0).fadeIn(4000);
			$(".ktouxiang span").eq(1).fadeIn(8000);
			$(".ktouxiang span").eq(2).fadeIn(12000);
			$(".ktouxiang span").eq(3).fadeIn(16000);
			$(".ktouxiang2 span").eq(0).fadeIn(4000);
			$(".ktouxiang2 span").eq(1).fadeIn(8000);
			$(".ktouxiang2 span").eq(2).fadeIn(12000);
			$(".ktouxiang2 span").eq(3).fadeIn(16000);
		})
	})
	
