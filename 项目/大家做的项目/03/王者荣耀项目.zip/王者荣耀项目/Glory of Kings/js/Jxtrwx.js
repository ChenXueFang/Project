$(function() {
	$(".yjgda").click(function() {
		$("dl").show();
	})
	$('body').click(function(e) {
			if($(e.target).attr('class') != 'yjgda') {
				$('.gdacon').css('display', 'none');
			}
		})
		//	轮播图
	var slideBox = $(".yjslideBox");
	var ul = slideBox.find("ul");
	var oneWidth = slideBox.find("ul li").eq(0).width();
	var number = slideBox.find(".yjspanBox span"); //注意分号 和逗号的用法
	var timer = null;
	var sw = 0;
	//每个span绑定click事件，完成切换颜色和动画，以及读取参数值
	number.on("click", function() {
		$(this).addClass("yjactive").siblings("span").removeClass("yjactive");
		sw = $(this).index();
		ul.animate({
			"right": oneWidth * sw, //ul标签的动画为向左移动；
		});
	});
	//左右按钮的控制效果
	$(".yjnext").stop(true, true).click(function() {
		sw++;
		if(sw == number.length) {
			sw = 0
		};
		number.eq(sw).trigger("click");
	});
	$(".yjprev").stop(true, true).click(function() {
		sw--;
		if(sw == number.length) {
			sw = 0
		};
		number.eq(sw).trigger("click");
	});
	//定时器的使用，自动开始
	timer = setInterval(function() {
		sw++;
		if(sw == number.length) {
			sw = 0
		};
		number.eq(sw).trigger("click");
	}, 3000);
	//hover事件完成悬停和，左右图标的动画效果
	slideBox.hover(function() {
			$(".yjnext,.yjprev").animate({
				"opacity": 1,
			}, 200);
			clearInterval(timer);
		}, function() {
			$(".yjnext,.yjprev").animate({
				"opacity": 0.5,
			}, 500);
			timer = setInterval(function() {
				sw++;
				if(sw == number.length) {
					sw = 0
				};
				number.eq(sw).trigger("click");
			}, 3000);
		})
	//	鼠标移入出现开始阅读蒙版

	$('#libai').mouseenter(function(){
		$(this).children('a').css("display","block");
		
	})
	$('#libai').mouseleave(function(){
		$(this).children('a').css("display","none");
		
	})
	
	$('#yys').mouseenter(function(){
		$(this).children('a').css("display","block");
		
	})
	$('#yys').mouseleave(function(){
		$(this).children('a').css("display","none");
		
	})
	
	$('#ryzj').mouseenter(function(){
		$(this).children('a').css("display","block");
		
	})
	$('#ryzj').mouseleave(function(){
		$(this).children('a').css("display","none");
		
	})
	
	// 小轮播图
	var q=0;
	$(".l_lunbo_r").click(function(){
		q++;
		if(q>4){
			q=0;
		}
		$(".l_small_lunbo>li").eq(q).css("z-index","8").animate({
			width: 180,
			height: 260,
			left: 33,
			zIndex: 2,
			top: 0,
		}).next("li").animate({
			width: 144,
			height: 208,
			zIndex: 1,
			opacity: 1,
			left: 85.5,
			top: 26,
		}).next("li").animate({
			width: 115,
			height: 166,
			zIndex: 0,
			opacity: 0.5,
			left: 130.8,
			top: 46.8,
		}).next("li").animate({
			width: 115,
			height: 166,
			zIndex: 0,
			opacity: 0.5,
			left: 0,
			top: 47,
		}).next("li").animate({
			width: 143,
			height: 208,
			zIndex: 1,
			opacity: 1,
			left: 16.5,
			top: 26.25,
		});
		
		$(".l_small_lunbo>li").eq(q).prev("li").animate({
			width: 144,
			height: 208,
			zIndex: 1,
			opacity: 1,
			left: 16.5,
			top: 26,
		}).prev("li").animate({
			width: 115,
			height: 166,
			zIndex: 0,
			opacity: 0.5,
			left: 0,
			top: 47,
		}).prev("li").animate({
			width: 115,
			height: 166,
			zIndex: 0,
			opacity: 0.5,
			left: 130.8,
			top: 46.8,
		}).prev("li").animate({
			width: 143,
			height: 208,
			zIndex: 1,
			opacity: 1,
			left: 85.5,
			top: 26.25,
		})
		
		$(".small_lunbo_zsq>div").eq(q).find("a").addClass("tanchishe");
		$(".small_lunbo_zsq>div").eq(q).siblings("div").find("a").removeClass("tanchishe");
		$(".sm_lunbo_tip").eq(q).show().siblings().hide();
		
		
	})
	
	$(".l_lunbo_l").click(function(){
		q--;
		if(q<0){
			q=4;
		}
		$(".l_small_lunbo>li").eq(q).css("z-index","8").animate({
			width: 180,
			height: 260,
			left: 33,
			zIndex: 2,
			top: 0,
		}).next("li").animate({
			width: 144,
			height: 208,
			zIndex: 1,
			opacity: 1,
			left: 85.5,
			top: 26,
		}).next("li").animate({
			width: 115,
			height: 166,
			zIndex: 0,
			opacity: 0.5,
			left: 130.8,
			top: 46.8,
		}).next("li").animate({
			width: 115,
			height: 166,
			zIndex: 0,
			opacity: 0.5,
			left: 0,
			top: 47,
		}).next("li").animate({
			width: 143,
			height: 208,
			zIndex: 1,
			opacity: 1,
			left: 16.5,
			top: 26.25,
		});
		
		$(".l_small_lunbo>li").eq(q).prev("li").animate({
			width: 144,
			height: 208,
			zIndex: 1,
			opacity: 1,
			left: 16.5,
			top: 26,
		}).prev("li").animate({
			width: 115,
			height: 166,
			zIndex: 0,
			opacity: 0.5,
			left: 0,
			top: 47,
		}).prev("li").animate({
			width: 115,
			height: 166,
			zIndex: 0,
			opacity: 0.5,
			left: 130.8,
			top: 46.8,
		}).prev("li").animate({
			width: 143,
			height: 208,
			zIndex: 1,
			opacity: 1,
			left: 85.5,
			top: 26.25,
		})
		
		$(".small_lunbo_zsq>div").eq(q).find("a").addClass("tanchishe");
		$(".small_lunbo_zsq>div").eq(q).siblings("div").find("a").removeClass("tanchishe");
		$(".sm_lunbo_tip").eq(q).show().siblings().hide();
		
		
	})
	
	// 点击指示器
	$(".small_lunbo_zsq>div").click(function(){
		q=$(this).index();
		$(".small_lunbo_zsq>div").eq(q).find("a").addClass("tanchishe");
		$(".small_lunbo_zsq>div").eq(q).siblings("div").find("a").removeClass("tanchishe");
		$(".sm_lunbo_tip").eq(q).show().siblings().hide();
		
		$(".l_small_lunbo>li").eq(q).css("z-index","10").animate({
			width: 180,
			height: 260,
			left: 33,
			zIndex: 2,
			top: 0,
		}).next("li").animate({
			width: 144,
			height: 208,
			zIndex: 1,
			opacity: 1,
			left: 85.5,
			top: 26,
		}).next("li").animate({
			width: 115,
			height: 166,
			zIndex: 0,
			opacity: 0.5,
			left: 130.8,
			top: 46.8,
		}).next("li").animate({
			width: 115,
			height: 166,
			zIndex: 0,
			opacity: 0.5,
			left: 0,
			top: 47,
		}).next("li").animate({
			width: 143,
			height: 208,
			zIndex: 1,
			opacity: 1,
			left: 16.5,
			top: 26.25,
		});
		
		$(".l_small_lunbo>li").eq(q).prev("li").animate({
			width: 144,
			height: 208,
			zIndex: 1,
			opacity: 1,
			left: 16.5,
			top: 26,
		}).prev("li").animate({
			width: 115,
			height: 166,
			zIndex: 0,
			opacity: 0.5,
			left: 0,
			top: 47,
		}).prev("li").animate({
			width: 115,
			height: 166,
			zIndex: 0,
			opacity: 0.5,
			left: 130.8,
			top: 46.8,
		}).prev("li").animate({
			width: 143,
			height: 208,
			zIndex: 1,
			opacity: 1,
			left: 85.5,
			top: 26.25,
		})
	})
	
	
	
})