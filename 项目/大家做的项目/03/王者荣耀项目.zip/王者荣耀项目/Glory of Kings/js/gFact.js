$(function(){
//	手风琴的效果
	$(".gSkillsTitle").mouseenter(function(){
		$(this).siblings(".gSkillsImg").animate({"width":638}).parent("li").siblings("li").children(".gSkillsImg").animate({"width":0});
	});
//浮动的导条
	$(document).scroll(function(){
		if($(this).scrollTop()>=80){
			$(".gSkinShowBox").css({"top":0});
		}else{
			$(".gSkinShowBox").css({"top":80});
		}
	});
//瞄点动画
	$('a[href="#gHeadX"],a[href="#gFeatuBox"]').click(function() {
   if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
      var $target = $(this.hash);
      $target = $target.length && $target || $('[name=' + this.hash.slice(1) + ']');
      if ($target.length) {
         var targetOffset = $target.offset().top;
         $('html,body').animate({
               scrollTop: targetOffset
            },
            1000);
         return false;
      }
   }
	});
//点击瞄点时的文字切换效果
	$(".gClick").click(function(){
		$(this).css({"color":"#c39b5e"});
		$(this).parent("li").siblings("li").children("a").css({"color":"#a59e94"});
	})
});