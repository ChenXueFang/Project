$(document).ready(function(){

// 三张图片轮播
$(".l_left_tip>li").mouseenter(function(){
	$(this).addClass("l_tip_cur").siblings("li").removeClass("l_tip_cur");
	$(".l_left_pic>div").animate({
		left:$(this).index()*-600
	},200);
})
var l_timer_threepic=null,a=0;

// 轮播函数  自动轮播
function l_fn(){
	a++;
	if(a>2){
		a=0;
	}
	$(".l_left_tip>li").eq(a).addClass("l_tip_cur").siblings("li").removeClass("l_tip_cur");
	$(".l_left_pic>div").animate({
		left:a*-600
	},200);
}

l_timer_threepic=setInterval(l_fn,2000);
$(".l_banner_left").mouseenter(function(){
	clearInterval(l_timer_threepic);
})
$(".l_banner_left").mouseleave(function(){
	l_timer_threepic=setInterval(l_fn,2000);
})
	
	
// 公告菜单切换
$(".l_banner_right>ul>li").click(function(){
	$(this).addClass("l_cur_ggao").siblings("li").removeClass("l_cur_ggao");
	$(".l_banner_right>dl").eq($(this).index()).css("display","block").siblings("dl").css("display","none");
	
})

// 手风琴展示部分
$(".l_show_box>ul>li").click(function(){
	$(this).animate({width:600},200).siblings("li").animate({width:140},200);
	$(this).children("a").css("display","none");
	$(this).children(".l_item_pic").css("display","block");
	$(this).siblings("li").children("a").css("display","block");
	$(this).siblings("li").children(".l_item_pic").css("display","none");
})

// 点击箭头滚动
$(".l_arr_right").eq(0).click(function(){
	$(".spxt_ul").animate({
		left:'-=150px'
	})
})
$(".l_arr_left").eq(0).click(function(){
	$(".spxt_ul").animate({
		left:'+=150px'
	})
})
$(".l_arr_right").eq(1).click(function(){
	$(".djjz_ul").animate({
		left:'-=150px'
	})
})
$(".l_arr_left").eq(1).click(function(){
	$(".djjz_ul").animate({
		left:'+=150px'
	})
})



	
	
	
	
	
})