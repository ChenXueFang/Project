$(document).ready(function(){
				$(".qs_bannertext>li").mouseenter(function(){
					
					$(".qs_lunbopic>div").eq($(this).index()).addClass("qs_chuxian").siblings("div").removeClass("qs_chuxian");
				});
				
//				中间的tab部分
$(".qs_bantabtext>li").mouseenter(function(){
	$(this).addClass("qs_biansel").siblings("li").removeClass("qs_biansel")
		$(".qs_bantabcon>div").eq($(this).index()).addClass("qs_xianchul").siblings("div").removeClass("qs_xianchul");
});
				
//图片放大
// $("#qs_foumax>ul>li").mouseenter(function(){
// 	$(this).children().animate({"width":"+=10",
// 	"height":"+=10"}).siblings("li").animate({"width":"291",
// 	"height":"134"})
// })
// $("#qs_foumax>ul>li").mouseleave(function(){
// 	$(this).children().animate({"width":"291",
// 	"height":"134"})
// })

//内容部分			
$(".qs_tablan>li").mouseenter(function(){
	$(this).addClass("qs_duochulai").siblings("li").removeClass("qs_duochulai");
	$(".qs_tabcon>div").eq($(this).index()).addClass("qs_flow").siblings("div").removeClass("qs_flow");
})
				
//		qs_tablan和qs_tabcon里面的div是一组		
$(".qs_lan>li").mouseenter(function(){
	$(this).addClass("qs_lanchuxian").siblings("li").removeClass("qs_lanchuxian");
		$(".qs_lancon>div").eq($(this).index()).addClass("lanconchuxian").siblings("div").removeClass("lanconchuxian");
})
//右边的新英雄部分			
$(".qs_newlan>li").mouseenter(function(){
	$(this).addClass("qs_newlanxian").siblings("li").removeClass("qs_newlanxian");
	$(".qs_newcon>div").eq($(this).index()).addClass("newconxian").siblings("div").removeClass("newconxian");
})


//小英雄淡入淡出//待修改..........bug
$(".qs_smhero>li").mouseenter(function(){
	$(this).children("div").fadeIn(200);
	$(this).siblings("li").children("div").fadeOut(200);

})
$(".qs_smhero>li").mouseleave(function(){
	
	$(this).children("div").fadeOut(200);

})
//赛事中心部分
$(".qs_sailan>li").mouseenter(function(){
	$(this).addClass("sailanxian").siblings("li").removeClass("sailanxian");
	$(".qs_saicon>div").eq($(this).index()).addClass("saiconchuxian").siblings("div").removeClass("saiconchuxian");
})
		
		
		
})
				
				
				
				
				
				
				
	
				
				
				
				
				
				
				
		