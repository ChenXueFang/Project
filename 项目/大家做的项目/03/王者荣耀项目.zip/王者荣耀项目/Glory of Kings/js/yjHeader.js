$(function() {
	$(".yjgda").click(function() {
		$("dl").show();
	})
	$('body').click(function(e) {
			if($(e.target).attr('class') != 'yjgda') {
				$('.gdacon').css('display', 'none');
			}
		})
		//	轮播图
	var slideBox = $(".yjslideBox");
	var ul = slideBox.find("ul");
	var oneWidth = slideBox.find("ul li").eq(0).width();
	var number = slideBox.find(".yjspanBox span"); //注意分号 和逗号的用法
	var timer = null;
	var sw = 0;
	//每个span绑定click事件，完成切换颜色和动画，以及读取参数值
	number.on("click", function() {
		$(this).addClass("yjactive").siblings("span").removeClass("yjactive");
		sw = $(this).index();
		ul.animate({
			"right": oneWidth * sw, //ul标签的动画为向左移动；
		});
	});
	//左右按钮的控制效果
	$(".yjnext").stop(true, true).click(function() {
		sw++;
		if(sw == number.length) {
			sw = 0
		};
		number.eq(sw).trigger("click");
	});
	$(".yjprev").stop(true, true).click(function() {
		sw--;
		if(sw == number.length) {
			sw = 0
		};
		number.eq(sw).trigger("click");
	});
	//定时器的使用，自动开始
	timer = setInterval(function() {
		sw++;
		if(sw == number.length) {
			sw = 0
		};
		number.eq(sw).trigger("click");
	}, 3000);
	//hover事件完成悬停和，左右图标的动画效果
	slideBox.hover(function() {
			$(".yjnext,.yjprev").animate({
				"opacity": 1,
			}, 200);
			clearInterval(timer);
		}, function() {
			$(".yjnext,.yjprev").animate({
				"opacity": 0.5,
			}, 500);
			timer = setInterval(function() {
				sw++;
				if(sw == number.length) {
					sw = 0
				};
				number.eq(sw).trigger("click");
			}, 3000);
		})
		//	手风琴效果轮播
		var backG = "";
	$(".parentWrap span").click(function() {
		var backG =  $(this).css("background-image");
		console.log(backG);
		$(this).css("background","#fff");
		$(this).parent("li").siblings("li").children("span").click(function(){
			$(this).parent("li").siblings("li").children("span").css("background",backG);
		})
		$(this).siblings("div").fadeIn(2000);
		$(this).parent("li").siblings("li").children("div").hide();
	})
	/*鼠标放入后显示文字*/
	$(".menuGroup>div").mouseenter(function(){
	  $(this).children('span').show();
	})
	$(".menuGroup>div").mouseleave(function(){
	  $(this).children('span').hide();
	})
	

})

