$(function(){
//关闭温馨提示
	$(".warm_tip").click(function(){
		$("#js_tell").hide();
	})
//=======================================================
//	全选
	$(".js_allinput").click(function(){
		$(".js_dianpu input:checkbox").prop("checked",$(this).prop("checked"));
		$(".js_botchange input:checkbox").prop("checked",$(this).prop("checked"));
		
	})
	$(".js_botchange input:checkbox").click(function(){
		$(".js_dianpu input:checkbox").prop("checked",$(this).prop("checked"));
		$(".js_allinput").prop("checked",$(this).prop("checked"));
		
	})
	$(".js_common").click(function(){
		$(".js_danxuan").prop("checked",$(this).prop("checked"));
		$(".js_botchange input:checkbox").prop("checked",$(this).prop("checked"));
	})
	$(".js_dianpu input:checkbox").click(function(){
		if($(".js_dianpu input:checkbox").length==$(".js_dianpu input:checked").length){
			$(".js_allinput").prop("checked",true);
		}else{
			$(".js_allinput").prop("checked",false);
		}
		
	})
//	$(".danxuan").click(function(){
//		$(".conJs_change input:checkbox").prop("checked",$(this).prop("checked"));
//	})


//加减号
	$(".js_jian").mouseenter(function(){
		$(".js_jian").css("background","#f5f5f5");
	})
	$(".js_jia").mouseenter(function(){
		$(".js_jia").css("background","#f5f5f5");
	})
	$(".js_jian").mouseleave(function(){
		$(".js_jian").css("background","white");
	})
	$(".js_jia").mouseleave(function(){
		$(".js_jia").css("background","white");
	})
	var i=$(".js_neirong").html();
	$(".js_jia").click(function(){
		i++;
		$(".js_xiao").html("¥"+635*i+".00");
		$(".js_zongji").html("¥"+635*i+".00");
		$(".js_num").html(i);
		$(".js_neirong").html(i);
		if(i>=4){
			$(".js_jia").css("cursor","not-allowed");
			i=4;
		}else{
			$(".js_jia").css("cursor","pointer");
		}
		
		
	console.log(i)
	})
	$(".js_jian").click(function(){
		
		$(".js_neirong").html(i);
		$(".js_num").html(i);
		$(".js_xiao").html("¥"+635*i+".00");
		$(".js_zongji").html("¥"+635*i+".00");
		i--;
		if(i<1){
			i=1;
			$(".js_jian").css("cursor","not-allowed");
		}else{
			$(".js_jian").css("cursor","pointer");
		}
		
		
	})
	
//	为您推荐切换
	$(".js_teshu1").click(function(){
		$(".js_teshu1").css("border-bottom","2px solid black");
		$(".js_teshu2").css("border-bottom","none");
		$(".botJs").slideDown();
		$(".botJs1").hide();
		$(".js_teshu3").show();
	})
	$(".js_teshu2").click(function(){
		$(".js_teshu1").css("border-bottom","none");
		$(".js_teshu2").css("border-bottom","2px solid black");
		$(".botJs1").slideDown();
		$(".botJs").hide();
		$(".js_teshu3").hide();
	})
	$(".js_teshu3").click(function(){
		$(".botJs").slideToggle();
		$(".botJs1").slideToggle();
	})
	
	//删除
	$(".js_del").click(function(){
		$(".js_shanchu").show();
	})
	$(".js_no").click(function(){
		$(".js_shanchu").hide();
	})
	$(".js_not").click(function(){
		$(".js_shanchu").hide();
	})
	$(".js_sure").click(function(){
		$(".js_xiaoshi").show();
		$(".js_shanchu").hide();
	})
	
	})




