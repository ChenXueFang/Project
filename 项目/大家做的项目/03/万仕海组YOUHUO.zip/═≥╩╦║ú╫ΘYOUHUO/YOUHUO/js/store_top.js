$(function(){
	//有货部分的js效果
	$("#yoho").mouseenter(function(){
		$(".have").show();
	})
	$("#yoho").mouseleave(function(){
		$(".have").hide();
	})
//	英文字母的转变
    $(".have_pro>li:eq(0)").mouseenter(function(){
    	$(this).text("集团官网").css({"color":"#000"});
    })
    $(".have_pro>li:eq(0)").mouseleave(function(){
    	$(this).text("YOHO");
    })
    $(".have_pro>li:eq(1)").mouseenter(function(){
    	$(this).text("男生潮流").css({"color":"#000"});
    })
    $(".have_pro>li:eq(1)").mouseleave(function(){
    	$(this).text("YOHOBOYS");
    })
     $(".have_pro>li:eq(2)").mouseenter(function(){
    	$(this).text("女生潮流").css({"color":"#000"});
    })
    $(".have_pro>li:eq(2)").mouseleave(function(){
    	$(this).text("YOHOGILS");
    })
     $(".have_pro>li:eq(3)").mouseenter(function(){
    	$(this).text("新鲜好去处").css({"color":"#000"});
    })
    $(".have_pro>li:eq(3)").mouseleave(function(){
    	$(this).text("Mars");
    })
      $(".have_pro>li:eq(4)").mouseenter(function(){
    	$(this).text("潮流嘉年华").css({"color":"#000"});
    })
    $(".have_pro>li:eq(4)").mouseleave(function(){
    	$(this).text("YO'HOOD");
    })
// 鼠标移动到客户服务显示效果
   $("#customer").mouseenter(function(){
   	   $(".customer").slideDown(200);
   })
    $("#customer").mouseleave(function(){
   	   $(".customer").slideUp(200);
   })
// 鼠标移动到微信部分显示效果
   $("#weixin_focuse").mouseenter(function(){
   	   $(".weixin_focuse").show();
   })
    $("#weixin_focuse").mouseleave(function(){
   	   $(".weixin_focuse").hide();
   })
// 鼠标移动到手机部分显示效果
   $("#phone").mouseenter(function(){
   	   $(".phone").show();
   })
    $("#phone").mouseleave(function(){
   	   $(".phone").hide();
   })
//购物车部分
$("#carshop").mouseenter(function(){
	$(".shoperCar").show();
})
$("#carshop").mouseleave(function(){
	$(".shoperCar").hide();
})

//黑色导航条部分的内容显示
//服饰部分
$(".black_pro>li:eq(2)").mouseenter(function(){
	$(".pro_hover").show().children("li").eq(0).show().siblings("li").hide();
})
$(".pro_hover").mouseleave(function(){
	$(this).hide().$(this).children("li").hide();
})
//鞋履部分
$(".black_pro>li:eq(3)").mouseenter(function(){
	$(".pro_hover").show().children("li").eq(1).show().siblings("li").hide();
})
$(".pro_hover").mouseleave(function(){
	$(this).hide().$(this).children("li").hide();
})
//包袋部分
$(".black_pro>li:eq(4)").mouseenter(function(){
	$(".pro_hover").show().children("li").eq(2).show().siblings("li").hide();
})
$(".pro_hover").mouseleave(function(){
	$(this).hide().$(this).children("li").hide();
})
//配饰部分
$(".black_pro>li:eq(5)").mouseenter(function(){
	$(".pro_hover").show().children("li").eq(3).show().siblings("li").hide();
})
$(".pro_hover").mouseleave(function(){
	$(this).hide().$(this).children("li").hide();
})
//鼠标移动到店铺介绍部分的二维码显示
$(".login_main").mouseenter(function(){
	$(".upjt").show().next().show();
})
$(".login").mouseleave(function(){
	$(".upjt").hide().next().hide();
})
//风格部分 的效果
$("#style").mouseenter(function(){
	$("#jt2").show().next().show();
	$(this).children("img").css("display","none");
})
$(".person_style").mouseleave(function(){
	$("#jt2").hide().next().hide();
	$("#style").children("img").css("display","inline-block");
})
//袖长部分的效果
$("#long_xiu").mouseenter(function(){
	$("#jt3").show().next().show();
	$(this).children("img").css("display","none");
})
$(".long").mouseleave(function(){
	$("#jt3").hide().next().hide();
	$("#long_xiu").children("img").css("display","inline-block");
})
//点击数字部分出现内容
$(".store_right_top_r>ul>li:eq(0)").click(function(){
	$(".num_hover").slideToggle()
	
})
$(".num_hover>ul>li").mouseenter(function(){
	$(this).css("background","blue").siblings("li").css("background","#FFF8EA");
})



//鼠标移动到衣服上出现内容
//第一件衣服的
$(".clothes1").mouseenter(function(){
	$(".cloth_box").show();
})
$(".small_cloth>img:eq(1)").mouseenter(function(){
$(".clothes1>img[src='../img/clothes1.jpg']").attr('src','../img/clothes2.jpg');

})
$(".small_cloth>img:eq(0)").mouseenter(function(){
$(".clothes1>img[src='../img/clothes2.jpg']").attr('src','../img/clothes1.jpg');
})
$(".cloth_box").mouseleave(function(){
	$(".cloth_box").hide();
})
//第二件衣服的
$(".clothes2").mouseenter(function(){
	$(".cloth_box2").show();
})
$(".cloth_box2").mouseleave(function(){
	$(".cloth_box2").hide();
})
//第三件衣服的
$(".clothes3").mouseenter(function(){
	$(".cloth_box3").show();
})
$(".small_cloth3>img:eq(0)").mouseenter(function(){
$(".clothes3>img[src='../img/clothes5.jpg']").attr('src','../img/clothes4.jpg');
})
$(".small_cloth3>img:eq(1)").mouseenter(function(){
$(".clothes3>img[src='../img/clothes4.jpg']").attr('src','../img/clothes5.jpg');
})
$(".cloth_box3").mouseleave(function(){
	$(".cloth_box3").hide();
})
//第四件衣服的
$(".clothes4").mouseenter(function(){
	$(".cloth_box4").show();
})
$(".small_cloth4>img:eq(1)").mouseenter(function(){
$(".clothes4>img[src='../img/04_1.jpg']").attr('src','../img/04_2.jpg');
})
$(".small_cloth4>img:eq(0)").mouseenter(function(){
$(".clothes4>img[src='../img/04_2.jpg']").attr('src','../img/04_1.jpg');
})
$(".cloth_box4").mouseleave(function(){
	$(".cloth_box4").hide();
})

//第二行内容开始
//第五件衣服的
$(".clothes5").mouseenter(function(){
	$(".cloth_box5").show();
})
$(".small_cloth5>img:eq(1)").mouseenter(function(){
$(".clothes5>img[src='../img/05_1.jpg']").attr('src','../img/05_2.jpg');
})
$(".small_cloth5>img:eq(0)").mouseenter(function(){
$(".clothes5>img[src='../img/05_2.jpg']").attr('src','../img/05_1.jpg');
})
$(".cloth_box5").mouseleave(function(){
	$(".cloth_box5").hide();
})
//第六件衣服的
$(".clothes6").mouseenter(function(){
	$(".cloth_box6").show();
})
$(".small_cloth6>img:eq(1)").mouseenter(function(){
$(".clothes6>img[src='../img/06_1.jpg']");
})
$(".small_cloth6>img:eq(0)").mouseenter(function(){
$(".clothes6>img[src='../img/06_2.jpg']").attr('src','../img/06_1.jpg');
})
$(".cloth_box6").mouseleave(function(){
	$(".cloth_box6").hide();
})
//第七件衣服
$(".clothes7").mouseenter(function(){
	$(".cloth_box7").show();
})
$(".small_cloth7>img:eq(1)").mouseenter(function(){
$(".clothes7>img[src='../img/07_1.jpg']").attr('src','../img/07_2.jpg');
})
$(".small_cloth7>img:eq(0)").mouseenter(function(){
$(".clothes7>img[src='../img/07_2.jpg']").attr('src','../img/07_1.jpg');
})
$(".cloth_box7").mouseleave(function(){
	$(".cloth_box7").hide();
})

//第八件衣服
$(".clothes8").mouseenter(function(){
	$(".cloth_box8").show();
})
$(".cloth_box8").mouseleave(function(){
	$(".cloth_box8").hide();
})

//第九件衣服开始
$(".clothes9").mouseenter(function(){
	$(".cloth_box9").show();
})
$(".cloth_box9").mouseleave(function(){
	$(".cloth_box9").hide();
})

//第十件开始
$(".clothes10").mouseenter(function(){
	$(".cloth_box10").show();
})
$(".small_cloth10>img:eq(1)").mouseenter(function(){
$(".clothes10>img[src='../img/10_1.jpg']").attr('src','../img/10_2.jpg');
})
$(".small_cloth10>img:eq(0)").mouseenter(function(){
$(".clothes10>img[src='../img/10_2.jpg']").attr('src','../img/10_1.jpg');
})
$(".cloth_box10").mouseleave(function(){
	$(".cloth_box10").hide();
})

//第十一开始
$(".clothes11").mouseenter(function(){
	$(".cloth_box11").show();
})
$(".cloth_box11").mouseleave(function(){
	$(".cloth_box11").hide();
})
//第十二开始

$(".clothes12").mouseenter(function(){
	$(".cloth_box12").show();
})
$(".small_cloth12>img:eq(1)").mouseenter(function(){
$(".clothes12>img[src='../img/12_1.jpg']").attr('src','../img/12_2.jpg');
})
$(".small_cloth12>img:eq(0)").mouseenter(function(){
$(".clothes12>img[src='../img/12_2.jpg']").attr('src','../img/12_1.jpg');
})
$(".cloth_box12").mouseleave(function(){
	$(".cloth_box12").hide();
})


//手风琴js
var i =0;
$(".shoufeng>li").click(function(){
	$(".shoufeng>li>div").eq($(this).index()).slideToggle();
	if(i==0){
		$(".shoufeng>li img").eq($(this).index()).addClass("xunzhuan");
		$(".shoufeng>li img").eq($(this).index()).removeClass("xunfu");
		i=1;
	}else{
		$(".shoufeng>li img").eq($(this).index()).addClass("xunfu");
		$(".shoufeng>li img").eq($(this).index()).removeClass("xunzhuan");
		i=0;
		
	}
})

    //	放回顶部
    $(".dingbuTop").click(function(){
    	$(".dingbuTop>div").slideToggle();
    })
	 $(".dingbubottom").click(function() {
     $('body,html').animate({
         "scrollTop": 0
     }, 300)
     
 });
     //鼠标滚动的距离
     window.addEventListener("scroll",function(){
     	var iTop = $(window).scrollTop();
         console.log(iTop);
     if (iTop >= $("#dingbu").height()) {
            $("#dingbu").slideDown();
        }else{
       	    $("#dingbu").slideUp();
        }
     },true)




})
