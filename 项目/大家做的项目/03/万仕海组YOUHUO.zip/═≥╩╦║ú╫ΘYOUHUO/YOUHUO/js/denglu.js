$(function(){
	//	头部的开始
    $(".h_right>li:eq(1)").mouseenter(function(){
		$(this).css({"background":"#ccc"});
		$(this).children(".h_shou").fadeIn(100);
		$(this).children("b").css("background-image",'url(../img/上三角.png)');
	}) 
	 $(".h_right>li:eq(1)").mouseleave(function(){
	    $(this).css({"background":"#ffffff"});
		$(this).children(".h_shou").fadeOut(200);
		$(this).children("b").css("background-image",'url(../img/下三角.png)');
	})
	$(".h_right>li:eq(3)").mouseenter(function(){
		$(this).css({"background":"#ccc"});
		$(this).children(".h_zai").fadeIn(100);
		$(this).children("span").css("background-image",'url(../img/上三角.png)');
	}) 
	 $(".h_right>li:eq(3)").mouseleave(function(){
	    $(this).css({"background":"#ffffff"});
		$(this).children(".h_zai").fadeOut(200);
		$(this).children("span").css("background-image",'url(../img/下三角.png)');
	}) 
	//头部的结束
//二维码移动
    $(".tupian").mouseenter(function(){
	    $(".tupian").children("i").css({"left":"55px","transition":"0.8s"})
	    $(".tupian").children("b").fadeIn(1500)
})
     $(".tupian").mouseleave(function(){
	    $(".tupian").children("i").css({"left":"130px","transition":"0.8s"})
	    $(".tupian").children("b").hide()
})
     
     $(".yi").click(function(){
     	 $(".top_t").toggle();
     	  $(".top_b").toggle();
     	  $(".mi").hide()
     })
     
     
     
//区域代码
    
     $(".inputL").click(function(){
        $(".ulL").slideDown(500)
     })
	 $(".inputL").blur(function(){
	 	$(".ulL").slideUp(500)
	 })
	$(".ulL li").click(function(){
		var str=$(".ulL li").eq($(this).index()).text()
		$(".inputL").val(str)
	})
	
//	登录方式转换
   $(".putong").click(function(){
   	$(".huan_t").show();
   	$(".huan").hide();
   	
   })
	
	$(".yanzheng").click(function(){
   	$(".huan").show()
   	$(".huan_t").hide()
   })
	
	//图片翻转
	  var current = 0;
			$("#h_x1").click(function(){
				current = (current+90)%360;
				this.style.transform = 'rotate('+current+'deg)';
			})
          	$("#h_x2").click(function(){
				current = (current+90)%360;
				this.style.transform = 'rotate('+current+'deg)';
			})
            $("#h_x3").click(function(){
				current = (current+90)%360;
				this.style.transform = 'rotate('+current+'deg)';
			})
        	$("#h_x4").click(function(){
				current = (current+90)%360;
				this.style.transform = 'rotate('+current+'deg)';
			})
        	
        	
        	
        	$("#h_x11").click(function(){
				current = (current+90)%360;
				this.style.transform = 'rotate('+current+'deg)';
			})
          	$("#h_x21").click(function(){
				current = (current+90)%360;
				this.style.transform = 'rotate('+current+'deg)';
			})
            $("#h_x31").click(function(){
				current = (current+90)%360;
				this.style.transform = 'rotate('+current+'deg)';
			})
        	$("#h_x41").click(function(){
				current = (current+90)%360;
				this.style.transform = 'rotate('+current+'deg)';
			})


	
	
	
	//手机验证
	function isPhoneNo(phone) {
    var pattern = /^1[34578]\d{9}$/;
    return pattern.test(phone);
}
	
/*手机号判断*/
function userTel(inputid, spanid) {
    $(".erPhone").blur(function() {
        if ($.trim($(".erPhone").val()).length == 0) {
            $(".please").show().siblings("span").hide()
            $(".erPhone").css("border","1px solid red")
        } else {
            if (isPhoneNo($.trim($(".erPhone").val())) == false) {
                $(".no").show().siblings("span").hide()
                $(".erPhone").css("border","1px solid red")
            }
        }

    });
};
userTel(".erPhone", ".no");
})





//短信验证
var countdown=60;
function settime(obj) {
  if (countdown == 0) {
    obj.removeAttribute("disabled");
    obj.value="免费获取验证码";
    countdown = 60;
    return;
  } else {
    obj.setAttribute("disabled", true);
    obj.value="重新发送(" + countdown + ")";
    countdown--;
  }
setTimeout(function() {
  settime(obj) }
  ,1000)
}