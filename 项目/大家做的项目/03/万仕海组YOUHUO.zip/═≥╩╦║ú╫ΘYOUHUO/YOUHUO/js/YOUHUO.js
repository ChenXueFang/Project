
//
//var jq11  = jQuery.noConflict(true);
//  jq11(function(){





//  	console.log(jq11.fn.jquery);
// })


$(document).ready(function(){
	
$('#boxThings>li>a').mouseenter(function(){
//	console.log(11);
	$(this).next('div').show();
})
	
$('#boxThings>li>a').mouseleave(function(){
//	console.log(11);
	$(this).next('div').hide();
})	
	
	
	
	
//<!--start 返回顶部-->

        $(".gotop").hide();
        $(window).bind('scroll',function(){
            if($(window).scrollTop()<=180){
                $(".gotop").hide();
                $('.saoYiSao').hide();
           	}else{
                $(".gotop").show();
                 $('.saoYiSao').show();
            }
        });
        $(".gotop").bind("click",function(){
            $('html, body').animate({scrollTop: 0},500);
              $('.saoYiSao>ul').hide();
        });


//	二维码显示隐藏

	$('.saoYiSao').click(function(){
		$(this).children('ul').toggle();
	});
	


//移动的奋斗云
$('#moverHover>li').mouseenter(function(){
//console.log($(this).index());	
//console.log(eq($(this).index()))
//console.log(eq($('#moverHover>li').index()));	
	var mover = $(this).index()*234;
//	console.log(mover);
	$('#hoverarr').animate({"left":mover},100);
//	console.log(222);
})





//点击切换背景色以及图片

$('.sale-nav>li').click(function(){
	$(this).addClass('.yan').siblings('li').removeClass('.yan');
	
	
	
	
})













})