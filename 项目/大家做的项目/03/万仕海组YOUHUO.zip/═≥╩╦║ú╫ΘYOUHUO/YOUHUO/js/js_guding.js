$(function(){
	$(".js_erweima").mouseenter(function(){
	$(".js_erweima").css("background","black");
	$(".js_tanchu").show();
})
$(".js_erweima").mouseleave(function(){
	$(".js_erweima").css("background","#666666");
	$(".js_tanchu").hide();
})
$(".js_tanchu").mouseenter(function(){
	$(".js_erweima").css("background","black");
	$(".js_tanchu").show();
})
$(".js_tanchu").mouseleave(function(){
	$(".js_erweima").css("background","#666666");
	$(".js_tanchu").hide();
})


window.addEventListener('scroll',function(){
	var scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
	if(scrollTop>50){
		$(".js_guding").show();
	}else{
		$(".js_guding").hide();
	}
},true);

})
	
	
