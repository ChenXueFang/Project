$(function(){
	$(".dd_line").eq(0).click(function(){
		$(".dd_dui").eq(0).show();
		$(".dd_dui1").eq(0).hide();
		$(".dd_line").eq(0).css("border","1px solid #FF0700");
		$(".dd_get").eq(0).css("border","1px solid #ccc")
	})
	$(".dd_get").eq(0).click(function(){
		$(".dd_dui1").eq(0).show();
		$(".dd_dui").eq(0).hide();
		$(".dd_get").eq(0).css("border","1px solid #FF0700");
		$(".dd_line").eq(0).css("border","1px solid #ccc")
	})
	$(".dd_line").eq(1).click(function(){
		$(".dd_dui").eq(1).show();
		$(".dd_dui1").eq(1).hide();
		$(".dd_line").eq(1).css("border","1px solid #FF0700");
		$(".dd_get").eq(1).css("border","1px solid #ccc")
	})
	$(".dd_get").eq(1).click(function(){
		$(".dd_dui1").eq(1).show();
		$(".dd_dui").eq(1).hide();
		$(".dd_get").eq(1).css("border","1px solid #FF0700");
		$(".dd_line").eq(1).css("border","1px solid #ccc")
	})
	$(".dd_line1").click(function(){
		$(".dd_dui2").show();
		$(".dd_dui3").hide();
		$(".dd_dui4").hide();
		$(".dd_line1").css("border","1px solid #FF0700");
		$(".dd_get1").css("border","1px solid #ccc")
		$(".dd_get2").css("border","1px solid #ccc")
	})
	$(".dd_get1").click(function(){
		$(".dd_dui3").show();
		$(".dd_dui2").hide();
		$(".dd_dui4").hide();
		$(".dd_get1").css("border","1px solid #FF0700");
		$(".dd_line1").css("border","1px solid #ccc")
		$(".dd_get2").css("border","1px solid #ccc")
	})
	$(".dd_get2").click(function(){
		$(".dd_dui4").show();
		$(".dd_dui2").hide();
		$(".dd_dui3").hide();
		$(".dd_get2").css("border","1px solid #FF0700");
		$(".dd_line1").css("border","1px solid #ccc")
		$(".dd_get1").css("border","1px solid #ccc")
	})
	
//=================================================
	//优惠券tab切换
	$(".discount_hide_title>li").click(function(){
    		//li
    		$(this).addClass("hide_title_selected").siblings("li").removeClass("hide_title_selected");
    		//内容
    		$(".discount_hide_con>div").eq($(this).index()).addClass("hide_con_selected").siblings("div").removeClass("hide_con_selected");
    	})
    })
    
    //优惠券输入框
    $(function(){
    	console.log($(".d_hide_inp").text("").length);
    })
   
////	var shu = 
//  if($(".d_hide_inp").val=""){
//  	$(".d_hide_but").css("background","#b0b0b0");
//  }else{
//  	$(".d_hide_but").css("background","#444");
//  }
	$(".d_hide_inp").change(function(){
		$(".d_hide_but").css("background","#444");
	})
	
	//优惠券隐藏块+-
	$(function(){
		$(".discount_hide").hide();
		$("#c_faPiao_jia1").click(function(){
			$(this).text("-");
			$(".discount_hide").toggle(0,function(){
				$("#c_faPiao_jia1").text("+");
			});
		})
	})
	
//=====================================
	//使用货币隐藏
	$(function(){
		$("#use_money").hide();
		$(".c_use").hide();
		$("#c_faPiao_jia2").click(function(){
			$(this).text("-");
			$("#use_money").toggle();
			$(".c_use").toggle(0,function(){
				$("#c_faPiao_jia1").text("+");
			});
			$(".use_money_but").click(function(){
				$("#c_faPiao_jia2").text("+");
				$("#use_money").hide();
				$(".c_use").hide();
			})
		})
	})

//===========================================================
	//其他信息隐藏
	$(function(){
		$("#c_other").hide();
		$("#c_faPiao_jia3").click(function(){
			$(this).text("-");
			$("#c_other").toggle(0,function(){
				$("#c_faPiao_jia3").text("+");
			});
		})
	})






//=====================================
	//新增地址模态框
	var jq183 = jQuery.noConflict(true);
    jq183(function(){
     	jq183('.c_alert-box').hide();
		jq183('.c_alert_an').on('click', function() {
		    jq183('.c_alert-box').show();
		});
		jq183(".alert_cancel").on('click', function() {
		   jq183('.c_alert-box').hide();
		});
//=====================================
		//发票模态框
		jq183('.faPiao_box').hide();
		jq183('.faPiao_radio').on('click', function() {
		    jq183('.faPiao_box').show();
		});
		jq183(".faPiao_cancel").on('click', function() {
		    jq183('.faPiao_box').hide();
		});
		
//=====================================
		//发票模态框
		jq183('.submit_box').hide();
		jq183('.c_submit_but').on('click', function() {
		    jq183('.submit_box').show();
		});
		jq183(".c_submit_cancel").on('click', function() {
		    jq183('.submit_box').hide();
		});
		
//=====================================
		//手机号验证
		function isPhoneNo(phone) {
		    var pattern = /^1[34578]\d{9}$/;
		    return pattern.test(phone);
		}
		function userTel(inputid, spanid) {
		    jq183(inputid).blur(function() {
		        if (jq183.trim(jq183(inputid).val()).length == 0) {
		            jq183(spanid).html("× 手机号没有输入");
		        } else {
		            if (isPhoneNo(jq183.trim(jq183(inputid).val())) == false) {
		                jq183(spanid).html("× 手机号码不正确");
		            }
		        }
		        jq183(inputid).focus(function() {
		            jq183(spanid).html("");
		        });
		    });
		};
		userTel('#telephone', "#checkExistPhone");
		/*姓名身份证，手机号提交*/
		function isChinaName(name) {
		    var pattern = /^[\u4E00-\u9FA5]{1,6}$/;
		    return pattern.test(name);
		}
		/*用户名判断*/
		function userName(inputid, spanid) {
		    jq183(inputid).blur(function() {
		        if (jq183.trim(jq183(inputid).val()).length == 0) {
		            jq183(spanid).html("× 名称没有输入");
		        } else {
		            if (isChinaName(jq183.trim(jq183(inputid).val())) == false) {
		               jq183(spanid).html("× 名称不合法");
		            }
		        }
		    });
		    jq183(inputid).focus(function() {
		        jq183(spanid).html("");
		    });
		
		};
		userName('#name', "#checkExistname");
	})
	
//=================================================	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

