//$(".g_zuixin1_pic").mouseenter(function(){
//	$("#g_main_Pic").CSS("background","red");
//})
$(function(){
	console.log($(".g_main_left_center>div").eq(0));
	console.log($(".g_main_left_center>div").eq(1));
	console.log($(".g_main_left_center>div").eq(2));
	

$(".g_main_left_top>li").click(function(){
	console.log($(this).index());
	$(this).addClass("g_active").siblings("li").removeClass("g_active");
	$(".g_main_left_center>div").eq($(this).index()).addClass("g_selected").siblings("div").removeClass("g_selected");
	console.log(111);
})
//$("#g_main_left_center>div").eq(0).show();


})

//选择数字区域的
 $(".g_main_left_button>li").click(function(){
 	$(this).addClass("numShow").siblings("li").removeClass("numShow");
 	
 })

//侧栏微信qq的和回顶部
//qq区域
$(".returnBox>ul>li").eq(0).mouseenter(function(){
//	console.log(111);
	$(this).children('span').css({"color":'#fff'})
	$('.imgBxo').toggle(200);
})

$(".returnBox>ul>li").eq(0).mouseleave(function(){
//	console.log(111);
	$(this).children('span').css({"color":'#666'})
	$('.imgBxo').toggle(200);
})
//微信区域
$(".returnBox>ul>li").eq(1).mouseenter(function(){
//	console.log(111);
	$(this).children('span').css({"color":'#fff'})
	$('.imgWei').toggle(200);
})

$(".returnBox>ul>li").eq(1).mouseleave(function(){
//	console.log(111);
	$(this).children('span').css({"color":'#666'})
	$('.imgWei').toggle(200);
})
//回顶部区域
$(".returnBox>ul>li").eq(2).click(function(){
	console.log(111);
	$(this).children('span').css({"color":'#fff'})
	
})

$(".returnBox>ul>li").eq(2).mouseleave(function(){
//	console.log(111);
	$(this).children('span').css({"color":'#666'})
})