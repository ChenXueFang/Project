

$(document).ready(function(){
	
console.log(111);


//点击切换背景色以及图片

$('.sale-nav>li').click(function(){
	
	console.log(222);

	
	$(this).addClass('yan').siblings('li').removeClass('yan');
	
//	console.log(116661);

	$(".movePic>div").eq($(this).index()).addClass("showPic").siblings("div").removeClass("showPic");
	
})


//
////首先让回顶图标隐藏
//      $(".gotop").hide();
//      // bind捆绑方法
//      $(window).bind('scroll',function(){
//      // 顶部滚动卷去的高度
//          if($(window).scrollTop()<=300){
//          // 小于判断高度隐藏
//              $(".gotop").hide();
//         	}else{
//         	// 大于高度显示
//              $(".gotop").show();
//          }
//      });
//      // 点击显示的回顶图标
//      $(".gotop").bind("click",function(){
//      	// 动画回顶，卷去的高度为0；执行时间为300ms;
//          $('html, body').animate({scrollTop: 0},300);
//      });


})