$(function(){
//	头部的开始
    $(".h_right>li:eq(1)").mouseenter(function(){
		$(this).css({"background":"#ccc"});
		$(this).children(".h_shou").fadeIn(100);
		$(this).children("b").css("background-image",'url(../img/上三角.png)');
	}) 
	 $(".h_right>li:eq(1)").mouseleave(function(){
	    $(this).css({"background":"#ffffff"});
		$(this).children(".h_shou").fadeOut(200);
		$(this).children("b").css("background-image",'url(../img/下三角.png)');
	})
	$(".h_right>li:eq(3)").mouseenter(function(){
		$(this).css({"background":"#ccc"});
		$(this).children(".h_zai").fadeIn(100);
		$(this).children("span").css("background-image",'url(../img/上三角.png)');
	}) 
	 $(".h_right>li:eq(3)").mouseleave(function(){
	    $(this).css({"background":"#ffffff"});
		$(this).children(".h_zai").fadeOut(200);
		$(this).children("span").css("background-image",'url(../img/下三角.png)');
	}) 
	//头部的结束
 


function isPhoneNo(phone) {
    var pattern = /^1[34578]\d{9}$/;
    return pattern.test(phone);
}

//图片翻转
var current = 0;
			$("#h_x11").click(function(){
				current = (current+90)%360;
				this.style.transform = 'rotate('+current+'deg)';
			})
          	$("#h_x21").click(function(){
				current = (current+90)%360;
				this.style.transform = 'rotate('+current+'deg)';
			})
            $("#h_x31").click(function(){
				current = (current+90)%360;
				this.style.transform = 'rotate('+current+'deg)';
			})
        	$("#h_x41").click(function(){
				current = (current+90)%360;
				this.style.transform = 'rotate('+current+'deg)';
			})


/*手机号判断*/
function userTel(inputid, spanid) {
    $(inputid).blur(function() {
        if ($.trim($(inputid).val()).length == 0) {
            $(spanid).html("请输入手机号");
        } else {
            if (isPhoneNo($.trim($(inputid).val())) == false) {
                $(spanid).html("号码格式不对");
            }
        }
        $(inputid).focus(function() {
            $(spanid).html("");
        });
    });
};
userTel('#telephone', "#checkExistPhone");


  
  
  
})


