$(document).ready(function(){
//	放大镜小卫衣js开始
    $(".sweaterCenter_center>img").mouseenter(function(){
    	$(".sweaterCenter_left>img").eq($(this).index()).addClass("fore")
    	.siblings("img").removeClass("fore");
    	$(this).addClass("bord").siblings("img").removeClass("bord");
    });
//  放大镜小卫衣js结束
    
    //*****************************************************************
//	 放大镜图片关联js开始
	 $(".sweaterCenter_center>img").mouseenter(function(){
	 	$(".big_box>img").eq($(this).index()).addClass("fangda")
	 	.siblings("img").removeClass("fangda");
	 	
	 });
//	  放大镜图片关联js结束

//********************************************************************

//  促销js开始
    $(".manjia").click(function(){
    	$(".zhuangkai>ul").slideDown();
    });
    $(".shouqi").click(function(){
    	$(".zhuangkai>ul").slideUp();
    });
//  促销js结束

//**************************************************************************
     
//   颜色js开始
     $(".yanse>div").click(function(){
     	$(this).addClass("bsck").siblings("div")
     	.removeClass("bsck");
     });
//   颜色js结束

//********************************************************************************

//  点击颜色图片变化js开始
    $(".yanse>div:eq(1)").click(function(){
//  	中间小图
     	$(".sweaterCenter_center>img:eq(0)").attr('src','../img/heiseweiyi1.jpg');
     	$(".sweaterCenter_center>img:eq(1)").attr('src','../img/heisweiyi2.jpg');
//   	左大图
        $(".sweaterCenter_left>img:eq(0)").attr('src','../img/heiseweiyi1.jpg');
     	$(".sweaterCenter_left>img:eq(1)").attr('src','../img/heisweiyi2.jpg');
//   	定位图
        $(".big_box>img:eq(0)").attr('src','../img/heiseweiyi1.jpg');
     	$(".big_box>img:eq(1)").attr('src','../img/heisweiyi2.jpg');
    });
    
     $(".yanse>div:eq(0)").click(function(){
//  	中间小图
     	$(".sweaterCenter_center>img:eq(0)").attr('src','../img/huangseweiyi1.jpg');
     	$(".sweaterCenter_center>img:eq(1)").attr('src','../img/huangseweiyi2.jpg');
//   	左大图
        $(".sweaterCenter_left>img:eq(0)").attr('src','../img/huangseweiyi1.jpg');
     	$(".sweaterCenter_left>img:eq(1)").attr('src','../img/huangseweiyi2.jpg');
//   	定位图
        $(".big_box>img:eq(0)").attr('src','../img/huangseweiyi1.jpg');
     	$(".big_box>img:eq(1)").attr('src','../img/huangseweiyi2.jpg');
     });
//  点击颜色图片变化js结束  
     
//***************************************************************************************   

	//放大镜js开始
	$(".mask").mouseover(function() {
	    $(".float_layer").show()
	    $(".big_box").show()
	})
	$(".mask").mouseout(function() {
	    $(".float_layer").hide()
	    $(".big_box").hide()
	})
	
	
	$(".mask").mousemove(function(e) {
	    var l = e.pageX - $(".small_box").offset().left - ($(".float_layer").width() / 2)
	    var t = e.pageY - $(".small_box").offset().top - ($(".float_layer").height() / 2)
	    if (l < 0) {
	        l = 0
	    }
	    if (l > $(this).width() - $(".float_layer").width()) {
	        l = $(this).width() - $(".float_layer").width()
	    }
	    if (t < 0) {
	        t = 0
	    }
	    if (t > $(this).height() - $(".float_layer").height()) {
	        t = $(this).height() - $(".float_layer").height()
	    }
	
	    $(".float_layer").css({
	        "left": l,
	        "top": t
	    })
	    var pX = l / ($(".mask").width() - $(".float_layer").width())
	    var pY = t / ($(".mask").height() - $(".float_layer").height())
	    $(".big_box img").css({
	        "left": -pX * ($(".big_box img").width() - $(".big_box").width()),
	        "top": -pY * ($(".big_box img").height() - $(".big_box").height())
	    })
	
	
	});
	//放大镜js结束
//	*****************************************************

//  尺码js开始
    $(".cima>ul>li").click(function(){
    	$(this).addClass("ci").siblings("li").removeClass("ci").removeClass("chi");
    	$("#jia").css({"cursor":"not-allowed","color":"#999999"});
    	$("#jia").unbind("click");
    	$("#jian").unbind("click");
    	var t=$("#jia").parent().find(".inp");
    	if(t.val()>1){
    		t.val(1);
        }
    	$('.num>div').css({"display":"none"});
//  	加入购物车
         $(".shouwan").css({"display":"block"}).siblings("div")
         .css({"display":"none"});
    });
    
    
    $(".cima>ul>li:eq(3)").click(function(){
    	$(this).addClass("chi");
    	//  商品数量加减js开始
    	$("#jia").css({"cursor":"pointer","color":"#000000"});
    	// 商品点击增加
	    	$("#jia").click(function(){
	    	var t=$(this).parent().find(".inp");
	    	t.val(parseInt(t.val())+1);
	    	if(t.val()>1){
	    		$("#jian").css({"cursor":"pointer","color":"#000000"});
	    	}
	    	if(t.val()>=5){
	    		t.val(5)
	    		$("#jia").css({"cursor":"not-allowed","color":"#999999"});
	    	}
	    });
	     //  商品减
	    $("#jian").click(function(){
	    	var t=$(this).parent().find(".inp");
	    	t.val(parseInt(t.val())-1);
	    	if(t.val()<=1){
	    		t.val(1);
	    		$("#jian").css({"cursor":"not-allowed","color":"#999999"});
	    	}
	    	if(t.val()<5){
		    		$("#jia").css({"cursor":"pointer","color":"#000000"});
		    	}
	    });
	    $("#jian").mouseenter(function(){
	    	var t=$(this).parent().find(".inp");
	    	if(t.val()<=1){
	    		$(this).css({"cursor":"not-allowed"});
	    	}else{
	    		$(this).css({"cursor":"pointer"});
	    	}
	    });
	    //  商品数量加减js结束
//	    购物车
         $(".shouc").css({"display":"block"}).siblings("div")
         .css({"display":"none"});
//	    商品紧剩5件js
        $('.num>div').css({"display":"block"});
    });
    
   

    
//  尺码js结束






    
//  **********************************************************
    
//  胸围js开始
    $(".cima>ul>li:eq(0)").click(function(){
    	$(".daxiao").addClass("daXi");
    	$(".daxiao").text("胸围 102cm");
    });
    $(".cima>ul>li:eq(1)").click(function(){
    	$(".daxiao").addClass("daXi");
    	$(".daxiao").text("胸围 106cm");
    });
    $(".cima>ul>li:eq(2)").click(function(){
    	$(".daxiao").addClass("daXi");
    	$(".daxiao").text("胸围 110cm");
    });
    $(".cima>ul>li:eq(3)").click(function(){
    	$(".daxiao").addClass("daXi");
    	$(".daxiao").text("胸围 116cm");
    });
//  胸围js结束

//*****************************************************************
    
    
//  售后服务js开始
var i=0;
    $(".serceTop").click(function(){
    	$(".tuiHuo").slideToggle();
    	if(i==0){
    		$(".serceTop>i").addClass("icon-angle-down")
    		.removeClass("icon-arrow-left");
    		i=1;
    	}else{
    		i=0;
    		$(".serceTop>i").addClass("icon-arrow-left")
    		.removeClass("icon-angle-down");
    	}
    });
//  售后服务js开始
    
//  ******************************************************

//  推荐js开始
    $(".recommendTop>ul>li").click(function(){
//  	点击出现低边框
    	$(this).addClass("teshu").siblings("li")
    	.removeClass("teshu");
//  	换一换消失
    	$(".recommendTop>div").slideUp();
//  	点击下部分切换
        $(".recommendBottom>div").eq($(this).index())
        .slideDown().siblings().slideUp();
    });
//  点击店铺推荐出现换一换
    $(".recommendTop>ul>li:eq(0)").click(function(){
    	$(".recommendTop>div").slideDown();
    });
    
    
//  店铺推荐轮播js
    // 获取第一张图片的节点对象
	var firstImg = $('#ul li').first().clone();
	// 添加到最后的位置 并设置 ul 的宽度
//	$('#ul').append(firstImg).width($('#ul li').length * $('.dianpu').width());
	
	var i = 0;
	var imgW = $('.dianpu').width();
	
	// 下一张
	$('.huan').click(function() {
	    moveImg(++i);
	});
	
	// 移动到指定的图片
	function moveImg() {
	    // alert(num);
	
	    // 最后一张
	    if (i == 3) {
	        $('#ul').css({
	            left: 0
	        })
	        i = 1;
	    }
	
	    // 是第一张的时候			
	    if (i == -1) {
	        i = $('#ul li').length - 2;
	        $('#ul').css({
	            left: ($('#ul li').length - 1) * -800
	        });
	    }
	
	    // 移动图片动画
	    $('#ul').stop().animate({
	        left: i * -imgW
	    }, 800);
	    
	}
//  推荐js结束

//	放回顶部
//  $(".dingbuTop").click(function(){
////  	$(".dingbuTop>div").slideToggle();
//  });
//	 $(".dingbubottom").click(function() {
//   $('body,html').animate({
//       "scrollTop": 0
//   }, 300);
//   
// });
//
//   //鼠标滚动的距离
//   window.addEventListener("scroll",function(){
//   	var iTop = $(window).scrollTop();
//       console.log(iTop);
//   if (iTop >= $("#dingbu").height()) {
//          $("#dingbu").slideDown();
//      }else{
//     	    $("#dingbu").slideUp();
//      }
//   },true)
//   
     
     
});