$(".S_one").mouseenter(function(){
	$(".S_one>ul").toggle();
	$(this).css("background","gray");
})
$(".S_one").mouseleave(function(){
	$(".S_one>ul").hide();
	$(this).css("background","#f4f4f4");
})
$(".S_one li:eq(0)").mouseenter(function(){
	$(this).text("集团官网");
})
$(".S_one li:eq(1)").mouseenter(function(){
	$(this).text("男生潮流");
})
$(".S_one li:eq(2)").mouseenter(function(){
	$(this).text("女生潮流");
})
$(".S_one li:eq(3)").mouseenter(function(){
	$(this).text("新鲜好去处");
})
$(".S_one li:eq(4)").mouseenter(function(){
	$(this).text("潮流嘉年华");
})
$(".S_one li:eq(0)").mouseleave(function(){
	$(this).text("YOHU!");
	$(this).addClass("yoho-group");
})
$(".S_one li:eq(1)").mouseleave(function(){
	$(this).text("YOHU!BOYS");
	$(this).addClass("yoho-group");
})
$(".S_one li:eq(2)").mouseleave(function(){
	$(this).text("YOHU!GIRLS");
	$(this).addClass("yoho-group");
})
$(".S_one li:eq(3)").mouseleave(function(){
	$(this).text("Mars");
	$(this).addClass("yoho-group");
})
$(".S_one li:eq(4)").mouseleave(function(){
	$(this).text("YO'HOOD");
	$(this).addClass("yoho-group");
})

//客户服务
$(".S_eight").mouseenter(function(){
	$(".S_eight>ul").show();
})
$(".S_eight").mouseleave(function(){
	$(".S_eight>ul").hide();
})
//关注有货
$("#S_nine").mouseenter(function(){
	$("#S_nine img").toggle();
})
$("#S_nine").mouseleave(function(){
	$("#S_nine img").hide();
})
//手机版
$("#S_ten").mouseenter(function(){
	$("#S_ten img").toggle();
})
$("#S_ten").mouseleave(function(){
	$("#S_ten img").hide();
})