        function mytransform(){  
            if($(".S_box1").attr("id") == undefined || $(".S_box1").attr("id") === ""){  
                $(".S_box1").attr("id","S_box1");  
            }else if($(".S_box1").attr("id") === "S_box1") {  
                $(".S_box1").attr("id","");  
            }  
            if($(".S_box2").attr("id") == undefined || $(".S_box2").attr("id") === "S_box1"){  
                $(".S_box2").attr("id","S_box2");  
            }else if($(".S_box2").attr("id") === "S_box2") {  
                $(".S_box2").attr("id","S_box1");  
            }  
        }
      var timer =  setInterval(mytransform,2000);