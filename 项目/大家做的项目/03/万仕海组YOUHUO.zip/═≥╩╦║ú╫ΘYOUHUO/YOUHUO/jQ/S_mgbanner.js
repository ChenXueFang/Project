$(".S_baner_left li").mouseenter(function(){
	$(this).children("a").css("top","4px");
	$(this).children("a").children("div").css("opacity","1");
	$(this).children("a").children("p").fadeIn();
	$(this).children("a").css("box-shadow","0 0 28px 0 rgba(0,0,0,.2)");
	console.log($(this).children());
})
$(".S_baner_left li").mouseleave(function(){
	$(this).children("a").css("top","10px");
	$(this).children("a").children("div").css("opacity","0");
	$(this).children("a").children("p").fadeOut();
})


//var nav1=$(".S_nav1"); //得到导航对象
//var win=$(window); //得到窗口对象
//var sc=$(document);//得到document文档对象。

$(window).scroll(function(){
 	if($(document).scrollTop()>172){
  		$(".S_nav1").fadeIn(); 
 	}else{
 		 $(".S_nav1").fadeOut();
 	}
})


//	jQuery("#j-slidewrap").slide({
//		titCell:".u-slidepg ul li",
//		mainCell:".slide ul",
//		autoPlay:true,
//		delayTime:0,
//	});	