var timer = null;
var num = 0;
fn();
timer = setInterval(fn,2000)
function fn (){
	if(num>7){
		num=0;
	$('#lunbo .lunbo_box li').eq(0).show().siblings().hide();
	}
	$('#lunbo .lunbo_box li').eq(num).show().siblings().hide();
	num++;
}
$('#lunbo').mouseenter(function(){
	clearTimeout(timer)
})
$('#lunbo').mouseleave(function(){
	timer = setInterval(fn,2000);
})
num =0;
$('#lunbo_right').click(function(){
	num++;
	if(num>7){
		num=0;
	$('#lunbo .lunbo_box li').eq(0).show().siblings().hide();
	}
	$('#lunbo .lunbo_box li').eq(num).show().siblings().hide();
	
})

$('#lunbo_left').click(function(){
	num--;
	if(num<0){
		num=7;
	$('#lunbo .lunbo_box li').eq(0).show().siblings().hide();
	}
	$('#lunbo .lunbo_box li').eq(num).show().siblings().hide();
})
$('#lunbo>ul>li').mouseenter(function(){
	$('#lunbo .lunbo_box li').eq($(this).index()).show().siblings().hide();
})
//固定右面导航条


$('#right_nav li').mouseenter(function(){
	
	$(this).find('b').show().css({'width':'80px','transition':'1s'});
	
})
$('#right_nav li').mouseleave(function(){
	$(this).find('b').hide();
})
