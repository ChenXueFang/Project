 $(".h_right>li:eq(1)").mouseenter(function(){
		$(this).css({"background":"#ccc"});
		$(this).children(".h_shou").fadeIn(100);
		$(this).children("b").css("background-image",'url(../img/上三角.png)');
	}) 
	 $(".h_right>li:eq(1)").mouseleave(function(){
	    $(this).css({"background":"#ffffff"});
		$(this).children(".h_shou").fadeOut(200);
		$(this).children("b").css("background-image",'url(../img/下三角.png)');
	})
	$(".h_right>li:eq(3)").mouseenter(function(){
		$(this).css({"background":"#ccc"});
		$(this).children(".h_zai").fadeIn(100);
		$(this).children("span").css("background-image",'url(../img/上三角.png)');
	}) 
	 $(".h_right>li:eq(3)").mouseleave(function(){
	    $(this).css({"background":"#ffffff"});
		$(this).children(".h_zai").fadeOut(200);
		$(this).children("span").css("background-image",'url(../img/下三角.png)');
	}) 

$('.banner_bot ol li').click(function(){
	$(this).css({'background':'#fff','border':'1px solid #ccc','borderBottom':'1px solid #fff','height':'41px'}).siblings('li').css({'background':'#ededed','border':'','borderBottom':'1px solid #ccc','height':'41px'});
	$('.banner_bot ul').eq($(this).index()).show().siblings('ul').hide();
})

	
		var times = 60 * 60; // 60秒
		var countTime = setInterval(fn1, 1000);
		function fn1 () {
			times = --times < 0 ? 0 : times;
			var ms = Math.floor(times / 60).toString();
//				console.log(ms)
			if(ms.length <= 1) {
				ms = "0" + ms;
			}
			var hm = Math.floor(times % 60).toString();
//			console.log(Math.floor(times))
			if(hm.length <= 1) {
				hm = "0" + hm;
			}
			if(times == 0) {
//				alert("游戏结束");
				clearInterval(countTime);
			}
			// 获取分钟、毫秒数
			$(".banner_zhifu p span:eq(0)").html(ms);
			$(".banner_zhifu p span:eq(1)").html(hm);
		}
	
